#targetengine "outlineStrokeBridgeV2"

/*
  PS 轮廓化描边助手 V2

  设计目标：
  - 形状图层、形状文件夹统一走 Photoshop PDF 中转到 Illustrator
  - Illustrator 只清理明确的页面白底矩形，不做激进对象过滤
  - AI 处理结果会保留在 Illustrator 里，便于检查
  - 复制完成后尝试自动回 Photoshop 弹出粘贴窗口
  - 位图描摹是测试功能，适合黑白/纯色/边缘清晰图案
*/

(function () {
  var appName = String(app.name || "").toLowerCase();

  function isPhotoshop() {
    return appName.indexOf("photoshop") >= 0;
  }

  function isIllustrator() {
    return appName.indexOf("illustrator") >= 0;
  }

  function aiSource() {
    return [
      'function tryMenu(name) {',
      '  try { app.executeMenuCommand(name); return true; } catch (e) { return false; }',
      '}',
      '',
      'function quietIllustratorAlerts() {',
      '  var oldLevel = null;',
      '  try {',
      '    oldLevel = app.userInteractionLevel;',
      '    app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;',
      '  } catch (e) {}',
      '  return oldLevel;',
      '}',
      '',
      'function restoreIllustratorAlerts(oldLevel) {',
      '  try {',
      '    if (oldLevel !== null && oldLevel !== undefined) app.userInteractionLevel = oldLevel;',
      '  } catch (e) {}',
      '}',
      '',
      'function unlockAll(item) {',
      '  try { item.locked = false; } catch (e) {}',
      '  try { item.hidden = false; } catch (e2) {}',
      '  if (item.layers) {',
      '    for (var i = 0; i < item.layers.length; i++) unlockAll(item.layers[i]);',
      '  }',
      '  if (item.pageItems) {',
      '    for (var j = 0; j < item.pageItems.length; j++) unlockAll(item.pageItems[j]);',
      '  }',
      '}',
      '',
      'function boundsOf(item) {',
      '  try {',
      '    var b = item.geometricBounds;',
      '    return { left:b[0], top:b[1], right:b[2], bottom:b[3], width:Math.abs(b[2]-b[0]), height:Math.abs(b[1]-b[3]) };',
      '  } catch (e) { return null; }',
      '}',
      '',
      'function artboardBox(doc) {',
      '  var ab = doc.artboards[doc.artboards.getActiveArtboardIndex()].artboardRect;',
      '  return { left:ab[0], top:ab[1], right:ab[2], bottom:ab[3], width:Math.abs(ab[2]-ab[0]), height:Math.abs(ab[1]-ab[3]) };',
      '}',
      '',
      'function isWhiteColor(color) {',
      '  try {',
      '    if (!color) return false;',
      '    if (color.typename === "RGBColor") return color.red >= 245 && color.green >= 245 && color.blue >= 245;',
      '    if (color.typename === "CMYKColor") return color.cyan <= 3 && color.magenta <= 3 && color.yellow <= 3 && color.black <= 3;',
      '    if (color.typename === "GrayColor") return color.gray <= 3;',
      '  } catch (e) {}',
      '  return false;',
      '}',
      '',
      'function isPageWhiteRect(item, doc) {',
      '  try {',
      '    if (!item || item.typename !== "PathItem") return false;',
      '    if (!item.closed) return false;',
      '    if (item.pathPoints.length !== 4) return false;',
      '    var b = boundsOf(item);',
      '    if (!b) return false;',
      '    var ab = artboardBox(doc);',
      '    var nearArtboardSize = b.width >= ab.width * 0.88 && b.height >= ab.height * 0.88;',
      '    if (!nearArtboardSize) return false;',
      '    var noStroke = !item.stroked;',
      '    var emptyFill = !item.filled;',
      '    var whiteFill = item.filled && isWhiteColor(item.fillColor);',
      '    return noStroke && (emptyFill || whiteFill);',
      '  } catch (e) { return false; }',
      '}',
      '',
      'function removePageFrames(container, doc) {',
      '  var removed = 0;',
      '  try {',
      '    for (var i = container.pageItems.length - 1; i >= 0; i--) {',
      '      var item = container.pageItems[i];',
      '      if (item.typename === "GroupItem") removed += removePageFrames(item, doc);',
      '      if (isPageWhiteRect(item, doc)) {',
      '        try { item.remove(); removed++; } catch (e) {}',
      '      }',
      '    }',
      '  } catch (e2) {}',
      '  return removed;',
      '}',
      '',
      'function cleanupDoc(doc) {',
      '  unlockAll(doc);',
      '  removePageFrames(doc, doc);',
      '}',
      '',
      'function copySelectionToClipboard() {',
      '  try {',
      '    app.copy();',
      '    try { app.redraw(); } catch (redrawError) {}',
      '    try { $.sleep(1200); } catch (sleepError) {}',
      '    return true;',
      '  } catch (e) {',
      '    return false;',
      '  }',
      '}',
      '',
      'function closeDocNoSave(doc) {',
      '  try {',
      '    if (doc) doc.close(SaveOptions.DONOTSAVECHANGES);',
      '  } catch (e) {}',
      '}',
      '',
      'function removePlacedLinks(container) {',
      '  var removed = 0;',
      '  try {',
      '    for (var i = container.pageItems.length - 1; i >= 0; i--) {',
      '      var item = container.pageItems[i];',
      '      if (item.typename === "GroupItem") removed += removePlacedLinks(item);',
      '      if (item.typename === "PlacedItem") {',
      '        try { item.remove(); removed++; } catch (removeError) {}',
      '      }',
      '    }',
      '  } catch (e) {}',
      '  return removed;',
      '}',
      '',
      'function hasGroupItem(container) {',
      '  try {',
      '    for (var i = 0; i < container.pageItems.length; i++) {',
      '      var item = container.pageItems[i];',
      '      if (item.typename === "GroupItem") return true;',
      '      if (item.pageItems && hasGroupItem(item)) return true;',
      '    }',
      '  } catch (e) {}',
      '  return false;',
      '}',
      '',
      'function selectGroupsOnly(container) {',
      '  var count = 0;',
      '  try {',
      '    for (var i = 0; i < container.pageItems.length; i++) {',
      '      var item = container.pageItems[i];',
      '      if (item.typename === "GroupItem") {',
      '        try { item.selected = true; count++; } catch (selectError) {}',
      '      } else if (item.pageItems) {',
      '        count += selectGroupsOnly(item);',
      '      }',
      '    }',
      '  } catch (e) {}',
      '  return count;',
      '}',
      '',
      'function ungroupIfNeeded(doc, maxTimes) {',
      '  for (var i = 0; i < maxTimes; i++) {',
      '    cleanupDoc(doc);',
      '    if (!hasGroupItem(doc)) return;',
      '    app.selection = null;',
      '    if (selectGroupsOnly(doc) === 0) return;',
      '    if (!tryMenu("ungroup")) return;',
      '  }',
      '}',
      '',
      'function outlineVectorDocAndCopy(doc) {',
      '  cleanupDoc(doc);',
      '  tryMenu("selectall");',
      '  tryMenu("expandStyle");',
      '  tryMenu("expand");',
      '  cleanupDoc(doc);',
      '  if (!tryMenu("outline")) tryMenu("OffsetPath v22");',
      '  cleanupDoc(doc);',
      '  ungroupIfNeeded(doc, 3);',
      '  cleanupDoc(doc);',
      '  tryMenu("selectall");',
      '  if (!copySelectionToClipboard()) return "COPY_BACK_FAILED";',
      '  closeDocNoSave(doc);',
      '  return "OK";',
      '}',
      '',
      'function traceBitmapFileAndCopy(imagePath) {',
      '  var step = "start";',
      '  var file = new File(imagePath);',
      '  if (!file.exists) return "IMAGE_MISSING";',
      '  var doc = null;',
      '  try {',
      '    step = "create_ai_document";',
      '    try { doc = app.documents.add(); } catch (docAddError) { return "TRACE_DOC_FAILED at " + step + ": " + docAddError; }',
      '    step = "add_placed_item";',
      '    var placed = doc.placedItems.add();',
      '    step = "place_png_file";',
      '    try { placed.file = file; } catch (placeFileError) { return "TRACE_PLACE_FAILED at " + step + ": " + placeFileError; }',
      '    step = "position_png";',
      '    try { placed.position = [0, 0]; } catch (positionError) {}',
      '    step = "select_png";',
      '    app.selection = null;',
      '    placed.selected = true;',
      '    var traced = false;',
      '    step = "placed_trace";',
      '    try { placed.trace(); traced = true; } catch (traceError) {}',
      '    step = "menu_live_trace";',
      '    if (!traced) traced = tryMenu("Live Trace");',
      '    step = "menu_tracing_make";',
      '    if (!traced) traced = tryMenu("Tracing Make");',
      '    step = "menu_make_tracing";',
      '    if (!traced) traced = tryMenu("makeTracing");',
      '    if (!traced) return "TRACE_MANUAL_READY";',
      '    step = "redraw_after_trace";',
      '    try { app.redraw(); } catch (redrawError) {}',
      '    try { $.sleep(300); } catch (sleepError) {}',
      '    step = "expand_style";',
      '    tryMenu("expandStyle");',
      '    step = "expand";',
      '    tryMenu("expand");',
      '    step = "ungroup_if_needed";',
      '    ungroupIfNeeded(doc, 3);',
      '    step = "select_all";',
      '    tryMenu("selectall");',
      '    step = "copy_to_clipboard";',
      '    if (!copySelectionToClipboard()) return "TRACE_MANUAL_READY";',
      '    step = "close_ai_document";',
      '    closeDocNoSave(doc);',
      '    return "OK";',
      '  } catch (e) {',
      '    return "TRACE_MANUAL_READY at " + step + ": " + e;',
      '  }',
      '}',
      '',
      'function prepareBitmapFileForManualTrace(imagePath) {',
      '  var step = "start";',
      '  var file = new File(imagePath);',
      '  if (!file.exists) return "IMAGE_MISSING";',
      '  var doc = null;',
      '  try {',
      '    step = "create_ai_document";',
      '    doc = app.documents.add();',
      '    step = "add_placed_item";',
      '    var placed = doc.placedItems.add();',
      '    step = "place_png_file";',
      '    placed.file = file;',
      '    step = "embed_png";',
      '    try { placed.embed(); } catch (embedError) {}',
      '    step = "select_art";',
      '    tryMenu("selectall");',
      '    try { app.redraw(); } catch (redrawError) {}',
      '    return "BITMAP_MANUAL_READY";',
      '  } catch (e) {',
      '    return "BITMAP_PREP_FAILED at " + step + ": " + e + " line=" + (e.line || "") + " file=" + (e.fileName || "");',
      '  }',
      '}'
    ].join("\n");
  }

  function runPhotoshop() {
    if (typeof BridgeTalk === "undefined") {
      alert("当前 Photoshop 脚本环境不支持 Adobe 跨软件通信。");
      return;
    }

    if (!app.documents.length) {
      alert("请先打开一个 PSD 文件。");
      return;
    }

    function bridgeTargetsText() {
      try {
        var targets = BridgeTalk.getTargets();
        if (!targets || targets.length === 0) return "没有识别到任何 Adobe 脚本目标";
        return targets.join("\n");
      } catch (e) {
        return "读取目标失败：" + e;
      }
    }

    function bridgeErrorText(err) {
      return (
        "Photoshop 没有成功连接到 Illustrator。\n\n" +
        "建议排查：\n" +
        "1. 先手动打开 Illustrator，等它完全启动后再运行脚本。\n" +
        "2. Photoshop 和 Illustrator 的运行权限保持一致，不要一个管理员、一个普通。\n" +
        "3. 如果电脑装了多个 Illustrator 版本，先手动打开要使用的那个版本。\n\n" +
        "Photoshop 当前能识别到的 Adobe 目标：\n" +
        bridgeTargetsText() +
        "\n\n错误信息：\n" + err
      );
    }

    function addUniqueTarget(list, target) {
      if (!target) return;
      var value = String(target);
      for (var i = 0; i < list.length; i++) {
        if (String(list[i]).toLowerCase() === value.toLowerCase()) return;
      }
      list.push(value);
    }

    function illustratorTargets() {
      var result = [];
      var preferredNames = [
        "illustrator-26",
        "illustrator-26.0",
        "illustrator-26.064",
        "illustrator-27",
        "illustrator-27.0",
        "illustrator-28",
        "illustrator-28.0",
        "illustrator-29",
        "illustrator-29.0",
        "illustrator-29.064",
        "illustrator-25",
        "illustrator",
        "illustrator-30",
        "illustrator-30.0"
      ];
      try {
        for (var s = 0; s < preferredNames.length; s++) {
          var spec = BridgeTalk.getSpecifier(preferredNames[s]);
          if (spec) {
            try {
              if (BridgeTalk.isRunning(spec)) addUniqueTarget(result, spec);
            } catch (runningSpecError) {}
          }
        }
      } catch (e2) {}
      try {
        var targets = BridgeTalk.getTargets();
        for (var i = 0; i < targets.length; i++) {
          if (String(targets[i]).toLowerCase().indexOf("illustrator") >= 0) {
            try {
              if (BridgeTalk.isRunning(targets[i])) addUniqueTarget(result, targets[i]);
            } catch (runningTargetError) {}
          }
        }
      } catch (e) {}
      try {
        for (var g = 0; g < preferredNames.length; g++) {
          var fallbackSpec = BridgeTalk.getSpecifier(preferredNames[g]);
          if (fallbackSpec) addUniqueTarget(result, fallbackSpec);
        }
      } catch (e3) {}
      for (var p = 0; p < preferredNames.length; p++) addUniqueTarget(result, preferredNames[p]);
      return result;
    }

    function pasteBack() {
      try { app.bringToFront(); } catch (bringError) {}
      try { $.sleep(1800); } catch (sleepError) {}
      try {
        executeAction(charIDToTypeID("past"), undefined, DialogModes.ALL);
        return true;
      } catch (pasteError) {
        return false;
      }
    }

    function sendToAI(aiCode, autoPaste) {
      if (autoPaste !== false) autoPaste = true;
      var runnerCode = aiCode;
      if (!$.global.outlineStrokePendingBridgeTalks) $.global.outlineStrokePendingBridgeTalks = [];

      function rememberBridgeTalk(bt) {
        $.global.outlineStrokePendingBridgeTalks.push(bt);
      }

      function forgetBridgeTalk(bt) {
        try {
          var list = $.global.outlineStrokePendingBridgeTalks;
          for (var i = list.length - 1; i >= 0; i--) {
            if (list[i] === bt) list.splice(i, 1);
          }
        } catch (e) {}
      }

      function handleResult(res) {
        var body = String(res.body || "");
        if (body.indexOf("PDF_MISSING") >= 0) {
          alert("临时 PDF 没有被 Illustrator 找到。请重试一次。");
          return;
        }
        if (body.indexOf("IMAGE_MISSING") >= 0) {
          alert("临时 PNG 没有被 Illustrator 找到。请重试一次。");
          return;
        }
        if (body.indexOf("TRACE_FAILED") >= 0) {
          alert("位图描摹失败。建议换边缘更清楚的图，或在 Illustrator 里手动使用“图像描摹”。");
          return;
        }
        if (body.indexOf("TRACE_PLACE_FAILED") >= 0) {
          alert("位图描摹失败：Illustrator 没有成功置入临时 PNG。\n\n建议：\n1. 回 Photoshop 确认当前图层可见。\n2. 先把图层栅格化并裁切到可见内容。\n3. 或手动导出 PNG 到 Illustrator 里做图像描摹。\n\n返回信息：\n" + body);
          return;
        }
        if (body.indexOf("TRACE_MANUAL_READY") >= 0) {
          alert("自动位图描摹没有完成，但临时图片已留在 Illustrator。\n\n请在 Illustrator 中选中图片，手动使用“图像描摹”并展开，然后 Ctrl+C，回 Photoshop Ctrl+V 选择“形状图层”。\n\n返回信息：\n" + body);
          return;
        }
        if (body.indexOf("BITMAP_MANUAL_READY") >= 0) {
          alert("位图已稳定送到 Illustrator，并已选中。\n\n请在 Illustrator 里点“图像描摹”，确认效果后点“扩展”，再 Ctrl+C，回 Photoshop Ctrl+V 选择“形状图层”。\n\n这个模式优先保证 AI 2022-2025 都能跑，不强行调用容易失效的自动描摹接口。");
          return;
        }
        if (body.indexOf("BITMAP_PREP_FAILED") >= 0) {
          alert("位图没有成功送到 Illustrator。\n\n建议先在 Photoshop 里确认当前图层可见，并把复杂效果盖印/栅格化后再试。\n\n返回信息：\n" + body);
          return;
        }
        if (body.indexOf("TRACE_DOC_FAILED") >= 0) {
          alert("位图描摹失败：Illustrator 无法新建描摹用的临时文档。\n\n这通常是 Illustrator 当前状态异常、弹窗未关闭，或脚本环境卡住。\n\n建议：\n1. 关闭 Illustrator 里所有弹窗和中间文件。\n2. 重启 Illustrator。\n3. 重新运行脚本。\n\n返回信息：\n" + body);
          return;
        }
        if (body.indexOf("COPY_BACK_FAILED") >= 0) {
          alert("Illustrator 已处理，但复制回剪贴板失败。请切到 Illustrator 手动 Ctrl+C。");
          return;
        }
        if (body.indexOf("AI_SCRIPT_MISSING") >= 0) {
          alert("临时 AI 脚本没有被 Illustrator 找到。请重试一次。");
          return;
        }
        if (body.indexOf("AI_PROCESS_FAILED") >= 0) {
          alert("Illustrator 处理失败。\n\n" + body);
          return;
        }
        if (body.indexOf("OK") < 0) {
          alert("Illustrator 没有返回成功状态，已停止自动粘贴，避免 Photoshop 粘贴时报“无法转换”。\n\n返回信息：\n" + (body || "空"));
          return;
        }
        if (!autoPaste) {
          alert("Illustrator 已处理并复制到剪贴板。\n\n请回到 Photoshop 手动 Ctrl+V，选择“形状图层”。");
          return;
        }
        if (!pasteBack()) {
          alert("Illustrator 已处理并复制，但 Photoshop 自动粘贴没有成功。\n\n请回到 Photoshop 手动 Ctrl+V，选择“形状图层”。");
        }
      }

      function handleError(err) {
        alert(bridgeErrorText(err.body || err));
      }

      function trySendToTarget(target, errors) {
        var running = false;
        try { running = BridgeTalk.isRunning(target); } catch (runningError) {
          errors.push(target + " 检查运行状态失败：" + runningError);
        }

        if (!running) {
          try {
            BridgeTalk.launch(target);
            try { $.sleep(1600); } catch (sleepError) {}
          } catch (launchError) {
            errors.push(target + " 启动失败：" + launchError);
          }
        }

        var bt = new BridgeTalk();
        bt.target = target;
        bt.body = runnerCode;
        bt.onResult = function (res) {
          forgetBridgeTalk(bt);
          handleResult(res);
        };
        bt.onError = function (err) {
          forgetBridgeTalk(bt);
          handleError(err);
        };

        try {
          rememberBridgeTalk(bt);
          if (bt.send(90)) return true;
          forgetBridgeTalk(bt);
          errors.push(target + " send 返回 false");
        } catch (sendError) {
          forgetBridgeTalk(bt);
          errors.push(target + " send 报错：" + sendError);
        }
        return false;
      }

      var targets = illustratorTargets();
      var errors = [];
      for (var i = 0; i < targets.length; i++) {
        if (trySendToTarget(targets[i], errors)) return;
      }
      alert(bridgeErrorText("BridgeTalk.send 返回失败\n\n已经尝试：\n" + targets.join("\n") + "\n\n失败记录：\n" + errors.join("\n")));
    }

    function exportActiveLayerAsPDF() {
      var sourceDoc = app.activeDocument;
      var sourceLayer = sourceDoc.activeLayer;
      var tempDoc = null;
      var oldUnits = app.preferences.rulerUnits;
      var pdfFile = new File(Folder.temp.fsName + "/ps_outline_v2_" + String(new Date().getTime()) + ".pdf");

      try {
        app.preferences.rulerUnits = Units.PIXELS;
        tempDoc = app.documents.add(
          sourceDoc.width,
          sourceDoc.height,
          sourceDoc.resolution,
          "ps_outline_v2_temp",
          NewDocumentMode.RGB,
          DocumentFill.TRANSPARENT
        );
        app.activeDocument = sourceDoc;
        var duplicated = sourceLayer.duplicate(tempDoc, ElementPlacement.PLACEATBEGINNING);
        app.activeDocument = tempDoc;
        tempDoc.activeLayer = duplicated;

        var pdfOptions = new PDFSaveOptions();
        pdfOptions.alphaChannels = true;
        pdfOptions.annotations = false;
        pdfOptions.embedColorProfile = true;
        pdfOptions.layers = true;
        pdfOptions.preserveEditing = true;
        pdfOptions.spotColors = true;
        pdfOptions.vectorData = true;

        tempDoc.saveAs(pdfFile, pdfOptions, true, Extension.LOWERCASE);
        tempDoc.close(SaveOptions.DONOTSAVECHANGES);
        tempDoc = null;
        app.activeDocument = sourceDoc;
        app.preferences.rulerUnits = oldUnits;
        return pdfFile;
      } catch (e) {
        try { if (tempDoc) tempDoc.close(SaveOptions.DONOTSAVECHANGES); } catch (_) {}
        try { app.activeDocument = sourceDoc; } catch (docError) {}
        try { app.preferences.rulerUnits = oldUnits; } catch (unitError) {}
        alert("临时 PDF 导出失败。请确认当前选中的是可见形状图层或图层组。\n\n错误信息：\n" + e);
        return null;
      }
    }

    function exportActiveLayerAsPNG() {
      var sourceDoc = app.activeDocument;
      var sourceLayer = sourceDoc.activeLayer;
      var tempDoc = null;
      var oldUnits = app.preferences.rulerUnits;
      var pngFile = new File(Folder.temp.fsName + "/ps_trace_v2_" + String(new Date().getTime()) + ".png");

      try {
        app.preferences.rulerUnits = Units.PIXELS;
        tempDoc = app.documents.add(
          sourceDoc.width,
          sourceDoc.height,
          sourceDoc.resolution,
          "ps_trace_v2_temp",
          NewDocumentMode.RGB,
          DocumentFill.TRANSPARENT
        );
        app.activeDocument = sourceDoc;
        var duplicated = sourceLayer.duplicate(tempDoc, ElementPlacement.PLACEATBEGINNING);
        app.activeDocument = tempDoc;
        tempDoc.activeLayer = duplicated;
        try { tempDoc.trim(TrimType.TRANSPARENT, true, true, true, true); } catch (trimError) {}
        try {
          tempDoc.resizeCanvas(UnitValue(Number(tempDoc.width.as("px")) + 80, "px"), UnitValue(Number(tempDoc.height.as("px")) + 80, "px"), AnchorPosition.MIDDLECENTER);
        } catch (padError) {}

        var pngOptions = new PNGSaveOptions();
        pngOptions.interlaced = false;
        tempDoc.saveAs(pngFile, pngOptions, true, Extension.LOWERCASE);

        tempDoc.close(SaveOptions.DONOTSAVECHANGES);
        tempDoc = null;
        app.activeDocument = sourceDoc;
        app.preferences.rulerUnits = oldUnits;
        return pngFile;
      } catch (e) {
        try { if (tempDoc) tempDoc.close(SaveOptions.DONOTSAVECHANGES); } catch (_) {}
        try { app.activeDocument = sourceDoc; } catch (docError) {}
        try { app.preferences.rulerUnits = oldUnits; } catch (unitError) {}
        alert("临时 PNG 导出失败。请确认当前选中的是可见位图图层。\n\n错误信息：\n" + e);
        return null;
      }
    }

    function processVector() {
      var pdf = exportActiveLayerAsPDF();
      if (!pdf) return;
      var pdfPath = pdf.fsName.replace(/\\/g, "\\\\");
      var aiCode = [
        '#target illustrator',
        '(function () {',
        '  var pdf = new File("' + pdfPath + '");',
        aiSource(),
        '  function main() {',
        '    if (!pdf.exists) return "PDF_MISSING";',
        '    var oldAlerts = quietIllustratorAlerts();',
        '    var vectorStep = "start";',
        '    try {',
        '      vectorStep = "open_pdf";',
        '      var doc = app.open(pdf);',
        '      vectorStep = "outline_vector_doc";',
        '      var result = outlineVectorDocAndCopy(doc);',
        '      vectorStep = "remove_temp_pdf";',
        '      try { pdf.remove(); } catch (removeError) {}',
        '      vectorStep = "restore_alerts";',
        '      restoreIllustratorAlerts(oldAlerts);',
        '      return result;',
        '    } catch (e) {',
        '      restoreIllustratorAlerts(oldAlerts);',
        '      return "AI_PROCESS_FAILED at vector_main/" + vectorStep + ": " + e + " line=" + (e.line || "") + " file=" + (e.fileName || "");',
        '    }',
        '  }',
        '  return main();',
        '}());'
      ].join("\n");
      sendToAI(aiCode, true);
    }

    function processBitmap() {
      var png = exportActiveLayerAsPNG();
      if (!png) return;
      var pngPath = png.fsName.replace(/\\/g, "\\\\");
      var aiCode = [
        '#target illustrator',
        '(function () {',
        '  var png = new File("' + pngPath + '");',
        aiSource(),
        '  function main() {',
        '    var oldAlerts = quietIllustratorAlerts();',
        '    var bitmapStep = "start";',
        '    try {',
        '      bitmapStep = "auto_trace_bitmap";',
        '      var result = traceBitmapFileAndCopy(png.fsName);',
        '      // 保留临时 PNG，避免 AI 留下链接对象时弹出“找不到链接文件”。',
        '      bitmapStep = "restore_alerts";',
        '      restoreIllustratorAlerts(oldAlerts);',
        '      return result;',
        '    } catch (e) {',
        '      restoreIllustratorAlerts(oldAlerts);',
        '      return "AI_PROCESS_FAILED at bitmap_main/" + bitmapStep + ": " + e + " line=" + (e.line || "") + " file=" + (e.fileName || "");',
        '    }',
        '  }',
        '  return main();',
        '}());'
      ].join("\n");
      sendToAI(aiCode, true);
    }

    function chooseMode() {
      var selectedMode = null;
      try {
        var win = new Window("dialog", "轮廓化描边助手");
        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 10;
        win.margins = 16;

        var title = win.add("statictext", undefined, "选择当前选中的内容");
        try { title.graphics.font = ScriptUI.newFont(title.graphics.font.name, "BOLD", 14); } catch (e) {}

        var group = win.add("group");
        group.orientation = "column";
        group.alignChildren = ["fill", "top"];
        group.spacing = 8;

        var vectorButton = group.add("button", undefined, "形状图层 / 文件夹");
        var bitmapButton = group.add("button", undefined, "位图自动描摹");

        var cancelGroup = win.add("group");
        cancelGroup.alignment = ["right", "top"];
        var cancelButton = cancelGroup.add("button", undefined, "取消", { name: "cancel" });

        vectorButton.onClick = function () { selectedMode = "vector"; win.close(); };
        bitmapButton.onClick = function () { selectedMode = "bitmap"; win.close(); };
        cancelButton.onClick = function () { selectedMode = null; win.close(); };

        win.show();
        return selectedMode;
      } catch (e2) {
        return confirm("处理当前选中的形状图层 / 文件夹？\n\n否 = 位图自动描摹") ? "vector" : "bitmap";
      }
    }

    var mode = chooseMode();
    if (mode === "vector") processVector();
    else if (mode === "bitmap") processBitmap();
  }

  function runIllustrator() {
    alert("请在 Photoshop 里运行主脚本。");
  }

  if (isPhotoshop()) runPhotoshop();
  else if (isIllustrator()) runIllustrator();
  else alert("请在 Photoshop 中运行这个脚本。");
}());
