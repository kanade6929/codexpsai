@echo off
setlocal EnableExtensions
pushd "%~dp0"
set "LOG_FILE=%~dp0install-log.txt"
> "%LOG_FILE%" echo [%date% %time%] Installer started from %~dp0

if /i "%~1"=="--elevated" goto :elevated

fltmc >nul 2>&1
if "%errorlevel%"=="0" goto :elevated

powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand WwBDAG8AbgBzAG8AbABlAF0AOgA6AFcAcgBpAHQAZQBMAGkAbgBlACgAJwBjayhX94tCbKF7BnRYVENnUJYM//eLKFc5X5d6LU4JkOliHCAvZh0gJiAmICcAKQA= 2>nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "try { $p = Start-Process -FilePath '%~f0' -ArgumentList '--elevated' -Verb RunAs -WorkingDirectory '%~dp0' -Wait -PassThru; exit $p.ExitCode } catch { Write-Host $_.Exception.Message; exit 1 }"
if not "%errorlevel%"=="0" (
  echo.
  powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand WwBDAG8AbgBzAG8AbABlAF0AOgA6AFcAcgBpAHQAZQBMAGkAbgBlACgAJwAqZ/2A5U6hewZ0WFRDZ1CWL1SoUolbxYgCMCcAKQA= 2>nul
  powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand WwBDAG8AbgBzAG8AbABlAF0AOgA6AFcAcgBpAHQAZQBMAGkAbgBlACgAJwD3i/NTLpVVU/tR2Y8qTiAAQgBBAFQADP8JkOliHCDlTqF7BnRYVKuO/U7Qj0yIHSACMCcAKQA= 2>nul
  powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand WwBDAG8AbgBzAG8AbABlAF0AOgA6AFcAcgBpAHQAZQBMAGkAbgBlACgAJwCJW8WI5WXXX01Pbn8a/ycAKQA= 2>nul
  echo %LOG_FILE%
  >> "%LOG_FILE%" echo Elevation failed or was cancelled.
  echo.
  pause
  exit /b
)
exit /b

:elevated
fltmc >nul 2>&1
if not "%errorlevel%"=="0" (
  powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand WwBDAG8AbgBzAG8AbABlAF0AOgA6AFcAcgBpAHQAZQBMAGkAbgBlACgAJwChbAlnt4OXX6F7BnRYVENnUJYM/4lbxYjgZdVs537tfgIwJwApAA== 2>nul
  powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand WwBDAG8AbgBzAG8AbABlAF0AOgA6AFcAcgBpAHQAZQBMAGkAbgBlACgAJwD3i/NTLpVVU/tR2Y8qTiAAQgBBAFQADP8JkOliHCDlTqF7BnRYVKuO/U7Qj0yIHSACMCcAKQA= 2>nul
  >> "%LOG_FILE%" echo Administrator check failed after elevation.
  echo.
  pause
  exit /b 1
)

set "FOUND=0"
set "SOURCE_COUNT=0"

for %%J in (*.jsx) do (
  set "SOURCE_COUNT=1"
  call :installByName "%%~fJ" "%%~nxJ"
)

if "%SOURCE_COUNT%"=="0" (
  powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand WwBDAG8AbgBzAG8AbABlAF0AOgA6AFcAcgBpAHQAZQBMAGkAbgBlACgAJwCJW8WIaFbBZbmPoWwJZ35iMFIgAEoAUwBYACAA0mP2Todl9k4CMCcAKQA= 2>nul
  powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand WwBDAG8AbgBzAG8AbABlAF0AOgA6AFcAcgBpAHQAZQBMAGkAbgBlACgAJwD3i0hRjFt0ZeOJi1MgAFoASQBQAAz/jVHMU/tR2Y8qTiAAQgBBAFQAIACJW8WIAjAnACkA 2>nul
  >> "%LOG_FILE%" echo No JSX source file was found.
) else if "%FOUND%"=="0" (
  powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand WwBDAG8AbgBzAG8AbABlAF0AOgA6AFcAcgBpAHQAZQBMAGkAbgBlACgAJwChbAlnfmIwUiAAUABoAG8AdABvAHMAaABvAHAAIAAWYiAASQBsAGwAdQBzAHQAcgBhAHQAbwByACAAhHYagSxnh2X2TjlZAjAnACkA 2>nul
  powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand WwBDAG8AbgBzAG8AbABlAF0AOgA6AFcAcgBpAHQAZQBMAGkAbgBlACgAJwD3i254pIsgAEEAZABvAGIAZQAgAG+P9k6JW8WIKFcgAEMAOgBcAFAAcgBvAGcAcgBhAG0AIABGAGkAbABlAHMAXABBAGQAbwBiAGUAAjAnACkA 2>nul
  >> "%LOG_FILE%" echo No supported Adobe script folder was found.
) else (
  echo.
  powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand WwBDAG8AbgBzAG8AbABlAF0AOgA6AFcAcgBpAHQAZQBMAGkAbgBlACgAJwCJW8WIjFsQYgIwJwApAA== 2>nul
  powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand WwBDAG8AbgBzAG8AbABlAF0AOgA6AFcAcgBpAHQAZQBMAGkAbgBlACgAJwD3i82RL1QgAEEAZABvAGIAZQAM/zZxDlTOThwgh2X2TiAAPgAgABqBLGcdINCPTIjSY/ZOAjAnACkA 2>nul
  >> "%LOG_FILE%" echo Installation completed successfully.
)

echo.
powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand WwBDAG8AbgBzAG8AbABlAF0AOgA6AFcAcgBpAHQAZQBMAGkAbgBlACgAJwCJW8WI5WXXX01Pbn8a/ycAKQA= 2>nul
echo %LOG_FILE%
pause
popd
exit /b

:installByName
set "FILE_NAME=%~2"
echo %FILE_NAME% | findstr /i "ai_ ai- 02_ai _ai illustrator" >nul
if "%errorlevel%"=="0" (
  call :copyIllustrator "%~1" "%~2"
  exit /b
)

echo %FILE_NAME% | findstr /i "ps_ ps- 01_ps _ps photoshop" >nul
if "%errorlevel%"=="0" (
  call :copyPhotoshop "%~1" "%~2"
  exit /b
)

call :copyPhotoshop "%~1" "%~2"
call :copyIllustrator "%~1" "%~2"
exit /b

:copyPhotoshop
for /d %%D in ("%ProgramFiles%\Adobe\Adobe Photoshop*") do (
  if exist "%%~fD\Presets\Scripts\" (
    copy /y "%~1" "%%~fD\Presets\Scripts\%~2" >> "%LOG_FILE%" 2>&1
    if errorlevel 1 (
      powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand WwBDAG8AbgBzAG8AbABlAF0AOgA6AFcAcgBpAHQAZQBMAGkAbgBlACgAJwBQAGgAbwB0AG8AcwBoAG8AcAAgAIlbxYgxWSWNGv8nACkA 2>nul
      echo %%~nxD\Presets\Scripts\%~2
    ) else (
      powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand WwBDAG8AbgBzAG8AbABlAF0AOgA6AFcAcgBpAHQAZQBMAGkAbgBlACgAJwBQAGgAbwB0AG8AcwBoAG8AcAAgAIlbxYgQYp9SGv8nACkA 2>nul
      echo %%~nxD\Presets\Scripts\%~2
      set "FOUND=1"
    )
  )
)
exit /b

:copyIllustrator
for /d %%D in ("%ProgramFiles%\Adobe\Adobe Illustrator*") do (
  set "COPIED_AI_DIR="
  if exist "%%~fD\Presets\" (
    for /d %%L in ("%%~fD\Presets\*") do (
      if not defined COPIED_AI_DIR if exist "%%~fL\Scripts\" (
        set "AI_TARGET_DIR=%%~fL\Scripts"
        call :copyIllustratorToDir "%~1" "%~2"
        set "AI_TARGET_DIR="
      )
    )
    if not defined COPIED_AI_DIR (
      for /f "delims=" %%F in ('dir /b /s /a-d "%%~fD\Presets\*.jsx" 2^>nul') do (
        if not defined COPIED_AI_DIR (
          set "AI_TARGET_DIR=%%~dpF"
          call :copyIllustratorToDir "%~1" "%~2"
          set "AI_TARGET_DIR="
        )
      )
    )
  )
)
exit /b

:copyIllustratorToDir
copy /y "%~1" "%AI_TARGET_DIR%\%~2" >> "%LOG_FILE%" 2>&1
if errorlevel 1 (
  powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand WwBDAG8AbgBzAG8AbABlAF0AOgA6AFcAcgBpAHQAZQBMAGkAbgBlACgAJwBJAGwAbAB1AHMAdAByAGEAdABvAHIAIACJW8WIMVkljRr/JwApAA== 2>nul
  echo %AI_TARGET_DIR%\%~2
) else (
  powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand WwBDAG8AbgBzAG8AbABlAF0AOgA6AFcAcgBpAHQAZQBMAGkAbgBlACgAJwBJAGwAbAB1AHMAdAByAGEAdABvAHIAIACJW8WIEGKfUhr/JwApAA== 2>nul
  echo %AI_TARGET_DIR%\%~2
  set "FOUND=1"
  set "COPIED_AI_DIR=1"
)
exit /b