#target illustrator

/*
  AI 备用轮廓化描边脚本 V2

  用法：
  1. 从 PS 或其它 AI 文件复制矢量对象
  2. 在 Illustrator 里运行本脚本
  3. 脚本会粘贴、轮廓化描边、复制回剪贴板
  4. 回 Photoshop 粘贴为“形状图层”
*/

(function () {
  function tryMenu(name) {
    try {
      app.executeMenuCommand(name);
      return true;
    } catch (e) {
      return false;
    }
  }

  function quietIllustratorAlerts() {
    var oldLevel = null;
    try {
      oldLevel = app.userInteractionLevel;
      app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;
    } catch (e) {}
    return oldLevel;
  }

  function restoreIllustratorAlerts(oldLevel) {
    try {
      if (oldLevel !== null && oldLevel !== undefined) app.userInteractionLevel = oldLevel;
    } catch (e) {}
  }

  function unlockAll(item) {
    try { item.locked = false; } catch (e) {}
    try { item.hidden = false; } catch (e2) {}
    if (item.layers) {
      for (var i = 0; i < item.layers.length; i++) unlockAll(item.layers[i]);
    }
    if (item.pageItems) {
      for (var j = 0; j < item.pageItems.length; j++) unlockAll(item.pageItems[j]);
    }
  }

  function boundsOf(item) {
    try {
      var b = item.geometricBounds;
      return {
        left: b[0],
        top: b[1],
        right: b[2],
        bottom: b[3],
        width: Math.abs(b[2] - b[0]),
        height: Math.abs(b[1] - b[3])
      };
    } catch (e) {
      return null;
    }
  }

  function artboardBox(doc) {
    var ab = doc.artboards[doc.artboards.getActiveArtboardIndex()].artboardRect;
    return {
      left: ab[0],
      top: ab[1],
      right: ab[2],
      bottom: ab[3],
      width: Math.abs(ab[2] - ab[0]),
      height: Math.abs(ab[1] - ab[3])
    };
  }

  function isWhiteColor(color) {
    try {
      if (!color) return false;
      if (color.typename === "RGBColor") return color.red >= 245 && color.green >= 245 && color.blue >= 245;
      if (color.typename === "CMYKColor") return color.cyan <= 3 && color.magenta <= 3 && color.yellow <= 3 && color.black <= 3;
      if (color.typename === "GrayColor") return color.gray <= 3;
    } catch (e) {}
    return false;
  }

  function isPageWhiteRect(item, doc) {
    try {
      if (!item || item.typename !== "PathItem") return false;
      if (!item.closed) return false;
      if (item.pathPoints.length !== 4) return false;
      var b = boundsOf(item);
      if (!b) return false;
      var ab = artboardBox(doc);
      if (b.width < ab.width * 0.88 || b.height < ab.height * 0.88) return false;
      var noStroke = !item.stroked;
      var emptyFill = !item.filled;
      var whiteFill = item.filled && isWhiteColor(item.fillColor);
      return noStroke && (emptyFill || whiteFill);
    } catch (e) {
      return false;
    }
  }

  function removePageFrames(container, doc) {
    var removed = 0;
    try {
      for (var i = container.pageItems.length - 1; i >= 0; i--) {
        var item = container.pageItems[i];
        if (item.typename === "GroupItem") removed += removePageFrames(item, doc);
        if (isPageWhiteRect(item, doc)) {
          try {
            item.remove();
            removed++;
          } catch (e) {}
        }
      }
    } catch (e2) {}
    return removed;
  }

  function cleanupDoc(doc) {
    unlockAll(doc);
    removePageFrames(doc, doc);
  }

  function hasGroupItem(container) {
    try {
      for (var i = 0; i < container.pageItems.length; i++) {
        var item = container.pageItems[i];
        if (item.typename === "GroupItem") return true;
        if (item.pageItems && hasGroupItem(item)) return true;
      }
    } catch (e) {}
    return false;
  }

  function selectGroupsOnly(container) {
    var count = 0;
    try {
      for (var i = 0; i < container.pageItems.length; i++) {
        var item = container.pageItems[i];
        if (item.typename === "GroupItem") {
          try {
            item.selected = true;
            count++;
          } catch (selectError) {}
        } else if (item.pageItems) {
          count += selectGroupsOnly(item);
        }
      }
    } catch (e) {}
    return count;
  }

  function ungroupIfNeeded(doc, maxTimes) {
    for (var i = 0; i < maxTimes; i++) {
      cleanupDoc(doc);
      if (!hasGroupItem(doc)) return;
      app.selection = null;
      if (selectGroupsOnly(doc) === 0) return;
      if (!tryMenu("ungroup")) return;
    }
  }

  function outlineAndCopy(doc) {
    cleanupDoc(doc);
    tryMenu("selectall");
    tryMenu("expandStyle");
    tryMenu("expand");
    cleanupDoc(doc);
    if (!tryMenu("outline")) tryMenu("OffsetPath v22");
    cleanupDoc(doc);
    ungroupIfNeeded(doc, 3);
    cleanupDoc(doc);
    tryMenu("selectall");

    try {
      app.copy();
    } catch (e) {
      return "COPY_BACK_FAILED";
    }

    return "OK";
  }

  var oldAlerts = quietIllustratorAlerts();

  if (app.documents.length === 0) {
    app.documents.add(DocumentColorSpace.RGB, 1000, 1000);
  }

  try {
    app.paste();
  } catch (e) {
    restoreIllustratorAlerts(oldAlerts);
    alert("粘贴失败：剪贴板里没有 Illustrator 可识别的矢量内容。");
    return;
  }

  var result = outlineAndCopy(app.activeDocument);
  restoreIllustratorAlerts(oldAlerts);

  if (result === "COPY_BACK_FAILED") {
    alert("已轮廓化，但复制失败。请手动 Ctrl+C。");
    return;
  }

  alert("已轮廓化描边并复制到剪贴板。回 Photoshop 粘贴为“形状图层”。");
}());
