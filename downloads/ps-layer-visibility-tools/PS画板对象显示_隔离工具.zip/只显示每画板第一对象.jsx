#target photoshop

/*
Only show the first object in every artboard
Photoshop 2022-2025 compatible JSX script.

Menu name follows this file name: only-show-first-object-in-each-artboard in Chinese.

What it does:
1. Find artboards in the current document.
2. In each artboard, keep only the first direct child object visible.
3. Hide the other objects in those artboards.
4. Hide non-artboard top-level layers/groups.

"First object" means the topmost direct layer/group inside the artboard
as shown in Photoshop's Layers panel.

Shortcut:
Set it in Photoshop:
Edit > Keyboard Shortcuts > Application Menus > File > Scripts.
*/

app.bringToFront();

var __FAO_DOC = app.documents.length ? app.activeDocument : null;
var __FAO_SHOW_IDS = [];
var __FAO_HIDE_IDS = [];

(function () {
    if (!__FAO_DOC) {
        alert("Please open a Photoshop document first.");
        return;
    }

    __FAO_DOC.suspendHistory("只显示每个画板第一个对象", "__FAO_run()");
})();

function __FAO_run() {
    __FAO_collectDocument(__FAO_DOC);

    __FAO_SHOW_IDS = __FAO_uniqueNumbers(__FAO_SHOW_IDS);
    __FAO_HIDE_IDS = __FAO_uniqueNumbers(__FAO_HIDE_IDS);

    // Hide first, then show required parents/objects. This keeps selected targets
    // visible even if their parent state changed earlier in the operation.
    __FAO_setVisibleByIds(__FAO_HIDE_IDS, false);
    __FAO_setVisibleByIds(__FAO_SHOW_IDS, true);
}

function __FAO_collectDocument(doc) {
    for (var i = 0; i < doc.layers.length; i++) {
        var layer = doc.layers[i];

        if (__FAO_isArtboard(layer)) {
            __FAO_collectArtboard(layer);
        } else {
            // The command is artboard-focused. Top-level loose layers or groups
            // are hidden so the canvas only shows artboard first objects.
            __FAO_addHide(__FAO_getDomLayerId(layer), layer);
        }
    }
}

function __FAO_collectArtboard(artboard) {
    __FAO_addShow(__FAO_getDomLayerId(artboard), artboard);

    var firstObject = null;
    for (var i = 0; i < artboard.layers.length; i++) {
        if (!firstObject) {
            firstObject = artboard.layers[i];
            __FAO_collectVisibleSubtree(firstObject);
        } else {
            // Hiding a direct child group is enough; no need to touch all children.
            __FAO_addHide(__FAO_getDomLayerId(artboard.layers[i]), artboard.layers[i]);
        }
    }
}

function __FAO_collectVisibleSubtree(layer) {
    __FAO_addShow(__FAO_getDomLayerId(layer), layer);

    if (layer.typename === "LayerSet") {
        for (var i = 0; i < layer.layers.length; i++) {
            __FAO_collectVisibleSubtree(layer.layers[i]);
        }
    }
}

function __FAO_isArtboard(layer) {
    if (!layer || layer.typename !== "LayerSet") {
        return false;
    }

    try {
        var id = __FAO_getDomLayerId(layer);
        if (id === null) {
            return false;
        }

        var ref = new ActionReference();
        ref.putIdentifier(charIDToTypeID("Lyr "), Number(id));
        var desc = executeActionGet(ref);
        var key = stringIDToTypeID("artboardEnabled");

        if (desc.hasKey(key)) {
            return desc.getBoolean(key) === true;
        }
    } catch (e) {
        // Fall through to the conservative fallback below.
    }

    // Older Photoshop builds can be inconsistent through scripting. In artboard
    // documents, artboards are normally top-level layer sets.
    try {
        return layer.parent && layer.parent.typename === "Document";
    } catch (e2) {
        return false;
    }
}

function __FAO_addShow(id, layer) {
    if (id !== null) {
        try {
            if (layer && layer.visible === true) {
                return;
            }
        } catch (e) {
            // Keep the action if visibility cannot be read.
        }

        __FAO_SHOW_IDS.push(Number(id));
    }
}

function __FAO_addHide(id, layer) {
    if (id !== null) {
        try {
            if (layer && layer.visible === false) {
                return;
            }
        } catch (e) {
            // Keep the action if visibility cannot be read.
        }

        __FAO_HIDE_IDS.push(Number(id));
    }
}

function __FAO_setVisibleByIds(ids, visible) {
    if (!ids || ids.length === 0) {
        return;
    }

    var eventId = visible ? charIDToTypeID("Shw ") : charIDToTypeID("Hd  ");
    var chunkSize = 300;

    for (var start = 0; start < ids.length; start += chunkSize) {
        var desc = new ActionDescriptor();
        var list = new ActionList();

        for (var i = start; i < ids.length && i < start + chunkSize; i++) {
            var ref = new ActionReference();
            ref.putIdentifier(charIDToTypeID("Lyr "), Number(ids[i]));
            list.putReference(ref);
        }

        desc.putList(charIDToTypeID("null"), list);

        try {
            executeAction(eventId, desc, DialogModes.NO);
        } catch (e) {
            __FAO_setVisibleByIdsFallback(ids, visible);
            return;
        }
    }
}

function __FAO_setVisibleByIdsFallback(ids, visible) {
    for (var i = 0; i < ids.length; i++) {
        var layer = __FAO_findLayerById(__FAO_DOC, Number(ids[i]));
        if (layer) {
            try {
                layer.visible = visible;
            } catch (e) {
                // Some special layers can reject visibility changes. Skip safely.
            }
        }
    }
}

function __FAO_findLayerById(container, id) {
    for (var i = 0; i < container.layers.length; i++) {
        var layer = container.layers[i];
        if (__FAO_getDomLayerId(layer) === id) {
            return layer;
        }

        if (layer.typename === "LayerSet") {
            var found = __FAO_findLayerById(layer, id);
            if (found) {
                return found;
            }
        }
    }

    return null;
}

function __FAO_getDomLayerId(layer) {
    try {
        return Number(layer.id);
    } catch (e) {
        return null;
    }
}

function __FAO_uniqueNumbers(values) {
    var seen = {};
    var unique = [];

    for (var i = 0; i < values.length; i++) {
        var key = String(values[i]);
        if (!seen[key]) {
            seen[key] = true;
            unique.push(values[i]);
        }
    }

    return unique;
}
