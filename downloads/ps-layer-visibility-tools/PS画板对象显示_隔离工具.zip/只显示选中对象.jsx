#target photoshop

/*
Only show selected objects
Photoshop 2020-2025 compatible JSX script.

Menu name follows this file name: only-show-selected-objects in Chinese.

What it does:
1. Keep selected layers/groups visible.
2. Keep parent groups/artboards visible when they contain selected layers.
3. Hide every other layer/group/artboard.
4. If an entire artboard is selected, keep that artboard visible and hide the other artboards.

Shortcut:
Set it in Photoshop:
Edit > Keyboard Shortcuts > Application Menus > File > Scripts.
*/

app.bringToFront();

var __OSSL_DOC = app.documents.length ? app.activeDocument : null;
var __OSSL_SELECTED = {};
var __OSSL_SHOW_IDS = [];
var __OSSL_HIDE_IDS = [];

(function () {
    if (!__OSSL_DOC) {
        alert("Please open a Photoshop document first.");
        return;
    }

    var selectedIds = __OSSL_getSelectedLayerIds();
    if (!selectedIds || selectedIds.length === 0) {
        alert("Please select one or more layers first.");
        return;
    }

    for (var i = 0; i < selectedIds.length; i++) {
        __OSSL_SELECTED[String(selectedIds[i])] = true;
    }

    __OSSL_DOC.suspendHistory("只显示选中对象", "__OSSL_run()");
})();

function __OSSL_run() {
    __OSSL_collectContainer(__OSSL_DOC);

    __OSSL_HIDE_IDS = __OSSL_uniqueNumbers(__OSSL_HIDE_IDS);
    __OSSL_SHOW_IDS = __OSSL_uniqueNumbers(__OSSL_SHOW_IDS);

    // Use Photoshop's own hide/show actions instead of direct DOM visibility.
    // This makes the operation more likely to create a normal undo history state.
    __OSSL_setVisibleByIds(__OSSL_HIDE_IDS, false);
    __OSSL_setVisibleByIds(__OSSL_SHOW_IDS, true);
}

function __OSSL_collectContainer(container) {
    var hasSelected = false;

    for (var i = 0; i < container.layers.length; i++) {
        if (__OSSL_collectLayer(container.layers[i])) {
            hasSelected = true;
        }
    }

    return hasSelected;
}

function __OSSL_collectLayer(layer) {
    var id = __OSSL_getDomLayerId(layer);
    var isSelected = id !== null && __OSSL_SELECTED[String(id)] === true;

    if (layer.typename === "LayerSet") {
        if (isSelected) {
            // A selected artboard should behave like one complete selected object:
            // keep the artboard and its contents visible, hide sibling artboards.
            __OSSL_collectAllDescendants(layer, true);
            __OSSL_addShow(id, layer);
            return true;
        }

        var showStart = __OSSL_SHOW_IDS.length;
        var hideStart = __OSSL_HIDE_IDS.length;
        var containsSelected = __OSSL_collectContainer(layer);
        if (containsSelected) {
            __OSSL_addShow(id, layer);
            return true;
        }

        if (id !== null) {
            // If a whole group/artboard has no selected content, hiding the parent
            // is enough. Drop child operations to avoid long pauses in large files.
            __OSSL_SHOW_IDS.length = showStart;
            __OSSL_HIDE_IDS.length = hideStart;
            __OSSL_addHide(id, layer);
        }
        return false;
    }

    if (isSelected) {
        __OSSL_addShow(id, layer);
        return true;
    }

    __OSSL_addHide(id, layer);
    return false;
}

function __OSSL_collectAllDescendants(group, visible) {
    for (var i = 0; i < group.layers.length; i++) {
        var layer = group.layers[i];
        var id = __OSSL_getDomLayerId(layer);

        if (visible) {
            __OSSL_addShow(id, layer);
        } else {
            __OSSL_addHide(id, layer);
        }

        if (layer.typename === "LayerSet") {
            __OSSL_collectAllDescendants(layer, visible);
        }
    }
}

function __OSSL_addShow(id, layer) {
    if (id !== null) {
        try {
            if (layer && layer.visible === true) {
                return;
            }
        } catch (e) {
            // Keep the action if visibility cannot be read.
        }

        __OSSL_SHOW_IDS.push(Number(id));
    }
}

function __OSSL_addHide(id, layer) {
    if (id !== null) {
        try {
            if (layer && layer.visible === false) {
                return;
            }
        } catch (e) {
            // Keep the action if visibility cannot be read.
        }

        __OSSL_HIDE_IDS.push(Number(id));
    }
}

function __OSSL_setVisibleByIds(ids, visible) {
    if (!ids || ids.length === 0) {
        return;
    }

    var eventId = visible ? charIDToTypeID("Shw ") : charIDToTypeID("Hd  ");
    var chunkSize = 300;

    for (var start = 0; start < ids.length; start += chunkSize) {
        var desc = new ActionDescriptor();
        var list = new ActionList();

        for (var i = start; i < ids.length && i < start + chunkSize; i++) {
            var ref = new ActionReference();
            ref.putIdentifier(charIDToTypeID("Lyr "), Number(ids[i]));
            list.putReference(ref);
        }

        desc.putList(charIDToTypeID("null"), list);

        try {
            executeAction(eventId, desc, DialogModes.NO);
        } catch (e) {
            // Fall back to DOM changes for any Photoshop build that rejects a batch.
            __OSSL_setVisibleByIdsFallback(ids, visible);
            return;
        }
    }
}

function __OSSL_setVisibleByIdsFallback(ids, visible) {
    for (var i = 0; i < ids.length; i++) {
        var layer = __OSSL_findLayerById(__OSSL_DOC, Number(ids[i]));
        if (layer) {
            try {
                layer.visible = visible;
            } catch (e) {
                // Some special layers can reject visibility changes. Skip safely.
            }
        }
    }
}

function __OSSL_findLayerById(container, id) {
    for (var i = 0; i < container.layers.length; i++) {
        var layer = container.layers[i];
        if (__OSSL_getDomLayerId(layer) === id) {
            return layer;
        }

        if (layer.typename === "LayerSet") {
            var found = __OSSL_findLayerById(layer, id);
            if (found) {
                return found;
            }
        }
    }

    return null;
}

function __OSSL_getDomLayerId(layer) {
    try {
        return Number(layer.id);
    } catch (e) {
        return null;
    }
}

function __OSSL_getSelectedLayerIds() {
    var ids = [];
    var stringId = stringIDToTypeID;
    var charId = charIDToTypeID;

    try {
        var ref = new ActionReference();
        ref.putProperty(stringId("property"), stringId("targetLayersIDs"));
        ref.putEnumerated(stringId("document"), stringId("ordinal"), stringId("targetEnum"));

        var desc = executeActionGet(ref);
        if (desc.hasKey(stringId("targetLayersIDs"))) {
            var list = desc.getList(stringId("targetLayersIDs"));

            for (var i = 0; i < list.count; i++) {
                var layerRef = list.getReference(i);
                var layerId = null;

                try {
                    layerId = layerRef.getIdentifier(stringId("layerID"));
                } catch (e1) {
                    try {
                        layerId = layerRef.getIdentifier();
                    } catch (e2) {
                        layerId = null;
                    }
                }

                if (layerId !== null) {
                    ids.push(Number(layerId));
                }
            }
        }
    } catch (e3) {
        ids = [];
    }

    if (ids.length === 0) {
        try {
            var singleRef = new ActionReference();
            singleRef.putProperty(charId("Prpr"), charId("LyrI"));
            singleRef.putEnumerated(charId("Lyr "), charId("Ordn"), charId("Trgt"));
            ids.push(Number(executeActionGet(singleRef).getInteger(charId("LyrI"))));
        } catch (e4) {
            // No active layer.
        }
    }

    // Photoshop can report an artboard-title click as the active layer without
    // including it in targetLayersIDs on some builds. Add activeLayer as a
    // fallback so selecting a whole artboard also works.
    try {
        var activeId = __OSSL_getDomLayerId(__OSSL_DOC.activeLayer);
        if (activeId !== null && __OSSL_isArtboardLayer(__OSSL_DOC.activeLayer)) {
            ids.push(Number(activeId));
        }
    } catch (e5) {
        // No active layer or artboard state unavailable.
    }

    return __OSSL_uniqueNumbers(ids);
}

function __OSSL_isArtboardLayer(layer) {
    if (!layer || layer.typename !== "LayerSet") {
        return false;
    }

    try {
        var id = __OSSL_getDomLayerId(layer);
        if (id === null) {
            return false;
        }

        var ref = new ActionReference();
        ref.putIdentifier(charIDToTypeID("Lyr "), Number(id));
        var desc = executeActionGet(ref);
        var key = stringIDToTypeID("artboardEnabled");

        if (desc.hasKey(key)) {
            return desc.getBoolean(key) === true;
        }
    } catch (e) {
        return false;
    }

    return false;
}

function __OSSL_uniqueNumbers(values) {
    var seen = {};
    var unique = [];

    for (var i = 0; i < values.length; i++) {
        var key = String(values[i]);
        if (!seen[key]) {
            seen[key] = true;
            unique.push(values[i]);
        }
    }

    return unique;
}
