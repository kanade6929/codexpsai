#target photoshop

/*
Show all objects
Photoshop 2022-2025 compatible JSX script.

Menu name follows this file name: show-all-objects in Chinese.

What it does:
1. Show every artboard.
2. Show every group.
3. Show every normal layer.

Shortcut:
Set it in Photoshop:
Edit > Keyboard Shortcuts > Application Menus > File > Scripts.
*/

app.bringToFront();

var __SAO_DOC = app.documents.length ? app.activeDocument : null;
var __SAO_SHOW_IDS = [];

(function () {
    if (!__SAO_DOC) {
        alert("Please open a Photoshop document first.");
        return;
    }

    __SAO_DOC.suspendHistory("显示所有对象", "__SAO_run()");
})();

function __SAO_run() {
    __SAO_collectContainer(__SAO_DOC);
    __SAO_SHOW_IDS = __SAO_uniqueNumbers(__SAO_SHOW_IDS);

    // Use Photoshop's own show action instead of direct DOM visibility.
    // This makes the operation more likely to create a normal undo history state.
    __SAO_setVisibleByIds(__SAO_SHOW_IDS, true);
}

function __SAO_collectContainer(container) {
    for (var i = 0; i < container.layers.length; i++) {
        __SAO_collectLayer(container.layers[i]);
    }
}

function __SAO_collectLayer(layer) {
    var id = __SAO_getDomLayerId(layer);
    if (id !== null) {
        try {
            if (layer.visible === false) {
                __SAO_SHOW_IDS.push(Number(id));
            }
        } catch (e) {
            __SAO_SHOW_IDS.push(Number(id));
        }
    }

    if (layer.typename === "LayerSet") {
        __SAO_collectContainer(layer);
    }
}

function __SAO_setVisibleByIds(ids, visible) {
    if (!ids || ids.length === 0) {
        return;
    }

    var eventId = visible ? charIDToTypeID("Shw ") : charIDToTypeID("Hd  ");
    var chunkSize = 300;

    for (var start = 0; start < ids.length; start += chunkSize) {
        var desc = new ActionDescriptor();
        var list = new ActionList();

        for (var i = start; i < ids.length && i < start + chunkSize; i++) {
            var ref = new ActionReference();
            ref.putIdentifier(charIDToTypeID("Lyr "), Number(ids[i]));
            list.putReference(ref);
        }

        desc.putList(charIDToTypeID("null"), list);

        try {
            executeAction(eventId, desc, DialogModes.NO);
        } catch (e) {
            __SAO_setVisibleByIdsFallback(ids, visible);
            return;
        }
    }
}

function __SAO_setVisibleByIdsFallback(ids, visible) {
    for (var i = 0; i < ids.length; i++) {
        var layer = __SAO_findLayerById(__SAO_DOC, Number(ids[i]));
        if (layer) {
            try {
                layer.visible = visible;
            } catch (e) {
                // Some special layers can reject visibility changes. Skip safely.
            }
        }
    }
}

function __SAO_findLayerById(container, id) {
    for (var i = 0; i < container.layers.length; i++) {
        var layer = container.layers[i];
        if (__SAO_getDomLayerId(layer) === id) {
            return layer;
        }

        if (layer.typename === "LayerSet") {
            var found = __SAO_findLayerById(layer, id);
            if (found) {
                return found;
            }
        }
    }

    return null;
}

function __SAO_getDomLayerId(layer) {
    try {
        return Number(layer.id);
    } catch (e) {
        return null;
    }
}

function __SAO_uniqueNumbers(values) {
    var seen = {};
    var unique = [];

    for (var i = 0; i < values.length; i++) {
        var key = String(values[i]);
        if (!seen[key]) {
            seen[key] = true;
            unique.push(values[i]);
        }
    }

    return unique;
}
