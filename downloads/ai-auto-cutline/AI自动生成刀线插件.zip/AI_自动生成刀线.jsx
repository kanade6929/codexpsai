#target illustrator

/*
  AI_自动生成刀线.jsx

  用途：
  - 在 Illustrator 中智能识别图层并自动生成刀线。
  - 默认生成 CutContour 专色描边，适合给印刷/制作文件单独输出刀线层。

  使用：
  1. 打开 Illustrator 文件。
  2. 可直接选中画布里的图片/对象，脚本会自动使用它所在的图层。
     如果没有选中对象，则使用当前活动图层。
  3. 文件 > 脚本 > 其它脚本...，选择本脚本。
*/

(function () {
  var STROKE_WIDTH_PREF_KEY = "zhou.dieline.strokeWidthPt";
  var DEFAULT_STROKE_WIDTH_PT = 0.85;
  var DEFAULT_OFFSET_MM = 3;
  var DEFAULT_ROUND_RADIUS_MM = 1;
  var DEFAULT_SIMPLIFY_TOLERANCE_MM = 0.5;
  var MAX_SOURCE_LIST_ITEMS = 350;

  if (app.documents.length === 0) {
    alert("请先在 Illustrator 中打开一个文件。");
    return;
  }

  var doc = app.activeDocument;
  var sourceInfo = getSmartSourceInfo(doc);
  var ui = showDialog(doc, sourceInfo);
  if (!ui) return;

  var sourceTarget = ui.sourceTarget;
  var offsetPt = mmToPt(ui.offsetMm) * (ui.direction === "inside" ? -1 : 1);
  var strokeWidthPt = ui.strokeWidthPt;
  var cutLayer = ensureLayer(doc, ui.layerName);

  if (ui.clearOld && isSameLayerSource(sourceTarget, cutLayer)) {
    alert("源图层和刀线图层相同时，不能清空刀线图层。请换一个刀线图层名。");
    return;
  }

  if (ui.clearOld) {
    clearLayer(cutLayer);
  }

  var color = ui.useSpot
    ? getOrCreateSpotColor(doc, ui.spotName, ui.cmyk)
    : makeCutCmykColor(ui.cmyk);

  try {
    doc.selection = null;

    if (ui.mode === "bounds") {
      createBoundsDieline(doc, sourceTarget, cutLayer, offsetPt, ui.cornerMm, color, strokeWidthPt, ui.roundCorners, ui.roundRadiusPt, ui.simplifyAnchors, ui.simplifyTolerancePt);
    } else {
      createSmartDieline(doc, sourceTarget, cutLayer, offsetPt, color, strokeWidthPt, ui.roundCorners, ui.roundRadiusPt, ui.simplifyAnchors, ui.simplifyTolerancePt);
    }

    saveStrokeWidthPreference(strokeWidthPt);

    alert("刀线已生成到图层：" + cutLayer.name);
  } catch (err) {
    alert("生成失败：\n" + err.message);
  }

  function showDialog(docRef, sourceInfoRef) {
    var sourceData = createSourceListData();
    collectSourcesForList(docRef, sourceData);
    var sourceNames = sourceData.names;
    var sourceTargets = sourceData.targets;
    var selectedSourceIndex = findSourceIndex(sourceTargets, sourceInfoRef.target);

    var win = new Window("dialog", "自动生成刀线");
    win.alignChildren = "fill";

    var sourceGroup = win.add("panel", undefined, "智能来源");
    sourceGroup.alignChildren = "left";
    sourceGroup.add("statictext", undefined, sourceInfoRef.message);
    sourceGroup.add("statictext", undefined, getCompatibilityText());
    sourceGroup.add("statictext", undefined, "需要时可手动选择图层、图片、组或对象：");
    if (sourceData.truncated) {
      sourceGroup.add("statictext", undefined, "来源太多，已只显示前 " + MAX_SOURCE_LIST_ITEMS + " 项；建议先选中目标对象再运行。");
    }
    var sourceList = sourceGroup.add("dropdownlist", undefined, sourceNames);
    sourceList.selection = selectedSourceIndex;
    sourceList.preferredSize.width = 330;

    var modeGroup = win.add("panel", undefined, "刀线方式");
    modeGroup.alignChildren = "left";
    var smartRadio = modeGroup.add("radiobutton", undefined, "智能异形刀线（矢量/位图自动识别）");
    var boundsRadio = modeGroup.add("radiobutton", undefined, "按图层/选区外接框");
    smartRadio.value = true;

    var directionGroup = win.add("panel", undefined, "生成方向");
    directionGroup.alignChildren = "left";
    var outsideRadio = directionGroup.add("radiobutton", undefined, "向外生成");
    var insideRadio = directionGroup.add("radiobutton", undefined, "向内生成");
    outsideRadio.value = true;

    var inputGroup = win.add("panel", undefined, "参数");
    inputGroup.alignChildren = "left";

    var offsetGroup = inputGroup.add("group");
    offsetGroup.add("statictext", undefined, "偏移距离 mm：");
    var offsetInput = offsetGroup.add("edittext", undefined, String(DEFAULT_OFFSET_MM));
    offsetInput.characters = 8;

    var strokeGroup = inputGroup.add("group");
    strokeGroup.add("statictext", undefined, "刀线线宽 pt：");
    var strokeInput = strokeGroup.add("edittext", undefined, formatNumber(getStrokeWidthPreference()));
    strokeInput.characters = 8;

    var colorGroup = inputGroup.add("group");
    colorGroup.add("statictext", undefined, "刀线颜色 CMYK：");
    var cyanInput = colorGroup.add("edittext", undefined, "0");
    cyanInput.characters = 4;
    colorGroup.add("statictext", undefined, "C");
    var magentaInput = colorGroup.add("edittext", undefined, "87");
    magentaInput.characters = 4;
    colorGroup.add("statictext", undefined, "M");
    var yellowInput = colorGroup.add("edittext", undefined, "89");
    yellowInput.characters = 4;
    colorGroup.add("statictext", undefined, "Y");
    var blackInput = colorGroup.add("edittext", undefined, "9");
    blackInput.characters = 4;
    colorGroup.add("statictext", undefined, "K");

    var cornerGroup = inputGroup.add("group");
    cornerGroup.add("statictext", undefined, "外接框圆角 mm：");
    var cornerInput = cornerGroup.add("edittext", undefined, "0");
    cornerInput.characters = 8;

    var roundGroup = inputGroup.add("group");
    var roundCheck = roundGroup.add("checkbox", undefined, "生成圆角刀线");
    roundCheck.value = false;
    roundGroup.add("statictext", undefined, "圆角半径 mm：");
    var roundInput = roundGroup.add("edittext", undefined, String(DEFAULT_ROUND_RADIUS_MM));
    roundInput.characters = 8;

    var simplifyGroup = inputGroup.add("group");
    var simplifyCheck = simplifyGroup.add("checkbox", undefined, "简化锚点");
    simplifyCheck.value = true;
    simplifyGroup.add("statictext", undefined, "最小间距 mm：");
    var simplifyInput = simplifyGroup.add("edittext", undefined, String(DEFAULT_SIMPLIFY_TOLERANCE_MM));
    simplifyInput.characters = 8;

    var layerGroup = inputGroup.add("group");
    layerGroup.add("statictext", undefined, "刀线图层名：");
    var layerInput = layerGroup.add("edittext", undefined, "刀线");
    layerInput.characters = 16;

    var spotGroup = inputGroup.add("group");
    var spotCheck = spotGroup.add("checkbox", undefined, "使用专色");
    spotCheck.value = true;
    var spotInput = spotGroup.add("edittext", undefined, "CutContour");
    spotInput.characters = 16;

    var clearCheck = inputGroup.add("checkbox", undefined, "生成前清空同名刀线图层");
    clearCheck.value = false;

    var btns = win.add("group");
    btns.alignment = "right";
    btns.add("button", undefined, "取消", { name: "cancel" });
    btns.add("button", undefined, "生成", { name: "ok" });

    if (win.show() !== 1) return null;

    var offsetMm = parseFloat(offsetInput.text);
    var strokeWidth = parseFloat(strokeInput.text);
    var cornerMm = parseFloat(cornerInput.text);
    var roundRadiusMm = parseFloat(roundInput.text);
    var simplifyToleranceMm = parseFloat(simplifyInput.text);
    var cmyk = {
      cyan: parseCmykValue(cyanInput.text),
      magenta: parseCmykValue(magentaInput.text),
      yellow: parseCmykValue(yellowInput.text),
      black: parseCmykValue(blackInput.text)
    };

    if (isNaN(offsetMm) || offsetMm < 0) {
      alert("偏移距离请输入大于等于 0 的数字。");
      return null;
    }
    if (isNaN(strokeWidth) || strokeWidth <= 0) {
      alert("刀线线宽请输入大于 0 的数字。");
      return null;
    }
    if (!isValidCmyk(cmyk)) {
      alert("刀线颜色请输入 0 到 100 之间的 CMYK 数值。");
      return null;
    }
    if (isNaN(cornerMm) || cornerMm < 0) {
      alert("外接框圆角请输入大于等于 0 的数字。");
      return null;
    }
    if (roundCheck.value && (isNaN(roundRadiusMm) || roundRadiusMm <= 0)) {
      alert("圆角半径请输入大于 0 的数字。");
      return null;
    }
    if (simplifyCheck.value && (isNaN(simplifyToleranceMm) || simplifyToleranceMm <= 0)) {
      alert("锚点最小间距请输入大于 0 的数字。");
      return null;
    }
    if (!layerInput.text) {
      alert("请填写刀线图层名。");
      return null;
    }
    if (spotCheck.value && !spotInput.text) {
      alert("请填写专色名。");
      return null;
    }
    if (!sourceList.selection) {
      alert("请选择来源。");
      return null;
    }
    if (clearCheck.value && isSameLayerNameSource(sourceTargets[sourceList.selection.index], layerInput.text)) {
      alert("来源图层和刀线图层同名时，不能勾选“生成前清空同名刀线图层”。");
      return null;
    }

    return {
      sourceTarget: sourceTargets[sourceList.selection.index],
      mode: boundsRadio.value ? "bounds" : "smart",
      direction: insideRadio.value ? "inside" : "outside",
      offsetMm: offsetMm,
      strokeWidthPt: strokeWidth,
      cmyk: cmyk,
      cornerMm: cornerMm,
      roundCorners: roundCheck.value,
      roundRadiusPt: mmToPt(roundRadiusMm),
      simplifyAnchors: simplifyCheck.value,
      simplifyTolerancePt: mmToPt(simplifyToleranceMm),
      layerName: layerInput.text,
      useSpot: spotCheck.value,
      spotName: spotInput.text,
      clearOld: clearCheck.value
    };
  }

  function createSourceListData() {
    return {
      names: [],
      targets: [],
      truncated: false
    };
  }

  function collectSourcesForList(docRef, data) {
    var selectedItems = getCurrentSelectionItems(docRef);
    if (selectedItems.length > 0) {
      addSourceOption(data, "[当前选中对象] " + selectedItems.length + " 个对象", {
        kind: "selection",
        items: selectedItems,
        name: "当前选中对象"
      });
    }

    collectLayerSources(docRef.layers, 0, data);
  }

  function addSourceOption(data, name, target) {
    if (data.targets.length >= MAX_SOURCE_LIST_ITEMS) {
      data.truncated = true;
      return false;
    }

    data.names.push(name);
    data.targets.push(target);
    return true;
  }

  function collectLayerSources(layers, depth, data) {
    for (var i = 0; i < layers.length; i++) {
      if (data.truncated) return;

      var layer = layers[i];
      addSourceOption(data, makeSourceIndent(depth) + "[图层] " + layer.name, {
        kind: "layer",
        layer: layer,
        name: layer.name
      });

      collectPageItemSources(layer.pageItems, depth + 1, data, layer);

      if (layer.layers && layer.layers.length > 0) {
        collectLayerSources(layer.layers, depth + 1, data);
      }
    }
  }

  function collectPageItemSources(pageItems, depth, data, ownerLayer) {
    for (var i = 0; i < pageItems.length; i++) {
      if (data.truncated) return;

      var item = pageItems[i];
      if (!item) continue;

      try {
        if (item.parent !== ownerLayer) continue;
      } catch (e) {}

      addSourceOption(data, makeSourceIndent(depth) + "[" + getItemTypeLabel(item) + "] " + getItemDisplayName(item, i), {
        kind: "item",
        item: item,
        name: getItemDisplayName(item, i)
      });

      if (item.pageItems && item.pageItems.length > 0) {
        collectNestedPageItemSources(item.pageItems, depth + 1, data);
      }
    }
  }

  function collectNestedPageItemSources(pageItems, depth, data) {
    for (var i = 0; i < pageItems.length; i++) {
      if (data.truncated) return;

      var item = pageItems[i];
      if (!item) continue;

      addSourceOption(data, makeSourceIndent(depth) + "[" + getItemTypeLabel(item) + "] " + getItemDisplayName(item, i), {
        kind: "item",
        item: item,
        name: getItemDisplayName(item, i)
      });

      if (item.pageItems && item.pageItems.length > 0) {
        collectNestedPageItemSources(item.pageItems, depth + 1, data);
      }
    }
  }

  function makeSourceIndent(depth) {
    var text = "";
    for (var i = 0; i < depth; i++) {
      text += "  > ";
    }
    return text;
  }

  function findSourceIndex(targets, target) {
    for (var i = 0; i < targets.length; i++) {
      if (isSameSource(targets[i], target)) return i;
    }
    return 0;
  }

  function isSameSource(a, b) {
    if (!a || !b || a.kind !== b.kind) return false;
    if (a.kind === "layer") return a.layer === b.layer;
    if (a.kind === "item") return a.item === b.item;
    if (a.kind === "selection") return b.kind === "selection";
    return false;
  }

  function getItemTypeLabel(item) {
    try {
      if (item.typename === "PlacedItem" || item.typename === "RasterItem") return "图片";
      if (item.typename === "GroupItem") return item.clipped ? "剪贴组" : "组";
      if (item.typename === "CompoundPathItem") return "复合路径";
      if (item.typename === "PathItem") return "路径";
      if (item.typename === "TextFrame") return "文字";
      if (item.typename === "SymbolItem") return "符号";
    } catch (e) {}
    return "对象";
  }

  function getItemDisplayName(item, index) {
    try {
      if (item.name) return item.name;
    } catch (e) {}
    return getItemTypeLabel(item) + " " + (index + 1);
  }

  function getSmartSourceInfo(docRef) {
    var selectedItems = getCurrentSelectionItems(docRef);
    if (selectedItems.length > 0) {
      return {
        target: {
          kind: "selection",
          items: selectedItems,
          name: "当前选中对象"
        },
        message: "已检测到选中对象，将优先使用当前选中对象"
      };
    }

    return {
      target: {
        kind: "layer",
        layer: docRef.activeLayer,
        name: docRef.activeLayer.name
      },
      message: "未检测到可用选中对象，将使用当前活动图层：「" + docRef.activeLayer.name + "」"
    };
  }

  function getCompatibilityText() {
    var versionText = "";
    try {
      versionText = app.version;
    } catch (e) {}

    if (!versionText) return "主要适配 Illustrator 2020-2025。";

    var major = parseInt(versionText, 10);
    if (!isNaN(major) && (major < 24 || major > 29)) {
      return "当前 AI 版本：" + versionText + "；脚本主要适配 2020-2025。";
    }

    return "当前 AI 版本：" + versionText + "；适配 2020-2025。";
  }

  function getCurrentSelectionItems(docRef) {
    var result = [];
    if (!docRef.selection || docRef.selection.length === 0) return result;
    for (var i = 0; i < docRef.selection.length; i++) {
      result.push(docRef.selection[i]);
    }
    return filterUsableItems(result);
  }

  function createSmartDieline(docRef, sourceTargetRef, cutLayerRef, offsetPtRef, colorRef, strokeWidthRef, roundCornersRef, roundRadiusPtRef, simplifyAnchorsRef, simplifyTolerancePtRef) {
    var sourceItems = getSourceItems(sourceTargetRef);
    if (sourceItems.length === 0) {
      throw new Error("来源里没有找到可处理的对象，或对象被锁定/隐藏。");
    }

    if (hasRasterArtwork(sourceItems)) {
      createTraceDieline(docRef, sourceTargetRef, cutLayerRef, offsetPtRef, colorRef, strokeWidthRef, roundCornersRef, roundRadiusPtRef, simplifyAnchorsRef, simplifyTolerancePtRef);
    } else {
      createVectorDieline(docRef, sourceTargetRef, cutLayerRef, offsetPtRef, colorRef, strokeWidthRef, roundCornersRef, roundRadiusPtRef, simplifyAnchorsRef, simplifyTolerancePtRef);
    }
  }

  function createVectorDieline(docRef, sourceTargetRef, cutLayerRef, offsetPtRef, colorRef, strokeWidthRef, roundCornersRef, roundRadiusPtRef, simplifyAnchorsRef, simplifyTolerancePtRef) {
    var sourceItems = getSourceItems(sourceTargetRef);
    if (sourceItems.length === 0) {
      throw new Error("源图层里没有找到可处理的对象，或图层被锁定/隐藏。");
    }

    var tempLayer = docRef.layers.add();
    tempLayer.name = "__临时刀线_" + new Date().getTime();

    try {
      var duplicated = duplicateItemsToLayer(sourceItems, tempLayer);
      if (duplicated.length === 0) {
        throw new Error("对象可能被锁定或隐藏，无法复制生成刀线。");
      }

      docRef.selection = null;
      selectItems(duplicated);

      tryMenu("group");
      tryMenu("expandStyle");
      tryMenu("expand");
      tryMenu("outline");
      tryMenu("Live Pathfinder Add");
      tryMenu("expandStyle");

      var selected = getSelectedItems(docRef);
      if (selected.length === 0) {
        throw new Error("合并轮廓后没有得到可用路径。");
      }

      applyOffsetToItems(selected, offsetPtRef);
      tryMenu("expandStyle");
      tryMenu("ungroup");
      tryMenu("ungroup");
      finalizeCurrentDielineSelection(
        docRef,
        cutLayerRef,
        colorRef,
        strokeWidthRef,
        roundCornersRef,
        roundRadiusPtRef,
        simplifyAnchorsRef,
        simplifyTolerancePtRef,
        "偏移后没有生成刀线路径。"
      );
    } finally {
      try {
        tempLayer.remove();
      } catch (cleanupErr) {}
    }
  }

  function createTraceDieline(docRef, sourceTargetRef, cutLayerRef, offsetPtRef, colorRef, strokeWidthRef, roundCornersRef, roundRadiusPtRef, simplifyAnchorsRef, simplifyTolerancePtRef) {
    var sourceItems = getSourceItems(sourceTargetRef);
    if (sourceItems.length === 0) {
      throw new Error("来源里没有找到可处理的对象，或对象被锁定/隐藏。");
    }

    var tempLayer = docRef.layers.add();
    tempLayer.name = "__临时异形刀线_" + new Date().getTime();

    try {
      var duplicated = duplicateItemsToLayer(sourceItems, tempLayer);
      if (duplicated.length === 0) {
        throw new Error("对象可能被锁定或隐藏，无法复制生成刀线。");
      }

      docRef.selection = null;
      selectItems(duplicated);

      if (!traceRasterItemsWithApi(duplicated)) {
        traceSelectedArtwork();
      }
      tryMenu("expandStyle");
      tryMenu("expand");
      tryMenu("ungroup");
      tryMenu("ungroup");

      var tracedItems = getSelectedItems(docRef);
      if (tracedItems.length === 0) {
        tracedItems = getLayerTopItems(tempLayer);
        docRef.selection = null;
        selectItems(tracedItems);
      }

      if (tracedItems.length === 0) {
        throw new Error("图像描摹后没有得到可用轮廓。请确认图片有透明区域，或先在 AI 里手动图像描摹并扩展。");
      }

      tryMenu("group");
      tryMenu("expandStyle");
      tryMenu("expand");
      tryMenu("Live Pathfinder Add");
      tryMenu("expandStyle");

      var selected = getSelectedItems(docRef);
      if (selected.length === 0) {
        selected = getLayerTopItems(tempLayer);
        docRef.selection = null;
        selectItems(selected);
      }

      applyOffsetToItems(selected, offsetPtRef);
      tryMenu("expandStyle");
      tryMenu("ungroup");
      tryMenu("ungroup");
      finalizeCurrentDielineSelection(
        docRef,
        cutLayerRef,
        colorRef,
        strokeWidthRef,
        roundCornersRef,
        roundRadiusPtRef,
        simplifyAnchorsRef,
        simplifyTolerancePtRef,
        "异形轮廓偏移后没有生成刀线路径。"
      );
    } finally {
      try {
        tempLayer.remove();
      } catch (cleanupErr) {}
    }
  }

  function traceRasterItemsWithApi(items) {
    var traced = false;
    var expanded = false;
    for (var i = 0; i < items.length; i++) {
      var result = traceRasterItemTree(items[i]);
      traced = result.traced || traced;
      expanded = result.expanded || expanded;
    }

    if (traced) {
      try {
        app.redraw();
      } catch (e) {}
    }

    return traced && expanded;
  }

  function traceRasterItemTree(item) {
    if (!item) return { traced: false, expanded: false };

    var traced = false;
    var expanded = false;
    try {
      if (item.typename === "PlacedItem" || item.typename === "RasterItem") {
        var pluginItem = item.trace();
        traced = true;
        configureTraceOptions(pluginItem);
        try {
          app.redraw();
        } catch (redrawErr) {}
        try {
          pluginItem.tracing.expandTracing(false);
          expanded = true;
        } catch (expandErr) {}
        return { traced: traced, expanded: expanded };
      }
    } catch (traceErr) {}

    if (item.pageItems) {
      for (var i = 0; i < item.pageItems.length; i++) {
        var childResult = traceRasterItemTree(item.pageItems[i]);
        traced = childResult.traced || traced;
        expanded = childResult.expanded || expanded;
      }
    }

    return { traced: traced, expanded: expanded };
  }

  function configureTraceOptions(pluginItem) {
    try {
      var options = pluginItem.tracing.tracingOptions;
      options.fills = true;
      options.strokes = false;
      options.pathFitting = 1;
      options.cornerAngle = 20;
      options.minArea = 1;
      options.tracingColors = 256;
      options.maxColors = 256;

      try {
        options.tracingMode = TracingModeType.TRACINGMODECOLOR;
      } catch (modeErr) {}

      try {
        options.tracingColorTypeValue = TracingColorType.TRACINGFULLCOLOR;
      } catch (colorErr) {}

      try {
        options.tracingMethod = TracingMethodType.TRACINGMETHODABUTTING;
      } catch (methodErr) {}
    } catch (e) {}
  }

  function traceSelectedArtwork() {
    var ok = false;
    ok = tryMenu("Live Trace") || ok;
    ok = tryMenu("Image Trace") || ok;
    ok = tryMenu("Tracing Preset Default") || ok;

    if (!ok) {
      try {
        app.executeMenuCommand("Live Trace");
        ok = true;
      } catch (e) {}
    }

    tryMenu("expandStyle");
    tryMenu("expand");
    return ok;
  }

  function hasRasterArtwork(items) {
    for (var i = 0; i < items.length; i++) {
      if (containsRasterArtwork(items[i])) return true;
    }
    return false;
  }

  function containsRasterArtwork(item) {
    if (!item) return false;

    try {
      if (item.typename === "PlacedItem" || item.typename === "RasterItem") return true;
    } catch (e) {}

    if (item.pageItems) {
      for (var i = 0; i < item.pageItems.length; i++) {
        if (containsRasterArtwork(item.pageItems[i])) return true;
      }
    }

    return false;
  }

  function createBoundsDieline(docRef, sourceTargetRef, cutLayerRef, offsetPtRef, cornerMmRef, colorRef, strokeWidthRef, roundCornersRef, roundRadiusPtRef, simplifyAnchorsRef, simplifyTolerancePtRef) {
    var sourceItems = getSourceItems(sourceTargetRef);
    if (sourceItems.length === 0) {
      throw new Error("源图层里没有找到可处理的对象，或图层被锁定/隐藏。");
    }

    var b = getUnionVisibleBounds(sourceItems);
    if (!b) throw new Error("无法读取对象边界。");

    var left = b[0] - offsetPtRef;
    var top = b[1] + offsetPtRef;
    var right = b[2] + offsetPtRef;
    var bottom = b[3] - offsetPtRef;
    var width = right - left;
    var height = top - bottom;
    var cornerPt = mmToPt(cornerMmRef);
    if (roundCornersRef && roundRadiusPtRef > 0) {
      cornerPt = Math.max(cornerPt, roundRadiusPtRef);
    }

    if (width <= 0 || height <= 0) {
      throw new Error("向内偏移距离太大，刀线已经小于或等于 0。请减小偏移距离。");
    }

    var path;
    if (cornerPt > 0) {
      path = cutLayerRef.pathItems.roundedRectangle(top, left, width, height, cornerPt, cornerPt);
    } else {
      path = cutLayerRef.pathItems.rectangle(top, left, width, height);
    }

    styleAsDieline(path, colorRef, strokeWidthRef);
    path.selected = true;
  }

  function getSourceItems(sourceTargetRef) {
    if (!sourceTargetRef) return [];

    if (sourceTargetRef.kind === "selection") {
      return filterUsableItems(sourceTargetRef.items || []);
    }

    if (sourceTargetRef.kind === "item") {
      return filterUsableItems([sourceTargetRef.item]);
    }

    var layer = sourceTargetRef.layer;
    if (!layer || layer.locked || !layer.visible) return [];

    var items = [];
    collectSourceItems(layer, items);
    return filterUsableItems(items);
  }

  function isSameLayerSource(sourceTargetRef, layer) {
    return sourceTargetRef && sourceTargetRef.kind === "layer" && sourceTargetRef.layer === layer;
  }

  function isSameLayerNameSource(sourceTargetRef, layerName) {
    return sourceTargetRef && sourceTargetRef.kind === "layer" && sourceTargetRef.name === layerName;
  }

  function collectSourceItems(layer, items) {
    if (!layer || layer.locked || !layer.visible) return;

    for (var i = 0; i < layer.pageItems.length; i++) {
      var item = layer.pageItems[i];
      if (item.parent === layer) items.push(item);
    }

    for (var j = 0; j < layer.layers.length; j++) {
      collectSourceItems(layer.layers[j], items);
    }
  }

  function filterUsableItems(items) {
    var usable = [];
    for (var i = 0; i < items.length; i++) {
      var item = items[i];
      if (!item) continue;
      try {
        if (item.locked || item.hidden) continue;
        if (item.guides) continue;
        usable.push(item);
      } catch (e) {}
    }
    return usable;
  }

  function duplicateItemsToLayer(items, targetLayer) {
    var result = [];
    for (var i = 0; i < items.length; i++) {
      try {
        var copy = items[i].duplicate(targetLayer, ElementPlacement.PLACEATEND);
        copy.hidden = false;
        copy.locked = false;
        result.push(copy);
      } catch (e) {}
    }
    return result;
  }

  function selectItems(items) {
    for (var i = 0; i < items.length; i++) {
      try {
        items[i].selected = true;
      } catch (e) {}
    }
  }

  function getSelectedItems(docRef) {
    var result = [];
    for (var i = 0; i < docRef.selection.length; i++) {
      result.push(docRef.selection[i]);
    }
    return result;
  }

  function getLayerTopItems(layer) {
    var result = [];
    if (!layer || !layer.pageItems) return result;

    for (var i = 0; i < layer.pageItems.length; i++) {
      try {
        if (layer.pageItems[i].parent === layer) result.push(layer.pageItems[i]);
      } catch (e) {}
    }

    return result;
  }

  function applyOffsetToItems(items, offsetPtRef) {
    var xml = '<LiveEffect name="Adobe Offset Path"><Dict data="R mlim 4 R ofst ' +
      offsetPtRef +
      ' I jntp 1 "/></LiveEffect>';

    for (var i = 0; i < items.length; i++) {
      try {
        items[i].applyEffect(xml);
      } catch (e) {}
    }
  }

  function applyRoundCornersToCurrentSelection(docRef, enabled, radiusPtRef) {
    if (!enabled || !radiusPtRef || radiusPtRef <= 0) return;

    var selected = getSelectedItems(docRef);
    if (selected.length === 0) return;

    for (var i = 0; i < selected.length; i++) {
      applyRoundCornersToItem(selected[i], radiusPtRef);
    }

    tryMenu("expandStyle");
    tryMenu("expand");
    tryMenu("ungroup");
    tryMenu("ungroup");
  }

  function applyRoundCornersToItem(item, radiusPtRef) {
    if (!item) return;

    if (item.typename === "PathItem" || item.typename === "CompoundPathItem") {
      try {
        var xml = '<LiveEffect name="Adobe Round Corners"><Dict data="R radius ' +
          radiusPtRef +
          ' "/></LiveEffect>';
        item.applyEffect(xml);
      } catch (e) {}
      return;
    }

    if (item.pageItems) {
      for (var i = 0; i < item.pageItems.length; i++) {
        applyRoundCornersToItem(item.pageItems[i], radiusPtRef);
      }
    }
  }

  function finalizeCurrentDielineSelection(docRef, cutLayerRef, colorRef, strokeWidthRef, roundCornersRef, roundRadiusPtRef, simplifyAnchorsRef, simplifyTolerancePtRef, emptyMessage) {
    applyRoundCornersToCurrentSelection(docRef, roundCornersRef, roundRadiusPtRef);
    applyAnchorSimplifyToCurrentSelection(docRef, simplifyAnchorsRef, simplifyTolerancePtRef);

    var moved = moveSelectionToLayer(docRef, cutLayerRef);
    if (moved.length === 0) {
      throw new Error(emptyMessage);
    }

    for (var i = 0; i < moved.length; i++) {
      styleAsDieline(moved[i], colorRef, strokeWidthRef);
    }
  }

  function applyAnchorSimplifyToCurrentSelection(docRef, enabled, tolerancePtRef) {
    if (!enabled || !tolerancePtRef || tolerancePtRef <= 0) return;

    var selected = getSelectedItems(docRef);
    if (selected.length === 0) return;

    for (var i = 0; i < selected.length; i++) {
      simplifyItemAnchors(selected[i], tolerancePtRef);
    }
  }

  function simplifyItemAnchors(item, tolerancePtRef) {
    if (!item) return;

    if (item.typename === "PathItem") {
      simplifyPathItemAnchors(item, tolerancePtRef);
      return;
    }

    if (item.typename === "CompoundPathItem") {
      for (var c = 0; c < item.pathItems.length; c++) {
        simplifyPathItemAnchors(item.pathItems[c], tolerancePtRef);
      }
      return;
    }

    if (item.pageItems) {
      for (var i = 0; i < item.pageItems.length; i++) {
        simplifyItemAnchors(item.pageItems[i], tolerancePtRef);
      }
    }
  }

  function simplifyPathItemAnchors(pathItem, tolerancePtRef) {
    try {
      if (!pathItem.pathPoints || pathItem.pathPoints.length < 8) return;
    } catch (e) {
      return;
    }

    var minKeep = pathItem.closed ? 4 : 3;
    var pass = 0;
    var changed = true;

    while (changed && pass < 3) {
      changed = false;
      pass++;

      for (var i = pathItem.pathPoints.length - 1; i >= 0; i--) {
        var count = pathItem.pathPoints.length;
        if (count <= minKeep) return;
        if (!pathItem.closed && (i === 0 || i === count - 1)) continue;

        if (shouldRemoveAnchor(pathItem, i, tolerancePtRef)) {
          try {
            pathItem.pathPoints[i].remove();
            changed = true;
          } catch (removeErr) {}
        }
      }
    }
  }

  function shouldRemoveAnchor(pathItem, index, tolerancePtRef) {
    var points = pathItem.pathPoints;
    var count = points.length;
    if (count < 4) return false;

    var prevIndex = index - 1;
    var nextIndex = index + 1;
    if (pathItem.closed) {
      if (prevIndex < 0) prevIndex = count - 1;
      if (nextIndex >= count) nextIndex = 0;
    } else if (prevIndex < 0 || nextIndex >= count) {
      return false;
    }

    var prev = points[prevIndex];
    var curr = points[index];
    var next = points[nextIndex];
    var a = curr.anchor;
    var pa = prev.anchor;
    var na = next.anchor;

    var lenPrev = pointDistance(pa, a);
    var lenNext = pointDistance(a, na);
    if (lenPrev === 0 || lenNext === 0) return true;

    var angle = angleBetween(pa, a, na);
    var turn = Math.PI - angle;
    var hasStrongHandle = pointHasStrongHandle(curr, tolerancePtRef * 0.6);

    if (lenPrev < tolerancePtRef * 0.45 && lenNext < tolerancePtRef * 0.45) return true;
    if (hasStrongHandle && turn > 0.08) return false;
    if (turn < 0.16 && (lenPrev < tolerancePtRef || lenNext < tolerancePtRef)) return true;
    if (turn < 0.08 && (lenPrev + lenNext) < tolerancePtRef * 3) return true;

    return false;
  }

  function pointDistance(a, b) {
    var dx = a[0] - b[0];
    var dy = a[1] - b[1];
    return Math.sqrt(dx * dx + dy * dy);
  }

  function angleBetween(prevAnchor, currAnchor, nextAnchor) {
    var v1x = prevAnchor[0] - currAnchor[0];
    var v1y = prevAnchor[1] - currAnchor[1];
    var v2x = nextAnchor[0] - currAnchor[0];
    var v2y = nextAnchor[1] - currAnchor[1];
    var d1 = Math.sqrt(v1x * v1x + v1y * v1y);
    var d2 = Math.sqrt(v2x * v2x + v2y * v2y);
    if (d1 === 0 || d2 === 0) return Math.PI;

    var dot = (v1x * v2x + v1y * v2y) / (d1 * d2);
    if (dot > 1) dot = 1;
    if (dot < -1) dot = -1;
    return Math.acos(dot);
  }

  function pointHasStrongHandle(point, thresholdPtRef) {
    try {
      return pointDistance(point.anchor, point.leftDirection) > thresholdPtRef ||
        pointDistance(point.anchor, point.rightDirection) > thresholdPtRef;
    } catch (e) {
      return false;
    }
  }

  function moveSelectionToLayer(docRef, targetLayer) {
    var selected = getSelectedItems(docRef);
    var moved = [];

    for (var i = selected.length - 1; i >= 0; i--) {
      try {
        selected[i].move(targetLayer, ElementPlacement.PLACEATEND);
        moved.push(selected[i]);
      } catch (e) {}
    }

    docRef.selection = null;
    selectItems(moved);
    return moved;
  }

  function styleAsDieline(item, colorRef, strokeWidthRef) {
    try {
      item.hidden = false;
      item.locked = false;
    } catch (e) {}

    if (item.typename === "PathItem") {
      try {
        item.filled = false;
        item.stroked = true;
        item.strokeColor = colorRef;
        item.strokeWidth = strokeWidthRef;
      } catch (pathErr) {}
      return;
    }

    if (item.typename === "CompoundPathItem") {
      for (var c = 0; c < item.pathItems.length; c++) {
        styleAsDieline(item.pathItems[c], colorRef, strokeWidthRef);
      }
      return;
    }

    if (item.pageItems) {
      for (var i = 0; i < item.pageItems.length; i++) {
        styleAsDieline(item.pageItems[i], colorRef, strokeWidthRef);
      }
    }
  }

  function getUnionVisibleBounds(items) {
    var bounds = null;

    for (var i = 0; i < items.length; i++) {
      var b;
      try {
        b = items[i].visibleBounds;
      } catch (e) {
        continue;
      }

      if (!bounds) {
        bounds = [b[0], b[1], b[2], b[3]];
      } else {
        bounds[0] = Math.min(bounds[0], b[0]);
        bounds[1] = Math.max(bounds[1], b[1]);
        bounds[2] = Math.max(bounds[2], b[2]);
        bounds[3] = Math.min(bounds[3], b[3]);
      }
    }

    return bounds;
  }

  function ensureLayer(docRef, name) {
    var layer;
    try {
      layer = docRef.layers.getByName(name);
    } catch (e) {
      layer = docRef.layers.add();
      layer.name = name;
    }

    try {
      layer.visible = true;
      layer.locked = false;
    } catch (e2) {}

    return layer;
  }

  function clearLayer(layer) {
    for (var i = layer.pageItems.length - 1; i >= 0; i--) {
      try {
        layer.pageItems[i].remove();
      } catch (e) {}
    }
  }

  function parseCmykValue(text) {
    return parseFloat(text);
  }

  function getStrokeWidthPreference() {
    try {
      var saved = app.preferences.getRealPreference(STROKE_WIDTH_PREF_KEY);
      if (!isNaN(saved) && saved > 0) return saved;
    } catch (e) {}
    return DEFAULT_STROKE_WIDTH_PT;
  }

  function saveStrokeWidthPreference(value) {
    try {
      app.preferences.setRealPreference(STROKE_WIDTH_PREF_KEY, value);
    } catch (e) {}
  }

  function formatNumber(value) {
    var text = String(Math.round(value * 1000) / 1000);
    return text;
  }

  function isValidCmyk(cmyk) {
    return isValidPercent(cmyk.cyan) &&
      isValidPercent(cmyk.magenta) &&
      isValidPercent(cmyk.yellow) &&
      isValidPercent(cmyk.black);
  }

  function isValidPercent(value) {
    return !isNaN(value) && value >= 0 && value <= 100;
  }

  function getOrCreateSpotColor(docRef, name, cmyk) {
    var spot;
    try {
      spot = docRef.spots.getByName(name);
    } catch (e) {
      var c = makeCutCmykColor(cmyk);
      spot = docRef.spots.add();
      spot.name = name;
      spot.colorType = ColorModel.SPOT;
      spot.color = c;
    }

    var sc = new SpotColor();
    sc.spot = spot;
    sc.tint = 100;
    return sc;
  }

  function makeCutCmykColor(cmyk) {
    var c = new CMYKColor();
    c.cyan = cmyk ? cmyk.cyan : 0;
    c.magenta = cmyk ? cmyk.magenta : 87;
    c.yellow = cmyk ? cmyk.yellow : 89;
    c.black = cmyk ? cmyk.black : 9;
    return c;
  }

  function tryMenu(name) {
    try {
      app.executeMenuCommand(name);
      return true;
    } catch (e) {
      return false;
    }
  }

  function mmToPt(mm) {
    return mm * 2.834645669291339;
  }
}());
