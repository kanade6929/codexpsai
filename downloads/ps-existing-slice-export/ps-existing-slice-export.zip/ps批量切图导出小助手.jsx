#target photoshop

/*
One-click export current or all opened PSD/PSB documents.
Photoshop 2020-2026 compatible JSX script.

Output structure:
Single-document output:
  DocumentName.jpg/png
  切图
    DocumentName_slice_001.jpg/png

All-open-documents output:
  DocumentName
    DocumentName.jpg/png
    切图
      DocumentName_slice_001.jpg/png

Notes:
- Source PSD/PSB documents are not edited.
- JPG export adds a white background and uses quality 100.
- PNG export keeps transparency.
- Slice export uses existing Photoshop slices with Legacy Save for Web.
*/

app.bringToFront();

var __PDE_START_DOC = app.documents.length ? app.activeDocument : null;

(function () {
    if (!__PDE_START_DOC) {
        alert("请先打开一个 PSD 或 PSB 文档。");
        return;
    }

    var oldUnits = app.preferences.rulerUnits;
    var oldDialogs = app.displayDialogs;

    try {
        app.preferences.rulerUnits = Units.PIXELS;

        var settings = __PDE_chooseSettings(__PDE_START_DOC);
        if (!settings) {
            return;
        }

        var docs = settings.exportAll ? __PDE_collectPsdPsbDocuments() : [__PDE_START_DOC];
        docs = __PDE_filterExportableDocs(docs);

        if (!docs.length) {
            alert("没有找到可导出的 PSD / PSB 文档。");
            return;
        }

        app.displayDialogs = DialogModes.NO;
        var summary = __PDE_exportDocuments(docs, settings);

        var message = "导出完成：" + summary.exportedDocs + " 个文档。";
        message += "\n\n保存位置：\n" + settings.outputFolder.fsName;
        if (summary.sliceEnabled) {
            message += "\n\n切片导出：" + summary.exportedSlices + " 张。";
        }
        if (summary.skipped.length) {
            message += "\n\n提示：\n" + summary.skipped.join("\n");
        }
        if (summary.failed.length) {
            message += "\n\n失败：\n" + summary.failed.join("\n");
        }

        alert(message);
    } catch (e) {
        alert("导出失败：\n" + e.message);
    } finally {
        app.preferences.rulerUnits = oldUnits;
        app.displayDialogs = oldDialogs;
        try {
            app.activeDocument = __PDE_START_DOC;
        } catch (focusError) {
            // The original document may have been closed by the user.
        }
    }
})();

function __PDE_chooseSettings(startDoc) {
    try {
        var dialog = new Window("dialog", "ps批量/切图导出小助手");
        dialog.orientation = "column";
        dialog.alignChildren = "fill";
        dialog.margins = 18;

        var title = dialog.add("statictext", undefined, "导出当前文档，或导出 Photoshop 已打开的所有 PSD/PSB 文档");
        title.alignment = "left";

        var formatPanel = dialog.add("panel", undefined, "导出格式");
        formatPanel.orientation = "column";
        formatPanel.alignChildren = "left";
        formatPanel.margins = 14;

        var pngOption = formatPanel.add("radiobutton", undefined, "PNG（保留透明）");
        var jpgOption = formatPanel.add("radiobutton", undefined, "JPG（白色背景，质量 100）");
        pngOption.value = true;

        var optionPanel = dialog.add("panel", undefined, "导出范围");
        optionPanel.orientation = "column";
        optionPanel.alignChildren = "left";
        optionPanel.margins = 14;

        var allDocsOption = optionPanel.add("checkbox", undefined, "导出 Photoshop 当前打开的所有 PSD / PSB 页面");
        allDocsOption.value = false;
        optionPanel.add("statictext", undefined, "不勾选时，只导出当前停留的文档。");

        var sliceOption = optionPanel.add("checkbox", undefined, "同时导出现有 PS 切片图片文件夹（切图）");
        sliceOption.value = false;

        var folderPanel = dialog.add("panel", undefined, "导出目录");
        folderPanel.orientation = "row";
        folderPanel.alignChildren = ["fill", "center"];
        folderPanel.margins = 14;

        var defaultFolder = __PDE_defaultFolder(startDoc);
        var folderText = folderPanel.add("edittext", undefined, defaultFolder ? defaultFolder.fsName : "");
        folderText.characters = 42;
        var folderButton = folderPanel.add("button", undefined, "选择...");
        var selectedFolder = defaultFolder;

        folderButton.onClick = function () {
            var chosen = Folder.selectDialog("选择导出目录", selectedFolder || defaultFolder);
            if (chosen) {
                selectedFolder = chosen;
                folderText.text = chosen.fsName;
            }
        };

        var buttons = dialog.add("group");
        buttons.alignment = "right";
        var saveButton = buttons.add("button", undefined, "开始导出", { name: "ok" });
        var cancelButton = buttons.add("button", undefined, "取消", { name: "cancel" });

        saveButton.onClick = function () {
            if (!folderText.text) {
                alert("请先选择导出目录。");
                return;
            }

            selectedFolder = new Folder(folderText.text);
            if (!selectedFolder.exists && !selectedFolder.create()) {
                alert("无法创建导出目录：\n" + selectedFolder.fsName);
                return;
            }

            dialog.close(1);
        };
        cancelButton.onClick = function () {
            dialog.close(0);
        };

        if (dialog.show() !== 1) {
            return null;
        }

        return {
            format: jpgOption.value ? "jpg" : "png",
            exportAll: allDocsOption.value,
            exportSlices: sliceOption.value,
            outputFolder: selectedFolder
        };
    } catch (e) {
        var outputFolder = Folder.selectDialog("选择导出目录");
        if (!outputFolder) {
            return null;
        }

        var formatChoice = prompt("请输入导出格式：PNG 或 JPG", "PNG");
        if (formatChoice === null) {
            return null;
        }

        var allChoice = confirm("是否导出 Photoshop 当前打开的所有 PSD / PSB 页面？\n选择“否”则只导出当前文档。");
        var sliceChoice = confirm("是否同时导出现有 PS 切片图片文件夹（切图）？");

        formatChoice = String(formatChoice).replace(/^\s+|\s+$/g, "").toLowerCase();
        return {
            format: formatChoice === "jpg" || formatChoice === "jpeg" ? "jpg" : "png",
            exportAll: allChoice,
            exportSlices: sliceChoice,
            outputFolder: outputFolder
        };
    }
}

function __PDE_collectPsdPsbDocuments() {
    var docs = [];
    for (var i = 0; i < app.documents.length; i++) {
        docs.push(app.documents[i]);
    }
    return docs;
}

function __PDE_filterExportableDocs(docs) {
    var result = [];
    for (var i = 0; i < docs.length; i++) {
        if (__PDE_isPsdPsbDocument(docs[i])) {
            result.push(docs[i]);
        }
    }
    return result;
}

function __PDE_isPsdPsbDocument(doc) {
    var name = "";
    try {
        name = String(doc.fullName ? doc.fullName.name : doc.name);
    } catch (e) {
        name = String(doc.name || "");
    }

    return /\.(psd|psb)$/i.test(name);
}

function __PDE_exportDocuments(docs, settings) {
    var summary = {
        exportedDocs: 0,
        exportedSlices: 0,
        sliceEnabled: settings.exportSlices,
        skipped: [],
        failed: []
    };

    for (var i = 0; i < docs.length; i++) {
        var doc = docs[i];
        var baseName = __PDE_baseName(doc.name);

        try {
            app.activeDocument = doc;

            var exportFolder = settings.outputFolder;
            if (settings.exportAll) {
                exportFolder = __PDE_uniqueFolder(settings.outputFolder, baseName);
                if (!exportFolder.exists && !exportFolder.create()) {
                    throw new Error("无法创建文档文件夹：" + exportFolder.fsName);
                }
            }

            var exportFile = __PDE_uniqueFile(exportFolder, baseName + "." + settings.format);
            __PDE_exportWholeDocument(doc, exportFile, settings.format);
            summary.exportedDocs++;

            if (settings.exportSlices) {
                var sliceFolder = new Folder(exportFolder.fsName + "/切图");
                if (!sliceFolder.exists && !sliceFolder.create()) {
                    throw new Error("无法创建切图文件夹：" + sliceFolder.fsName);
                }

                var sliceResult = __PDE_exportSlices(doc, sliceFolder, settings.format);
                summary.exportedSlices += sliceResult.exported;
                if (sliceResult.message) {
                    summary.skipped.push(baseName + "：" + sliceResult.message);
                }
            }
        } catch (docError) {
            summary.failed.push(baseName + "：" + docError.message);
        }
    }

    return summary;
}

function __PDE_exportWholeDocument(sourceDoc, file, format) {
    var tempDoc = null;

    app.activeDocument = sourceDoc;
    try {
        tempDoc = __PDE_duplicateForExport(sourceDoc, "__psd_psb_full_export_temp__");
        app.activeDocument = tempDoc;

        if (format === "jpg") {
            __PDE_prepareJpgBackground(tempDoc);
            __PDE_exportJpg(tempDoc, file);
        } else {
            __PDE_exportPng(tempDoc, file);
        }
    } finally {
        if (tempDoc) {
            __PDE_closeNoSave(tempDoc);
        }
        try {
            app.activeDocument = sourceDoc;
        } catch (e) {
            // Source document may have been closed.
        }
    }
}

function __PDE_exportSlices(sourceDoc, sliceFolder, format) {
    try {
        __PDE_exportSlicesWithLegacySaveForWeb(sourceDoc, sliceFolder, format);
        __PDE_flattenLegacyImageFolder(sliceFolder);

        var legacyCount = __PDE_countExportedImages(sliceFolder, format);
        if (legacyCount < 1) {
            throw new Error("旧版整体导出没有生成图片");
        }

        return {
            exported: legacyCount,
            message: ""
        };
    } catch (legacyError) {
        __PDE_removeExportedImages(sliceFolder);
        return {
            exported: 0,
            message: "切图统一导出失败：" + legacyError.message
        };
    }
}

function __PDE_exportSlicesWithLegacySaveForWeb(sourceDoc, outputFolder, format) {
    var tempDoc = null;
    var oldDialogs = app.displayDialogs;

    app.activeDocument = sourceDoc;
    app.displayDialogs = DialogModes.NO;

    try {
        tempDoc = __PDE_duplicateForExport(sourceDoc, "__legacy_slice_export_temp__");
        app.activeDocument = tempDoc;

        if (format === "jpg") {
            __PDE_prepareJpgBackground(tempDoc);
        }

        __PDE_legacySaveForWeb(tempDoc, outputFolder, format);
    } finally {
        app.displayDialogs = oldDialogs;
        if (tempDoc) {
            __PDE_closeNoSave(tempDoc);
        }
        try {
            app.activeDocument = sourceDoc;
        } catch (e) {
            // Source document may have been closed.
        }
    }
}

function __PDE_legacySaveForWeb(doc, outputFolder, format) {
    app.activeDocument = doc;

    var desc = new ActionDescriptor();
    var saveForWebDesc = new ActionDescriptor();

    saveForWebDesc.putEnumerated(charIDToTypeID("Op  "), charIDToTypeID("SWOp"), charIDToTypeID("OpSa"));

    if (format === "jpg") {
        saveForWebDesc.putEnumerated(charIDToTypeID("Fmt "), charIDToTypeID("IRFm"), charIDToTypeID("JPEG"));
        saveForWebDesc.putBoolean(charIDToTypeID("Intr"), false);
        saveForWebDesc.putInteger(charIDToTypeID("Qlty"), 100);
        saveForWebDesc.putInteger(charIDToTypeID("QChS"), 0);
        saveForWebDesc.putInteger(charIDToTypeID("QCUI"), 0);
        saveForWebDesc.putBoolean(charIDToTypeID("QChT"), false);
        saveForWebDesc.putBoolean(charIDToTypeID("QChV"), false);
        saveForWebDesc.putBoolean(charIDToTypeID("Optm"), true);
        saveForWebDesc.putInteger(charIDToTypeID("Pass"), 1);
        saveForWebDesc.putDouble(charIDToTypeID("blur"), 0);
        saveForWebDesc.putBoolean(charIDToTypeID("Mtt "), true);
    } else {
        saveForWebDesc.putEnumerated(charIDToTypeID("Fmt "), charIDToTypeID("IRFm"), charIDToTypeID("PN24"));
        saveForWebDesc.putBoolean(charIDToTypeID("Intr"), false);
        saveForWebDesc.putBoolean(charIDToTypeID("Trns"), true);
        saveForWebDesc.putBoolean(charIDToTypeID("Mtt "), false);
    }

    saveForWebDesc.putBoolean(charIDToTypeID("EICC"), true);
    saveForWebDesc.putPath(charIDToTypeID("In  "), outputFolder);
    saveForWebDesc.putBoolean(charIDToTypeID("SHTM"), false);
    saveForWebDesc.putBoolean(charIDToTypeID("SImg"), true);
    saveForWebDesc.putBoolean(charIDToTypeID("SWsl"), true);
    saveForWebDesc.putEnumerated(charIDToTypeID("SWch"), charIDToTypeID("STch"), charIDToTypeID("CHsR"));
    saveForWebDesc.putEnumerated(charIDToTypeID("SWmd"), charIDToTypeID("STmd"), charIDToTypeID("MDCC"));
    saveForWebDesc.putBoolean(charIDToTypeID("ohXH"), false);
    saveForWebDesc.putBoolean(charIDToTypeID("ohIC"), true);
    saveForWebDesc.putBoolean(charIDToTypeID("ohAA"), true);
    saveForWebDesc.putBoolean(charIDToTypeID("ohQA"), true);
    saveForWebDesc.putBoolean(charIDToTypeID("ohCA"), false);
    saveForWebDesc.putBoolean(charIDToTypeID("ohIZ"), true);
    saveForWebDesc.putEnumerated(charIDToTypeID("ohTC"), charIDToTypeID("SToc"), charIDToTypeID("OC03"));
    saveForWebDesc.putEnumerated(charIDToTypeID("ohAC"), charIDToTypeID("SToc"), charIDToTypeID("OC03"));
    saveForWebDesc.putInteger(charIDToTypeID("ohIn"), -1);
    saveForWebDesc.putEnumerated(charIDToTypeID("ohLE"), charIDToTypeID("STle"), charIDToTypeID("LE03"));
    saveForWebDesc.putBoolean(charIDToTypeID("ohEn"), false);
    saveForWebDesc.putBoolean(charIDToTypeID("olCS"), false);
    saveForWebDesc.putEnumerated(charIDToTypeID("olEC"), charIDToTypeID("STst"), charIDToTypeID("ST00"));
    saveForWebDesc.putEnumerated(charIDToTypeID("olWH"), charIDToTypeID("STwh"), charIDToTypeID("WH01"));
    saveForWebDesc.putEnumerated(charIDToTypeID("olSV"), charIDToTypeID("STsp"), charIDToTypeID("SP04"));
    saveForWebDesc.putEnumerated(charIDToTypeID("olSH"), charIDToTypeID("STsp"), charIDToTypeID("SP04"));

    desc.putObject(charIDToTypeID("Usng"), stringIDToTypeID("SaveForWeb"), saveForWebDesc);
    executeAction(charIDToTypeID("Expr"), desc, DialogModes.NO);
}

function __PDE_duplicateForExport(sourceDoc, tempName) {
    try {
        return sourceDoc.duplicate(tempName, true);
    } catch (e) {
        return sourceDoc.duplicate(tempName, false);
    }
}

function __PDE_prepareJpgBackground(doc) {
    app.activeDocument = doc;

    var white = new SolidColor();
    white.rgb.red = 255;
    white.rgb.green = 255;
    white.rgb.blue = 255;

    var bg = doc.artLayers.add();
    bg.name = "__jpg_white_background__";
    doc.selection.selectAll();
    doc.selection.fill(white, ColorBlendMode.NORMAL, 100, false);
    doc.selection.deselect();

    try {
        bg.move(doc, ElementPlacement.PLACEATEND);
    } catch (e) {
        try {
            bg.move(doc.layers[doc.layers.length - 1], ElementPlacement.PLACEAFTER);
        } catch (e2) {
            // Flattening for JPEG still uses the white-filled layer.
        }
    }

    doc.flatten();
}

function __PDE_exportPng(doc, file) {
    app.activeDocument = doc;

    try {
        var options = new ExportOptionsSaveForWeb();
        options.format = SaveDocumentType.PNG;
        options.PNG8 = false;
        options.transparency = true;
        options.interlaced = false;
        options.includeProfile = true;

        doc.exportDocument(file, ExportType.SAVEFORWEB, options);
    } catch (e) {
        var pngOptions = new PNGSaveOptions();
        pngOptions.interlaced = false;
        doc.saveAs(file, pngOptions, true, Extension.LOWERCASE);
    }
}

function __PDE_exportJpg(doc, file) {
    app.activeDocument = doc;

    try {
        var options = new ExportOptionsSaveForWeb();
        options.format = SaveDocumentType.JPEG;
        options.quality = 100;
        options.optimized = true;
        options.includeProfile = true;

        doc.exportDocument(file, ExportType.SAVEFORWEB, options);
    } catch (e) {
        var jpgOptions = new JPEGSaveOptions();
        jpgOptions.quality = 12;
        jpgOptions.embedColorProfile = true;
        jpgOptions.formatOptions = FormatOptions.STANDARDBASELINE;
        jpgOptions.matte = MatteType.WHITE;
        doc.saveAs(file, jpgOptions, true, Extension.LOWERCASE);
    }
}

function __PDE_unitToPx(value) {
    try {
        return Number(value.as("px"));
    } catch (e) {
        return Number(value);
    }
}

function __PDE_uniqueSorted(values) {
    values.sort(function (a, b) {
        return a - b;
    });

    var result = [];
    var last = null;
    for (var i = 0; i < values.length; i++) {
        var value = Math.round(Number(values[i]));
        if (isNaN(value)) {
            continue;
        }
        if (last === null || Math.abs(value - last) >= 1) {
            result.push(value);
            last = value;
        }
    }

    return result;
}

function __PDE_defaultFolder(doc) {
    try {
        if (doc.path && doc.path.exists) {
            return doc.path;
        }
    } catch (e) {
        // Unsaved documents do not have a path.
    }

    return Folder.desktop;
}

function __PDE_baseName(name) {
    var base = String(name || "document").replace(/\.[^\.]+$/, "");
    return __PDE_cleanName(base, "document");
}

function __PDE_uniqueFolder(parent, name) {
    var base = __PDE_cleanName(name, "document");
    var folder = new Folder(parent.fsName + "/" + base);
    var index = 2;

    while (folder.exists) {
        folder = new Folder(parent.fsName + "/" + base + "_" + index);
        index++;
    }

    return folder;
}

function __PDE_uniqueFile(folder, filename) {
    var cleaned = __PDE_cleanName(filename, "export.png");
    var dot = cleaned.lastIndexOf(".");
    var name = dot >= 0 ? cleaned.substring(0, dot) : cleaned;
    var ext = dot >= 0 ? cleaned.substring(dot) : "";
    var file = new File(folder.fsName + "/" + cleaned);
    var index = 2;

    while (file.exists) {
        file = new File(folder.fsName + "/" + name + "_" + index + ext);
        index++;
    }

    return file;
}

function __PDE_countExportedImages(folder, format) {
    var count = 0;
    var files = folder.getFiles();
    var extPattern = format === "jpg" ? /\.(jpg|jpeg)$/i : /\.png$/i;

    for (var i = 0; i < files.length; i++) {
        if (files[i] instanceof Folder) {
            count += __PDE_countExportedImages(files[i], format);
        } else if (extPattern.test(files[i].name)) {
            count++;
        }
    }

    return count;
}

function __PDE_flattenLegacyImageFolder(folder) {
    var files = folder.getFiles();
    for (var i = 0; i < files.length; i++) {
        var item = files[i];
        if (item instanceof Folder) {
            __PDE_flattenLegacyImageFolder(item);

            var nestedFiles = item.getFiles();
            for (var j = 0; j < nestedFiles.length; j++) {
                var nestedItem = nestedFiles[j];
                if (nestedItem instanceof File && /\.(jpg|jpeg|png)$/i.test(nestedItem.name)) {
                    var target = __PDE_uniqueFile(folder, nestedItem.name);
                    try {
                        nestedItem.copy(target);
                        nestedItem.remove();
                    } catch (e) {
                        // Keep the original file in the nested folder if moving fails.
                    }
                }
            }

            try {
                item.remove();
            } catch (removeFolderError) {
                // The folder may contain non-image metadata from Save for Web.
            }
        }
    }
}

function __PDE_removeExportedImages(folder) {
    var files = folder.getFiles();
    for (var i = 0; i < files.length; i++) {
        var item = files[i];
        if (item instanceof Folder) {
            __PDE_removeExportedImages(item);
            try {
                item.remove();
            } catch (folderError) {
                // Leave non-empty folders alone.
            }
        } else if (/\.(jpg|jpeg|png|gif|html?)$/i.test(item.name)) {
            try {
                item.remove();
            } catch (fileError) {
                // Ignore cleanup failures.
            }
        }
    }
}

function __PDE_cleanName(name, fallback) {
    var cleaned = String(name || "")
        .replace(/[\\\/:\*\?"<>\|]/g, "_")
        .replace(/^\s+|\s+$/g, "")
        .replace(/[\. ]+$/g, "");

    if (!cleaned) {
        cleaned = fallback;
    }

    return cleaned;
}

function __PDE_pad(number, size) {
    var text = String(number);
    while (text.length < size) {
        text = "0" + text;
    }
    return text;
}

function __PDE_closeNoSave(doc) {
    try {
        doc.close(SaveOptions.DONOTSAVECHANGES);
    } catch (e) {
        // Ignore close failures.
    }
}
