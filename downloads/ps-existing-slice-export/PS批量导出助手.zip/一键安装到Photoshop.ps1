$ErrorActionPreference = "Stop"

$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process -FilePath "powershell.exe" -ArgumentList @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $PSCommandPath) -Verb RunAs
    exit
}

$scriptName = "PS批量导出助手.jsx"
$source = Join-Path $PSScriptRoot $scriptName

if (-not (Test-Path -LiteralPath $source)) {
    Write-Host "未找到 $scriptName"
    Read-Host "按回车退出"
    exit 1
}

$photoshopFolders = Get-ChildItem -LiteralPath "C:\Program Files\Adobe" -Directory -Filter "Adobe Photoshop*" -ErrorAction SilentlyContinue
$installed = 0

foreach ($folder in $photoshopFolders) {
    $scriptsFolder = Join-Path $folder.FullName "Presets\Scripts"
    if (Test-Path -LiteralPath $scriptsFolder) {
        Copy-Item -LiteralPath $source -Destination (Join-Path $scriptsFolder $scriptName) -Force
        Write-Host "已安装到：$scriptsFolder"
        $installed++
    }
}

if ($installed -eq 0) {
    Write-Host "没有找到 Photoshop 的 Presets\Scripts 目录，请按使用说明手动复制。"
} else {
    Write-Host "安装完成。请重启 Photoshop。"
}

Read-Host "按回车退出"
