$ErrorActionPreference = "Stop"

$scriptName = "AI_一键嵌入所有链接.jsx"
$source = Join-Path -Path $PSScriptRoot -ChildPath $scriptName

if (!(Test-Path -LiteralPath $source)) {
    throw "Missing source JSX: $source"
}

$roots = Get-ChildItem -LiteralPath "C:\Program Files\Adobe" -Directory -Filter "Adobe Illustrator*" -ErrorAction SilentlyContinue
$installed = @()

foreach ($root in $roots) {
    $presetRoot = Join-Path -Path $root.FullName -ChildPath "Presets"
    if (!(Test-Path -LiteralPath $presetRoot)) {
        continue
    }

    $scriptDirs = Get-ChildItem -LiteralPath $presetRoot -Recurse -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -eq "脚本" -or $_.Name -eq "Scripts" }

    foreach ($dir in $scriptDirs) {
        $dest = Join-Path -Path $dir.FullName -ChildPath $scriptName
        Copy-Item -LiteralPath $source -Destination $dest -Force
        $installed += $dest
    }
}

if ($installed.Count -eq 0) {
    Write-Host "No Illustrator Scripts folder was found."
    exit 1
}

Write-Host "Installed:"
$installed | ForEach-Object { Write-Host $_ }
Write-Host ""
Write-Host "Restart Illustrator, then use File > Scripts > AI_一键嵌入所有链接."
