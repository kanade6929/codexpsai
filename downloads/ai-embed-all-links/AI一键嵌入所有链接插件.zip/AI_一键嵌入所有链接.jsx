﻿#target illustrator

(function () {
    if (app.documents.length < 1) {
        alert("请先打开一个 Illustrator 文件。");
        return;
    }

    var doc = app.activeDocument;
    var items = [];
    for (var i = 0; i < doc.placedItems.length; i++) {
        items.push(doc.placedItems[i]);
    }

    if (items.length < 1) {
        alert("当前文件没有需要嵌入的外部链接。");
        return;
    }

    var ok = confirm(
        "检测到 " + items.length + " 个外部链接对象。\n\n" +
        "脚本会尝试把它们一次性嵌入当前 AI 文件。\n" +
        "建议先另存一个副本，再继续。\n\n" +
        "是否开始嵌入？"
    );
    if (!ok) return;

    var embedded = 0;
    var failed = [];

    for (var j = 0; j < items.length; j++) {
        var item = items[j];
        var itemName = getItemName(item, j + 1);
        var states = [];

        try {
            revealAndUnlock(item, states);
            item.embed();
            embedded++;
        } catch (err) {
            failed.push(itemName + "： " + err.message);
        } finally {
            restoreStates(states);
        }
    }

    app.redraw();

    var message = "嵌入完成。\n\n成功：" + embedded + " 个";
    if (failed.length > 0) {
        message += "\n失败：" + failed.length + " 个\n\n";
        message += "失败项目：\n" + failed.join("\n");
        message += "\n\n缺失链接需要先重新链接后再运行。";
    }
    alert(message);

    function getItemName(item, index) {
        try {
            if (item.file && item.file.displayName) return item.file.displayName;
        } catch (ignored) {}

        try {
            if (item.name) return item.name;
        } catch (ignoredName) {}

        return "链接对象 " + index;
    }

    function revealAndUnlock(item, states) {
        var current = item;
        while (current) {
            saveAndSet(current, "locked", false, states);
            saveAndSet(current, "hidden", false, states);
            saveAndSet(current, "visible", true, states);

            try {
                if (!current.parent || current === current.parent) break;
                current = current.parent;
            } catch (parentErr) {
                break;
            }
        }
    }

    function saveAndSet(target, property, value, states) {
        try {
            var oldValue = target[property];
            if (oldValue !== value) {
                states.push({
                    target: target,
                    property: property,
                    value: oldValue
                });
                target[property] = value;
            }
        } catch (ignored) {}
    }

    function restoreStates(states) {
        for (var i = states.length - 1; i >= 0; i--) {
            try {
                states[i].target[states[i].property] = states[i].value;
            } catch (ignored) {}
        }
    }
})();
