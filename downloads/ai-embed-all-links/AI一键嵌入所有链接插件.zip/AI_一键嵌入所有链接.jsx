#target illustrator

(function () {
    if (app.documents.length < 1) {
        alert("请先打开一个 Illustrator 文件。");
        return;
    }

    var doc = app.activeDocument;
    var dialog = new Window("dialog", "AI 发厂前整理助手");
    dialog.orientation = "column";
    dialog.alignChildren = ["fill", "top"];
    dialog.spacing = 12;
    dialog.margins = 18;

    var description = dialog.add(
        "statictext",
        undefined,
        "请选择要执行的操作。重要文件建议先另存一个副本。",
        { multiline: true }
    );
    description.preferredSize.width = 360;

    var embedButton = dialog.add("button", undefined, "嵌入所有链接");
    var cleanupButton = dialog.add("button", undefined, "删除隐藏 / 空白对象");
    var statusText = dialog.add("statictext", undefined, "当前文件：" + getDocumentName(doc));
    statusText.preferredSize.width = 360;

    embedButton.onClick = function () {
        var result = embedAllLinks(doc);
        if (result) statusText.text = result;
    };

    cleanupButton.onClick = function () {
        var result = cleanupDocument(doc);
        if (result) statusText.text = result;
    };

    dialog.center();
    dialog.show();

    function getDocumentName(targetDoc) {
        try {
            return targetDoc.name;
        } catch (ignored) {
            return "当前文档";
        }
    }

    function embedAllLinks(targetDoc) {
        var items = snapshotCollection(targetDoc.placedItems);
        if (items.length < 1) {
            alert("当前文件没有需要嵌入的外部链接。");
            return "没有检测到外部链接";
        }

        var ok = confirm(
            "检测到 " + items.length + " 个外部链接对象。\n\n" +
            "脚本会使用 Illustrator 原生方式嵌入链接。\n" +
            "如果一个链接嵌入后产生多个对象，会自动编组为一个对象。\n" +
            "建议先另存一个副本，再继续。\n\n" +
            "是否开始嵌入？"
        );
        if (!ok) return null;

        var embedded = 0;
        var corrected = 0;
        var failed = [];
        var originalSelection = getSelectionSnapshot(targetDoc);

        for (var j = 0; j < items.length; j++) {
            var item = items[j];
            var itemName = getItemName(item, j + 1);
            var states = [];
            var marker = "__codex_embed_link_" + (new Date().getTime()) + "_" + j + "__";
            var oldName = getSafeName(item);
            var itemState = getItemState(item);

            try {
                revealAndUnlock(item, states);
                var beforeBounds = getBounds(item);
                var resultItems = embedAndFindResult(targetDoc, item, marker);
                resultItems = groupResultIfNeeded(targetDoc, resultItems, marker, oldName);

                if (resultItems.length > 0 && restoreBounds(resultItems, beforeBounds)) corrected++;

                restoreResultName(resultItems, oldName);
                restoreResultState(resultItems, itemState);
                embedded++;
            } catch (err) {
                failed.push(itemName + "： " + err.message);
            } finally {
                restoreStates(states);
            }
        }

        app.redraw();
        restoreSelection(targetDoc, originalSelection);

        var message = "嵌入完成。\n\n成功：" + embedded + " 个\n位置校正：" + corrected + " 个";
        if (failed.length > 0) {
            message += "\n失败：" + failed.length + " 个\n\n失败项目：\n" + failed.join("\n");
            message += "\n\n缺失链接需要先重新链接后再运行。";
        }
        alert(message);
        return "已嵌入 " + embedded + " 个链接";
    }

    function cleanupDocument(targetDoc) {
        var ok = confirm(
            "将永久删除当前文件中的：\n\n" +
            "• 隐藏图层和隐藏对象\n" +
            "• 透明度为 0% 的不可见对象\n" +
            "• 空文本、空路径、空复合路径\n" +
            "• 清理后形成的空编组和空图层\n\n" +
            "剪切路径和参考线会保留。\n" +
            "此操作会修改文件，建议先另存副本。\n\n" +
            "确定继续吗？"
        );
        if (!ok) return null;

        var stats = {
            hiddenLayers: 0,
            hiddenObjects: 0,
            invisibleObjects: 0,
            emptyTexts: 0,
            emptyPaths: 0,
            emptyCompoundPaths: 0,
            emptyGroups: 0,
            emptyLayers: 0,
            retainedRootLayer: 0,
            failed: 0
        };
        var originalSelection = getSelectionSnapshot(targetDoc);

        removeHiddenLayers(targetDoc, stats);
        removeHiddenPageItems(targetDoc, stats);
        removeZeroOpacityItems(targetDoc, stats);
        removeBlankStructures(targetDoc, stats);

        app.redraw();
        restoreSelection(targetDoc, originalSelection);

        var removedTotal = stats.hiddenLayers + stats.hiddenObjects + stats.invisibleObjects +
            stats.emptyTexts + stats.emptyPaths + stats.emptyCompoundPaths +
            stats.emptyGroups + stats.emptyLayers;

        var message =
            "清理完成。\n\n" +
            "隐藏图层：" + stats.hiddenLayers + "\n" +
            "隐藏对象：" + stats.hiddenObjects + "\n" +
            "0% 不可见对象：" + stats.invisibleObjects + "\n" +
            "空文本：" + stats.emptyTexts + "\n" +
            "空路径 / 复合路径：" + (stats.emptyPaths + stats.emptyCompoundPaths) + "\n" +
            "空编组：" + stats.emptyGroups + "\n" +
            "空图层：" + stats.emptyLayers + "\n\n" +
            "共删除：" + removedTotal + " 项";

        if (stats.retainedRootLayer > 0) {
            message += "\n\nIllustrator 必须保留至少一个主图层，最后一个空主图层未删除。";
        }
        if (stats.failed > 0) {
            message += "\n\n另有 " + stats.failed + " 项无法删除，请人工检查锁定或特殊对象。";
        }

        alert(message);
        return "已清理 " + removedTotal + " 项";
    }

    function removeHiddenLayers(targetDoc, stats) {
        var layers = [];
        collectLayers(targetDoc, layers);
        layers.sort(function (a, b) {
            return getLayerDepth(b) - getLayerDepth(a);
        });

        for (var i = 0; i < layers.length; i++) {
            var layer = layers[i];
            if (!isLayerVisible(layer) && !hasHiddenLayerAncestor(layer)) {
                ensureReplacementRootLayer(targetDoc, layer);
                if (removeTarget(layer)) stats.hiddenLayers++;
                else stats.failed++;
            }
        }
    }

    function ensureReplacementRootLayer(targetDoc, layer) {
        try {
            if (getTypeName(layer.parent) === "Document" && targetDoc.layers.length <= 1) {
                var replacement = targetDoc.layers.add();
                replacement.name = "发厂整理保留层";
                replacement.visible = true;
                replacement.locked = false;
            }
        } catch (ignored) {}
    }

    function removeHiddenPageItems(targetDoc, stats) {
        var items = snapshotCollection(targetDoc.pageItems);
        for (var i = items.length - 1; i >= 0; i--) {
            var item = items[i];
            if (isItemHidden(item) && !hasHiddenPageItemAncestor(item) && !hasHiddenLayerAncestor(item)) {
                if (removeTarget(item)) stats.hiddenObjects++;
                else stats.failed++;
            }
        }
    }

    function removeZeroOpacityItems(targetDoc, stats) {
        var items = snapshotCollection(targetDoc.pageItems);
        for (var i = items.length - 1; i >= 0; i--) {
            var item = items[i];
            if (isZeroOpacity(item) && !hasZeroOpacityPageItemAncestor(item) && !isProtectedStructure(item)) {
                if (removeTarget(item)) stats.invisibleObjects++;
                else stats.failed++;
            }
        }
    }

    function removeBlankStructures(targetDoc, stats) {
        var pass = 0;
        var changed = true;

        while (changed && pass < 50) {
            changed = false;
            pass++;

            var items = snapshotCollection(targetDoc.pageItems);
            for (var i = items.length - 1; i >= 0; i--) {
                var item = items[i];
                var blankType = getBlankType(item);
                if (!blankType) continue;

                if (removeTarget(item)) {
                    changed = true;
                    stats[blankType]++;
                } else {
                    stats.failed++;
                }
            }

            var layers = [];
            collectLayers(targetDoc, layers);
            layers.sort(function (a, b) {
                return getLayerDepth(b) - getLayerDepth(a);
            });

            for (var j = 0; j < layers.length; j++) {
                var layer = layers[j];
                if (!isLayerEmpty(layer)) continue;

                if (isOnlyRootLayer(targetDoc, layer)) {
                    stats.retainedRootLayer = 1;
                    continue;
                }

                if (removeTarget(layer)) {
                    changed = true;
                    stats.emptyLayers++;
                } else {
                    stats.failed++;
                }
            }
        }
    }

    function getBlankType(item) {
        var type = getTypeName(item);

        if (type === "TextFrame" || type === "LegacyTextItem") {
            try {
                if (String(item.contents).replace(/\s/g, "") === "") return "emptyTexts";
            } catch (ignoredText) {}
            return null;
        }

        if (type === "PathItem") {
            if (getTypeName(getParent(item)) === "CompoundPathItem") return null;
            if (isProtectedStructure(item)) return null;

            try {
                if (item.pathPoints.length === 0 || (!item.filled && !item.stroked)) return "emptyPaths";
            } catch (ignoredPath) {}
            return null;
        }

        if (type === "CompoundPathItem") {
            if (isProtectedStructure(item)) return null;
            try {
                if (item.pathItems.length === 0) return "emptyCompoundPaths";

                var allBlank = true;
                for (var i = 0; i < item.pathItems.length; i++) {
                    var path = item.pathItems[i];
                    if (isProtectedStructure(path) || path.filled || path.stroked) {
                        allBlank = false;
                        break;
                    }
                }
                if (allBlank) return "emptyCompoundPaths";
            } catch (ignoredCompound) {}
            return null;
        }

        if (type === "GroupItem") {
            try {
                if (item.pageItems.length === 0) return "emptyGroups";
            } catch (ignoredGroup) {}
        }

        return null;
    }

    function isProtectedStructure(item) {
        try {
            if (item.clipping) return true;
        } catch (ignoredClipping) {}
        try {
            if (item.guides) return true;
        } catch (ignoredGuides) {}
        return false;
    }

    function isLayerEmpty(layer) {
        try {
            return layer.pageItems.length === 0 && layer.layers.length === 0;
        } catch (ignored) {
            return false;
        }
    }

    function isOnlyRootLayer(targetDoc, layer) {
        try {
            return getTypeName(layer.parent) === "Document" && targetDoc.layers.length <= 1;
        } catch (ignored) {
            return false;
        }
    }

    function getLayerDepth(layer) {
        var depth = 0;
        var current = getParent(layer);
        while (current && getTypeName(current) === "Layer") {
            depth++;
            current = getParent(current);
        }
        return depth;
    }

    function collectLayers(container, result) {
        try {
            for (var i = 0; i < container.layers.length; i++) {
                var layer = container.layers[i];
                result.push(layer);
                collectLayers(layer, result);
            }
        } catch (ignored) {}
    }

    function snapshotCollection(collection) {
        var result = [];
        try {
            for (var i = 0; i < collection.length; i++) result.push(collection[i]);
        } catch (ignored) {}
        return result;
    }

    function isLayerVisible(layer) {
        try {
            return layer.visible !== false;
        } catch (ignored) {
            return true;
        }
    }

    function isItemHidden(item) {
        try {
            return item.hidden === true;
        } catch (ignored) {
            return false;
        }
    }

    function isZeroOpacity(item) {
        try {
            return Number(item.opacity) <= 0.001;
        } catch (ignored) {
            return false;
        }
    }

    function hasHiddenLayerAncestor(target) {
        var current = getParent(target);
        while (current) {
            if (getTypeName(current) === "Layer" && !isLayerVisible(current)) return true;
            current = getParent(current);
        }
        return false;
    }

    function hasHiddenPageItemAncestor(item) {
        var current = getParent(item);
        while (current) {
            var type = getTypeName(current);
            if (isPageItemType(type) && isItemHidden(current)) return true;
            current = getParent(current);
        }
        return false;
    }

    function hasZeroOpacityPageItemAncestor(item) {
        var current = getParent(item);
        while (current) {
            var type = getTypeName(current);
            if (isPageItemType(type) && isZeroOpacity(current)) return true;
            current = getParent(current);
        }
        return false;
    }

    function isPageItemType(type) {
        return type && type !== "Layer" && type !== "Document" && type !== "Application";
    }

    function getParent(target) {
        try {
            if (!target.parent || target.parent === target) return null;
            return target.parent;
        } catch (ignored) {
            return null;
        }
    }

    function getTypeName(target) {
        try {
            return target.typename || "";
        } catch (ignored) {
            return "";
        }
    }

    function removeTarget(target) {
        var states = [];
        try {
            revealAndUnlock(target, states);
            target.remove();
            return true;
        } catch (ignored) {
            return false;
        } finally {
            restoreStates(states);
        }
    }

    function getItemName(item, index) {
        try {
            if (item.file && item.file.displayName) return item.file.displayName;
        } catch (ignored) {}
        try {
            if (item.name) return item.name;
        } catch (ignoredName) {}
        return "链接对象 " + index;
    }

    function getItemState(item) {
        return {
            locked: getSafeProperty(item, "locked"),
            hidden: getSafeProperty(item, "hidden"),
            visible: getSafeProperty(item, "visible")
        };
    }

    function getSafeProperty(item, property) {
        try {
            return item[property];
        } catch (ignored) {
            return null;
        }
    }

    function restoreResultState(items, state) {
        if (!state) return;

        for (var i = 0; i < items.length; i++) {
            if (state.visible !== null) {
                try {
                    items[i].visible = state.visible;
                } catch (visibleErr) {}
            }
            if (state.hidden !== null) {
                try {
                    items[i].hidden = state.hidden;
                } catch (hiddenErr) {}
            }
            if (state.locked !== null) {
                try {
                    items[i].locked = state.locked;
                } catch (lockedErr) {}
            }
        }
    }

    function getSafeName(item) {
        try {
            return item.name || "";
        } catch (ignored) {
            return "";
        }
    }

    function embedAndFindResult(targetDoc, item, marker) {
        try {
            item.name = marker;
        } catch (nameErr) {}
        try {
            targetDoc.selection = null;
        } catch (clearErr) {}
        try {
            item.selected = true;
        } catch (selectErr) {}

        item.embed();
        app.redraw();

        var resultItems = getSelectionSnapshot(targetDoc);
        if (resultItems.length > 0) return resultItems;
        return findItemsByName(targetDoc, marker);
    }

    function getSelectionSnapshot(targetDoc) {
        var result = [];
        try {
            if (targetDoc.selection && targetDoc.selection.length) {
                for (var i = 0; i < targetDoc.selection.length; i++) result.push(targetDoc.selection[i]);
            }
        } catch (ignored) {}
        return result;
    }

    function groupResultIfNeeded(targetDoc, items, marker, oldName) {
        if (items.length <= 1) return items;

        try {
            var first = items[0];
            var parent = first.parent;
            var group = parent.groupItems.add();

            try {
                group.name = oldName || marker;
            } catch (nameErr) {}
            try {
                group.move(first, ElementPlacement.PLACEBEFORE);
            } catch (moveGroupErr) {}

            for (var i = 0; i < items.length; i++) {
                try {
                    items[i].move(group, ElementPlacement.PLACEATEND);
                } catch (moveItemErr) {}
            }

            try {
                targetDoc.selection = null;
                group.selected = true;
            } catch (selectErr) {}

            return [group];
        } catch (groupErr) {
            return items;
        }
    }

    function restoreSelection(targetDoc, selectionItems) {
        try {
            targetDoc.selection = null;
        } catch (clearErr) {}

        for (var i = 0; i < selectionItems.length; i++) {
            try {
                selectionItems[i].selected = true;
            } catch (ignored) {}
        }
    }

    function findItemsByName(targetDoc, marker) {
        var result = [];
        try {
            for (var i = 0; i < targetDoc.pageItems.length; i++) {
                if (targetDoc.pageItems[i].name === marker) result.push(targetDoc.pageItems[i]);
            }
        } catch (ignored) {}
        return result;
    }

    function restoreResultName(items, oldName) {
        for (var i = 0; i < items.length; i++) {
            try {
                if (items[i].name && items[i].name.indexOf("__codex_embed_link_") === 0) {
                    items[i].name = oldName;
                }
            } catch (ignored) {}
        }
    }

    function getBounds(target) {
        try {
            var b = target.geometricBounds;
            return {
                left: b[0],
                top: b[1],
                right: b[2],
                bottom: b[3],
                width: b[2] - b[0],
                height: b[1] - b[3]
            };
        } catch (err) {
            return null;
        }
    }

    function getCombinedBounds(items) {
        var combined = null;
        for (var i = 0; i < items.length; i++) {
            var b = getBounds(items[i]);
            if (!b) continue;

            if (!combined) {
                combined = { left: b.left, top: b.top, right: b.right, bottom: b.bottom };
            } else {
                combined.left = Math.min(combined.left, b.left);
                combined.top = Math.max(combined.top, b.top);
                combined.right = Math.max(combined.right, b.right);
                combined.bottom = Math.min(combined.bottom, b.bottom);
            }
        }

        if (!combined) return null;
        combined.width = combined.right - combined.left;
        combined.height = combined.top - combined.bottom;
        return combined;
    }

    function restoreBounds(items, originalBounds) {
        if (!originalBounds) return false;
        var currentBounds = getCombinedBounds(items);
        if (!currentBounds) return false;

        var sizeTolerance = 0.01;
        if (
            items.length === 1 && currentBounds.width > 0 && currentBounds.height > 0 &&
            (Math.abs(currentBounds.width - originalBounds.width) > sizeTolerance ||
                Math.abs(currentBounds.height - originalBounds.height) > sizeTolerance)
        ) {
            try {
                var scaleX = (originalBounds.width / currentBounds.width) * 100;
                var scaleY = (originalBounds.height / currentBounds.height) * 100;
                items[0].resize(scaleX, scaleY, true, true, true, true, scaleX, Transformation.TOPLEFT);
                currentBounds = getCombinedBounds(items);
            } catch (resizeErr) {}
        }

        if (!currentBounds) return false;
        var dx = originalBounds.left - currentBounds.left;
        var dy = originalBounds.top - currentBounds.top;
        if (Math.abs(dx) < 0.001 && Math.abs(dy) < 0.001) return true;

        for (var i = 0; i < items.length; i++) {
            try {
                items[i].translate(dx, dy);
            } catch (translateErr) {}
        }
        return true;
    }

    function revealAndUnlock(item, states) {
        var current = item;
        while (current) {
            saveAndSet(current, "locked", false, states);
            saveAndSet(current, "hidden", false, states);
            saveAndSet(current, "visible", true, states);

            try {
                if (!current.parent || current === current.parent) break;
                current = current.parent;
            } catch (parentErr) {
                break;
            }
        }
    }

    function saveAndSet(target, property, value, states) {
        try {
            var oldValue = target[property];
            if (oldValue !== value) {
                states.push({ target: target, property: property, value: oldValue });
                target[property] = value;
            }
        } catch (ignored) {}
    }

    function restoreStates(states) {
        for (var i = states.length - 1; i >= 0; i--) {
            try {
                states[i].target[states[i].property] = states[i].value;
            } catch (ignored) {}
        }
    }
})();
