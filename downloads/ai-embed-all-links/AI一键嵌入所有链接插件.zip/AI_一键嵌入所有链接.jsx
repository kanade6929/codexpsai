﻿#target illustrator

(function () {
    if (app.documents.length < 1) {
        alert("请先打开一个 Illustrator 文件。");
        return;
    }

    var doc = app.activeDocument;
    var items = [];
    for (var i = 0; i < doc.placedItems.length; i++) {
        items.push(doc.placedItems[i]);
    }

    if (items.length < 1) {
        alert("当前文件没有需要嵌入的外部链接。");
        return;
    }

    var ok = confirm(
        "检测到 " + items.length + " 个外部链接对象。\n\n" +
        "脚本会把每个链接合并为单个嵌入图像。\n" +
        "PSD/PDF 等多层链接会按当前外观压平成一张位图。\n" +
        "建议先另存一个副本，再继续。\n\n" +
        "是否开始合并嵌入？"
    );
    if (!ok) return;

    var embedded = 0;
    var corrected = 0;
    var failed = [];
    var originalSelection = getSelectionSnapshot(doc);

    for (var j = 0; j < items.length; j++) {
        var item = items[j];
        var itemName = getItemName(item, j + 1);
        var states = [];
        var marker = "__codex_embed_link_" + (new Date().getTime()) + "_" + j + "__";
        var oldName = getSafeName(item);
        var itemState = getItemState(item);

        try {
            revealAndUnlock(item, states);
            var beforeBounds = getBounds(item);
            var resultItems = rasterizeAndFindResult(doc, item, marker, beforeBounds);

            if (resultItems.length > 0 && restoreBounds(resultItems, beforeBounds)) {
                corrected++;
            }

            restoreResultName(resultItems, oldName);
            restoreResultState(resultItems, itemState);
            embedded++;
        } catch (err) {
            failed.push(itemName + "： " + err.message);
        } finally {
            restoreStates(states);
        }
    }

    app.redraw();

    restoreSelection(doc, originalSelection);

    var message = "合并嵌入完成。\n\n成功：" + embedded + " 个\n位置校正：" + corrected + " 个";
    if (failed.length > 0) {
        message += "\n失败：" + failed.length + " 个\n\n";
        message += "失败项目：\n" + failed.join("\n");
        message += "\n\n缺失链接需要先重新链接后再运行。";
    }
    alert(message);

    function getItemName(item, index) {
        try {
            if (item.file && item.file.displayName) return item.file.displayName;
        } catch (ignored) {}

        try {
            if (item.name) return item.name;
        } catch (ignoredName) {}

        return "链接对象 " + index;
    }

    function getItemState(item) {
        return {
            locked: getSafeProperty(item, "locked"),
            hidden: getSafeProperty(item, "hidden"),
            visible: getSafeProperty(item, "visible")
        };
    }

    function getSafeProperty(item, property) {
        try {
            return item[property];
        } catch (ignored) {
            return null;
        }
    }

    function restoreResultState(items, state) {
        if (!state) {
            return;
        }

        for (var i = 0; i < items.length; i++) {
            if (state.visible !== null) {
                try {
                    items[i].visible = state.visible;
                } catch (visibleErr) {}
            }
            if (state.hidden !== null) {
                try {
                    items[i].hidden = state.hidden;
                } catch (hiddenErr) {}
            }
            if (state.locked !== null) {
                try {
                    items[i].locked = state.locked;
                } catch (lockedErr) {}
            }
        }
    }

    function getSafeName(item) {
        try {
            return item.name || "";
        } catch (ignored) {
            return "";
        }
    }

    function rasterizeAndFindResult(doc, item, marker, bounds) {
        try {
            item.name = marker;
        } catch (nameErr) {}

        try {
            doc.selection = null;
        } catch (clearErr) {}

        try {
            item.selected = true;
        } catch (selectErr) {}

        var rasterOptions = makeRasterizeOptions();
        var rasterBounds = boundsToArray(bounds);
        var rasterItem = doc.rasterize(item, rasterBounds, rasterOptions);

        try {
            rasterItem.name = marker;
        } catch (rasterNameErr) {}

        app.redraw();

        if (rasterItem) {
            return [rasterItem];
        }

        return findItemsByName(doc, marker);
    }

    function makeRasterizeOptions() {
        var options = new RasterizeOptions();

        try {
            options.resolution = 300;
        } catch (resolutionErr) {}

        try {
            options.transparency = true;
        } catch (transparencyErr) {}

        try {
            options.antiAliasingMethod = AntiAliasingMethod.ARTOPTIMIZED;
        } catch (antiAliasErr) {}

        try {
            options.clippingMask = false;
        } catch (clipErr) {}

        return options;
    }

    function boundsToArray(bounds) {
        if (!bounds) {
            return null;
        }

        return [bounds.left, bounds.top, bounds.right, bounds.bottom];
    }

    function getSelectionSnapshot(doc) {
        var result = [];
        try {
            if (doc.selection && doc.selection.length) {
                for (var i = 0; i < doc.selection.length; i++) {
                    result.push(doc.selection[i]);
                }
            }
        } catch (ignored) {}
        return result;
    }

    function restoreSelection(doc, selectionItems) {
        try {
            doc.selection = null;
        } catch (clearErr) {}

        for (var i = 0; i < selectionItems.length; i++) {
            try {
                selectionItems[i].selected = true;
            } catch (ignored) {}
        }
    }

    function findItemsByName(doc, marker) {
        var result = [];
        try {
            for (var i = 0; i < doc.pageItems.length; i++) {
                if (doc.pageItems[i].name === marker) {
                    result.push(doc.pageItems[i]);
                }
            }
        } catch (ignored) {}
        return result;
    }

    function restoreResultName(items, oldName) {
        for (var i = 0; i < items.length; i++) {
            try {
                if (items[i].name && items[i].name.indexOf("__codex_embed_link_") === 0) {
                    items[i].name = oldName;
                }
            } catch (ignored) {}
        }
    }

    function getBounds(target) {
        try {
            var b = target.geometricBounds;
            return {
                left: b[0],
                top: b[1],
                right: b[2],
                bottom: b[3],
                width: b[2] - b[0],
                height: b[1] - b[3]
            };
        } catch (err) {
            return null;
        }
    }

    function getCombinedBounds(items) {
        var combined = null;

        for (var i = 0; i < items.length; i++) {
            var b = getBounds(items[i]);
            if (!b) {
                continue;
            }

            if (!combined) {
                combined = {
                    left: b.left,
                    top: b.top,
                    right: b.right,
                    bottom: b.bottom
                };
            } else {
                combined.left = Math.min(combined.left, b.left);
                combined.top = Math.max(combined.top, b.top);
                combined.right = Math.max(combined.right, b.right);
                combined.bottom = Math.min(combined.bottom, b.bottom);
            }
        }

        if (!combined) {
            return null;
        }

        combined.width = combined.right - combined.left;
        combined.height = combined.top - combined.bottom;
        return combined;
    }

    function restoreBounds(items, originalBounds) {
        if (!originalBounds) {
            return false;
        }

        var currentBounds = getCombinedBounds(items);
        if (!currentBounds) {
            return false;
        }

        var sizeTolerance = 0.01;
        if (
            items.length === 1 &&
            currentBounds.width > 0 &&
            currentBounds.height > 0 &&
            (Math.abs(currentBounds.width - originalBounds.width) > sizeTolerance ||
                Math.abs(currentBounds.height - originalBounds.height) > sizeTolerance)
        ) {
            try {
                var scaleX = (originalBounds.width / currentBounds.width) * 100;
                var scaleY = (originalBounds.height / currentBounds.height) * 100;
                items[0].resize(scaleX, scaleY, true, true, true, true, scaleX, Transformation.TOPLEFT);
                currentBounds = getCombinedBounds(items);
            } catch (resizeErr) {}
        }

        if (!currentBounds) {
            return false;
        }

        var dx = originalBounds.left - currentBounds.left;
        var dy = originalBounds.top - currentBounds.top;

        if (Math.abs(dx) < 0.001 && Math.abs(dy) < 0.001) {
            return true;
        }

        for (var i = 0; i < items.length; i++) {
            try {
                items[i].translate(dx, dy);
            } catch (translateErr) {}
        }

        return true;
    }

    function revealAndUnlock(item, states) {
        var current = item;
        while (current) {
            saveAndSet(current, "locked", false, states);
            saveAndSet(current, "hidden", false, states);
            saveAndSet(current, "visible", true, states);

            try {
                if (!current.parent || current === current.parent) break;
                current = current.parent;
            } catch (parentErr) {
                break;
            }
        }
    }

    function saveAndSet(target, property, value, states) {
        try {
            var oldValue = target[property];
            if (oldValue !== value) {
                states.push({
                    target: target,
                    property: property,
                    value: oldValue
                });
                target[property] = value;
            }
        } catch (ignored) {}
    }

    function restoreStates(states) {
        for (var i = states.length - 1; i >= 0; i--) {
            try {
                states[i].target[states[i].property] = states[i].value;
            } catch (ignored) {}
        }
    }
})();
