@echo off
setlocal EnableExtensions
pushd "%~dp0"
set "LOG_FILE=%~dp0install-log.txt"
> "%LOG_FILE%" echo [%date% %time%] Installer started from %~dp0

if /i "%~1"=="--elevated" goto :elevated

fltmc >nul 2>&1
if "%errorlevel%"=="0" goto :elevated

echo Requesting administrator permission...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "try { $p = Start-Process -FilePath '%~f0' -ArgumentList '--elevated' -Verb RunAs -WorkingDirectory '%~dp0' -Wait -PassThru; exit $p.ExitCode } catch { Write-Host $_.Exception.Message; exit 1 }"
if not "%errorlevel%"=="0" (
  echo.
  echo Installation did not start with administrator permission.
  echo Please right-click this BAT and choose Run as administrator.
  echo See log: %LOG_FILE%
  >> "%LOG_FILE%" echo Elevation failed or was cancelled.
  echo.
  pause
  exit /b
)
exit /b

:elevated
fltmc >nul 2>&1
if not "%errorlevel%"=="0" (
  echo Administrator permission was not obtained.
  echo Please right-click this BAT and choose Run as administrator.
  >> "%LOG_FILE%" echo Administrator check failed after elevation.
  echo.
  pause
  exit /b 1
)

set "FOUND=0"
set "SOURCE_COUNT=0"

for %%J in (*.jsx) do (
  set "SOURCE_COUNT=1"
  call :copyIllustrator "%%~fJ" "%%~nxJ"
)

if "%SOURCE_COUNT%"=="0" (
  echo No JSX plugin file was found beside this installer.
  echo Please extract the whole ZIP first, then double-click this BAT again.
  >> "%LOG_FILE%" echo No JSX source file was found.
) else if "%FOUND%"=="0" (
  echo No Photoshop or Illustrator script folder was found.
  echo Please confirm Adobe is installed under C:\Program Files\Adobe.
  >> "%LOG_FILE%" echo No supported Adobe script folder was found.
) else (
  echo.
  echo Installation completed successfully.
  echo Restart Adobe, then open File - Scripts to run the tool.
  >> "%LOG_FILE%" echo Installation completed successfully.
)

echo.
echo Log: %LOG_FILE%
pause
popd
exit /b

:installByName
set "FILE_NAME=%~2"
echo %FILE_NAME% | findstr /i "ai_ ai- 02_ai _ai illustrator" >nul
if "%errorlevel%"=="0" (
  call :copyIllustrator "%~1" "%~2"
  exit /b
)

echo %FILE_NAME% | findstr /i "ps_ ps- 01_ps _ps photoshop" >nul
if "%errorlevel%"=="0" (
  call :copyPhotoshop "%~1" "%~2"
  exit /b
)

call :copyPhotoshop "%~1" "%~2"
call :copyIllustrator "%~1" "%~2"
exit /b

:copyPhotoshop
for /d %%D in ("%ProgramFiles%\Adobe\Adobe Photoshop*") do (
  if exist "%%~fD\Presets\Scripts\" (
    copy /y "%~1" "%%~fD\Presets\Scripts\%~2" >> "%LOG_FILE%" 2>&1
    if errorlevel 1 (
      echo Failed [Photoshop] %%~nxD\Presets\Scripts\%~2
    ) else (
      echo Installed [Photoshop] %%~nxD\Presets\Scripts\%~2
      set "FOUND=1"
    )
  )
)
exit /b

:copyIllustrator
for /d %%D in ("%ProgramFiles%\Adobe\Adobe Illustrator*") do (
  set "COPIED_AI_DIR="
  if exist "%%~fD\Presets\" (
    for /d %%L in ("%%~fD\Presets\*") do (
      if not defined COPIED_AI_DIR if exist "%%~fL\Scripts\" (
        set "AI_TARGET_DIR=%%~fL\Scripts"
        call :copyIllustratorToDir "%~1" "%~2"
        set "AI_TARGET_DIR="
      )
    )
    if not defined COPIED_AI_DIR (
      for /f "delims=" %%F in ('dir /b /s /a-d "%%~fD\Presets\*.jsx" 2^>nul') do (
        if not defined COPIED_AI_DIR (
          set "AI_TARGET_DIR=%%~dpF"
          call :copyIllustratorToDir "%~1" "%~2"
          set "AI_TARGET_DIR="
        )
      )
    )
  )
)
exit /b

:copyIllustratorToDir
powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand JABQAHIAbwBnAHIAZQBzAHMAUAByAGUAZgBlAHIAZQBuAGMAZQAgAD0AIAAnAFMAaQBsAGUAbgB0AGwAeQBDAG8AbgB0AGkAbgB1AGUAJwA7ACAAJABwACAAPQAgAEoAbwBpAG4ALQBQAGEAdABoACAAJABlAG4AdgA6AEEASQBfAFQAQQBSAEcARQBUAF8ARABJAFIAIAAnAEEASQBfAABOLpVMXWVRQGIJZ/6UpWMuAGoAcwB4ACcAOwAgAGkAZgAgACgAVABlAHMAdAAtAFAAYQB0AGgAIAAtAEwAaQB0AGUAcgBhAGwAUABhAHQAaAAgACQAcAApACAAewAgAFIAZQBtAG8AdgBlAC0ASQB0AGUAbQAgAC0ATABpAHQAZQByAGEAbABQAGEAdABoACAAJABwACAALQBGAG8AcgBjAGUAIAB9AA== >> "%LOG_FILE%" 2>&1
copy /y "%~1" "%AI_TARGET_DIR%\%~2" >> "%LOG_FILE%" 2>&1
if errorlevel 1 (
  echo Failed [Illustrator] %AI_TARGET_DIR%\%~2
) else (
  echo Installed [Illustrator] %AI_TARGET_DIR%\%~2
  set "FOUND=1"
  set "COPIED_AI_DIR=1"
)
exit /b