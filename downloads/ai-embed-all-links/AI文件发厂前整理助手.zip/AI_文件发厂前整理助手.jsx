#target illustrator

(function () {
    if (app.documents.length < 1) {
        alert("请先打开一个 Illustrator 文件。");
        return;
    }

    var doc = app.activeDocument;
    var dialog = new Window("dialog", "AI文件发厂前整理助手");
    dialog.orientation = "column";
    dialog.alignChildren = ["fill", "top"];
    dialog.spacing = 12;
    dialog.margins = 18;

    var description = dialog.add(
        "statictext",
        undefined,
        "请选择要执行的操作。重要文件建议先另存一个副本。",
        { multiline: true }
    );
    description.preferredSize.width = 360;

    var embedButton = dialog.add("button", undefined, "嵌入");
    var cleanupButton = dialog.add("button", undefined, "删除隐藏 / 空白对象");
    var outlineButton = dialog.add("button", undefined, "一键文字转曲");
    var runAllButton = dialog.add("button", undefined, "一键执行全部");
    var statusText = dialog.add("statictext", undefined, "当前文件：" + getDocumentName(doc));
    statusText.preferredSize.width = 360;

    embedButton.onClick = function () {
        var result = embedAllLinks(doc);
        if (result) statusText.text = result;
    };

    cleanupButton.onClick = function () {
        var result = cleanupDocument(doc);
        if (result) statusText.text = result;
    };

    outlineButton.onClick = function () {
        var result = outlineAllText(doc);
        if (result) statusText.text = result;
    };

    runAllButton.onClick = function () {
        var result = runAllSteps(doc);
        if (result) statusText.text = result;
    };

    dialog.center();
    dialog.show();

    function setBusy(isBusy, text) {
        embedButton.enabled = !isBusy;
        cleanupButton.enabled = !isBusy;
        outlineButton.enabled = !isBusy;
        runAllButton.enabled = !isBusy;
        if (text) statusText.text = text;
        try {
            dialog.update();
        } catch (ignored) {}
    }

    function getDocumentName(targetDoc) {
        try {
            return targetDoc.name;
        } catch (ignored) {
            return "当前文档";
        }
    }

    function runAllSteps(targetDoc) {
        var ok = confirm(
            "将依次执行：清理隐藏/空白内容 → 嵌入链接 → 文字转曲。\n\n" +
            "对象较多时可能暂时未响应，请耐心等待，不要重复点击。\n" +
            "建议先另存副本。\n\n继续吗？"
        );
        if (!ok) return null;

        setBusy(true, "正在执行全部步骤，请耐心等待...");
        var results = [];
        results.push(cleanupDocument(targetDoc, true, true));
        results.push(embedAllLinks(targetDoc, true, true));
        results.push(outlineAllText(targetDoc, true, true));

        app.redraw();
        setBusy(false, "全部发厂整理步骤已执行");
        alert("全部完成。\n\n" + results.join("\n"));
        return "全部发厂整理步骤已执行";
    }

    function outlineAllText(targetDoc, skipConfirm, silent) {
        var ok = skipConfirm === true || confirm(
            "将全选可见、未锁定对象并创建文字轮廓。\n" +
            "隐藏或锁定文字不处理，转曲后文字不可编辑。\n\n继续吗？"
        );
        if (!ok) return null;

        if (silent !== true) setBusy(true, "正在进行文字转曲...");
        var originalSelection = getSelectionSnapshot(targetDoc);

        try {
            targetDoc.selection = null;
            app.executeMenuCommand("selectall");

            var selectedItems = getSelectionSnapshot(targetDoc);
            if (selectedItems.length < 1) {
                restoreSelection(targetDoc, originalSelection);
                if (silent !== true) setBusy(false, "没有可转曲对象");
                if (silent !== true) alert("当前文件没有可选择的对象。");
                return "没有可转曲对象";
            }

            app.executeMenuCommand("outline");
            app.redraw();
            if (silent !== true) setBusy(false, "文字转曲已完成");
            if (silent !== true) {
                alert("文字转曲完成。\n隐藏或锁定文字未处理。");
            }
            return "文字转曲已完成";
        } catch (err) {
            restoreSelection(targetDoc, originalSelection);
            if (silent !== true) setBusy(false, "文字转曲未完成");
            if (silent !== true) {
                alert("文字转曲未完成。\n\n可能没有可转曲文字，或当前对象状态不支持创建轮廓。\n\n" + err.message);
            }
            return "文字转曲未完成";
        }
    }

    function embedAllLinks(targetDoc, skipConfirm, silent) {
        var items = snapshotCollection(targetDoc.placedItems);
        if (items.length < 1) {
            if (silent !== true) alert("当前文件没有需要嵌入的外部链接。");
            return "没有检测到外部链接";
        }

        var ok = skipConfirm === true || confirm(
            "将嵌入 " + items.length + " 个外部链接。\n\n" +
            "不会自动编组或缩放；检测到位移时只校正位置。\n" +
            "建议先另存副本。\n\n继续吗？"
        );
        if (!ok) return null;

        if (silent !== true) setBusy(true, "正在嵌入链接...");
        var originalSelection = getSelectionSnapshot(targetDoc);
        var embedded = 0;
        var corrected = 0;
        var failed = 0;
        var firstError = "";

        for (var j = targetDoc.placedItems.length - 1; j >= 0; j--) {
            var completed = items.length - 1 - j;
            if (silent !== true && completed % 10 === 0) {
                statusText.text = "正在嵌入链接 " + (completed + 1) + " / " + items.length + "...";
                try {
                    dialog.update();
                } catch (ignoredProgress) {}
            }

            var item = targetDoc.placedItems[j];
            var states = [];
            var marker = "__codex_embed_" + (new Date().getTime()) + "_" + j + "__";
            var oldName = getSafeName(item);
            var itemState = getItemState(item);
            var beforeCount = getPlacedItemCount(targetDoc);
            var beforeBounds = getBounds(item);
            var resultItems = [];

            try {
                revealAndUnlock(item, states);
                try {
                    item.name = marker;
                } catch (nameErr) {}

                targetDoc.selection = null;
                item.selected = true;
                item.embed();
                app.redraw();

                resultItems = getSelectionSnapshot(targetDoc);
                if (resultItems.length < 1) resultItems = findItemsByName(targetDoc, marker);
                if (restorePosition(resultItems, beforeBounds)) corrected++;

                if (getPlacedItemCount(targetDoc) < beforeCount) {
                    embedded++;
                } else {
                    failed++;
                    if (!firstError) firstError = "Illustrator 执行嵌入后，该链接仍未嵌入。";
                }
            } catch (err) {
                failed++;
                if (!firstError) firstError = err.message || String(err);
            }

            if (resultItems.length < 1) resultItems = findItemsByName(targetDoc, marker);
            restoreResultName(resultItems, oldName);
            restoreResultState(resultItems, itemState);
            restoreStates(states);
        }

        var remaining = getPlacedItemCount(targetDoc);

        restoreSelection(targetDoc, originalSelection);
        app.redraw();

        var message = "嵌入完成。\n\n成功：" + embedded + " 个\n位置校正：" + corrected + " 个\n失败：" + failed + " 个\n剩余链接：" + remaining + " 个";
        if (failed > 0) {
            message += "\n\n失败原因：" + firstError;
            message += "\n缺失或不可用的链接请先在链接面板中重新链接。";
        }

        if (silent !== true) {
            setBusy(false, failed > 0 ? "已嵌入 " + embedded + " 个，失败 " + failed + " 个" : "已嵌入 " + embedded + " 个链接");
            alert(message);
        }

        if (failed > 0) return "已嵌入 " + embedded + " 个，失败 " + failed + " 个";
        return "已嵌入 " + embedded + " 个链接";
    }

    function getPlacedItemCount(targetDoc) {
        try {
            return targetDoc.placedItems.length;
        } catch (ignored) {
            return 0;
        }
    }

    function getBounds(target) {
        try {
            var bounds = target.geometricBounds;
            return {
                left: bounds[0],
                top: bounds[1],
                right: bounds[2],
                bottom: bounds[3]
            };
        } catch (ignored) {
            return null;
        }
    }

    function getCombinedBounds(items) {
        var combined = null;

        for (var i = 0; i < items.length; i++) {
            var bounds = getBounds(items[i]);
            if (!bounds) continue;

            if (!combined) {
                combined = {
                    left: bounds.left,
                    top: bounds.top,
                    right: bounds.right,
                    bottom: bounds.bottom
                };
            } else {
                combined.left = Math.min(combined.left, bounds.left);
                combined.top = Math.max(combined.top, bounds.top);
                combined.right = Math.max(combined.right, bounds.right);
                combined.bottom = Math.min(combined.bottom, bounds.bottom);
            }
        }

        return combined;
    }

    function restorePosition(items, originalBounds) {
        if (!originalBounds || items.length < 1) return false;

        var currentBounds = getCombinedBounds(items);
        if (!currentBounds) return false;

        var dx = originalBounds.left - currentBounds.left;
        var dy = originalBounds.top - currentBounds.top;
        if (Math.abs(dx) < 0.001 && Math.abs(dy) < 0.001) return false;

        for (var i = 0; i < items.length; i++) {
            try {
                items[i].translate(dx, dy);
            } catch (ignoredTranslate) {}
        }
        return true;
    }

    function cleanupDocument(targetDoc, skipConfirm, silent) {
        var ok = skipConfirm === true || confirm(
            "将删除隐藏图层/对象、空文本、空编组和空图层。\n" +
            "隐藏路径会删除，未隐藏路径会保留。\n\n" +
            "对象较多时删除可能会卡顿，请耐心等待，不要重复点击。\n" +
            "建议先另存副本。\n\n继续吗？"
        );
        if (!ok) return null;

        if (silent !== true) setBusy(true, "正在删除对象，可能会卡顿，请耐心等待...");
        var stats = {
            hiddenLayers: 0,
            hiddenObjects: 0,
            emptyTexts: 0,
            emptyGroups: 0,
            emptyLayers: 0,
            retainedRootLayer: 0,
            failed: 0
        };
        var originalSelection = getSelectionSnapshot(targetDoc);

        removeHiddenLayers(targetDoc, stats);
        removeHiddenAndBlankItems(targetDoc, stats);

        app.redraw();
        restoreSelection(targetDoc, originalSelection);

        var removedTotal = stats.hiddenLayers + stats.hiddenObjects +
            stats.emptyTexts + stats.emptyGroups + stats.emptyLayers;

        var message =
            "清理完成。\n\n" +
            "隐藏图层：" + stats.hiddenLayers + "\n" +
            "隐藏对象：" + stats.hiddenObjects + "\n" +
            "空文本：" + stats.emptyTexts + "\n" +
            "空编组：" + stats.emptyGroups + "\n" +
            "空图层：" + stats.emptyLayers + "\n\n" +
            "共删除：" + removedTotal + " 项";

        if (stats.retainedRootLayer > 0) {
            message += "\n\nIllustrator 必须保留至少一个主图层，最后一个空主图层未删除。";
        }
        if (stats.failed > 0) {
            message += "\n\n另有 " + stats.failed + " 项无法删除，请人工检查锁定或特殊对象。";
        }

        if (silent !== true) {
            setBusy(false, "已清理 " + removedTotal + " 项");
            alert(message);
        }
        return "已清理 " + removedTotal + " 项";
    }

    function removeHiddenLayers(targetDoc, stats) {
        var layers = [];
        collectLayers(targetDoc, layers);
        layers.sort(function (a, b) {
            return getLayerDepth(b) - getLayerDepth(a);
        });

        for (var i = 0; i < layers.length; i++) {
            if (i % 50 === 0) {
                statusText.text = "正在检查隐藏图层 " + i + " / " + layers.length + "...";
                try {
                    dialog.update();
                } catch (ignoredProgress) {}
            }

            var layer = layers[i];
            if (!isLayerVisible(layer) && !hasHiddenLayerAncestor(layer)) {
                ensureReplacementRootLayer(targetDoc, layer);
                if (removeTarget(layer)) stats.hiddenLayers++;
                else stats.failed++;
            }
        }
    }

    function ensureReplacementRootLayer(targetDoc, layer) {
        try {
            if (getTypeName(layer.parent) === "Document" && targetDoc.layers.length <= 1) {
                var replacement = targetDoc.layers.add();
                replacement.name = "发厂整理保留层";
                replacement.visible = true;
                replacement.locked = false;
            }
        } catch (ignored) {}
    }

    function removeHiddenAndBlankItems(targetDoc, stats) {
        var items = snapshotCollection(targetDoc.pageItems);
        items.sort(function (a, b) {
            return getItemDepth(b) - getItemDepth(a);
        });

        for (var i = 0; i < items.length; i++) {
            if (i % 200 === 0) {
                statusText.text = "正在扫描对象 " + i + " / " + items.length + "，请耐心等待...";
                try {
                    dialog.update();
                } catch (ignoredProgress) {}
            }

            var item = items[i];
            if (isItemHidden(item) && !hasHiddenPageItemAncestor(item) && !hasHiddenLayerAncestor(item)) {
                if (removeTarget(item)) stats.hiddenObjects++;
                else stats.failed++;
                continue;
            }

            var blankType = getBlankType(item);
            if (!blankType) continue;

            if (removeTarget(item)) stats[blankType]++;
            else stats.failed++;
        }

        var layers = [];
        collectLayers(targetDoc, layers);
        layers.sort(function (a, b) {
            return getLayerDepth(b) - getLayerDepth(a);
        });

        for (var j = 0; j < layers.length; j++) {
            if (j % 50 === 0) {
                statusText.text = "正在整理图层 " + j + " / " + layers.length + "...";
                try {
                    dialog.update();
                } catch (ignoredLayerProgress) {}
            }

            var layer = layers[j];
            if (!isLayerEmpty(layer)) continue;

            if (isOnlyRootLayer(targetDoc, layer)) {
                stats.retainedRootLayer = 1;
                continue;
            }

            if (removeTarget(layer)) stats.emptyLayers++;
            else stats.failed++;
        }
    }

    function getItemDepth(item) {
        var depth = 0;
        var current = getParent(item);
        while (current) {
            if (isPageItemType(getTypeName(current))) depth++;
            current = getParent(current);
        }
        return depth;
    }

    function getBlankType(item) {
        var type = getTypeName(item);

        if (type === "TextFrame" || type === "LegacyTextItem") {
            try {
                if (String(item.contents).replace(/\s/g, "") === "") return "emptyTexts";
            } catch (ignoredText) {}
            return null;
        }

        if (type === "GroupItem") {
            try {
                if (item.pageItems.length === 0) return "emptyGroups";
            } catch (ignoredGroup) {}
        }

        return null;
    }

    function isLayerEmpty(layer) {
        try {
            return layer.pageItems.length === 0 && layer.layers.length === 0;
        } catch (ignored) {
            return false;
        }
    }

    function isOnlyRootLayer(targetDoc, layer) {
        try {
            return getTypeName(layer.parent) === "Document" && targetDoc.layers.length <= 1;
        } catch (ignored) {
            return false;
        }
    }

    function getLayerDepth(layer) {
        var depth = 0;
        var current = getParent(layer);
        while (current && getTypeName(current) === "Layer") {
            depth++;
            current = getParent(current);
        }
        return depth;
    }

    function collectLayers(container, result) {
        try {
            for (var i = 0; i < container.layers.length; i++) {
                var layer = container.layers[i];
                result.push(layer);
                collectLayers(layer, result);
            }
        } catch (ignored) {}
    }

    function snapshotCollection(collection) {
        var result = [];
        try {
            for (var i = 0; i < collection.length; i++) result.push(collection[i]);
        } catch (ignored) {}
        return result;
    }

    function isLayerVisible(layer) {
        try {
            return layer.visible !== false;
        } catch (ignored) {
            return true;
        }
    }

    function isItemHidden(item) {
        try {
            return item.hidden === true;
        } catch (ignored) {
            return false;
        }
    }

    function hasHiddenLayerAncestor(target) {
        var current = getParent(target);
        while (current) {
            if (getTypeName(current) === "Layer" && !isLayerVisible(current)) return true;
            current = getParent(current);
        }
        return false;
    }

    function hasHiddenPageItemAncestor(item) {
        var current = getParent(item);
        while (current) {
            var type = getTypeName(current);
            if (isPageItemType(type) && isItemHidden(current)) return true;
            current = getParent(current);
        }
        return false;
    }

    function isPageItemType(type) {
        return type && type !== "Layer" && type !== "Document" && type !== "Application";
    }

    function getParent(target) {
        try {
            if (!target.parent || target.parent === target) return null;
            return target.parent;
        } catch (ignored) {
            return null;
        }
    }

    function getTypeName(target) {
        try {
            return target.typename || "";
        } catch (ignored) {
            return "";
        }
    }

    function removeTarget(target) {
        var states = [];
        try {
            revealAndUnlock(target, states);
            target.remove();
            return true;
        } catch (ignored) {
            return false;
        } finally {
            restoreStates(states);
        }
    }

    function getItemState(item) {
        return {
            locked: getSafeProperty(item, "locked"),
            hidden: getSafeProperty(item, "hidden"),
            visible: getSafeProperty(item, "visible")
        };
    }

    function getSafeProperty(item, property) {
        try {
            return item[property];
        } catch (ignored) {
            return null;
        }
    }

    function restoreResultState(items, state) {
        if (!state) return;

        for (var i = 0; i < items.length; i++) {
            if (state.visible !== null) {
                try {
                    items[i].visible = state.visible;
                } catch (visibleErr) {}
            }
            if (state.hidden !== null) {
                try {
                    items[i].hidden = state.hidden;
                } catch (hiddenErr) {}
            }
            if (state.locked !== null) {
                try {
                    items[i].locked = state.locked;
                } catch (lockedErr) {}
            }
        }
    }

    function getSafeName(item) {
        try {
            return item.name || "";
        } catch (ignored) {
            return "";
        }
    }

    function getSelectionSnapshot(targetDoc) {
        var result = [];
        try {
            if (targetDoc.selection && targetDoc.selection.length) {
                for (var i = 0; i < targetDoc.selection.length; i++) result.push(targetDoc.selection[i]);
            }
        } catch (ignored) {}
        return result;
    }

    function restoreSelection(targetDoc, selectionItems) {
        try {
            targetDoc.selection = null;
        } catch (clearErr) {}

        for (var i = 0; i < selectionItems.length; i++) {
            try {
                selectionItems[i].selected = true;
            } catch (ignored) {}
        }
    }

    function findItemsByName(targetDoc, marker) {
        var result = [];
        try {
            for (var i = 0; i < targetDoc.pageItems.length; i++) {
                if (targetDoc.pageItems[i].name === marker) result.push(targetDoc.pageItems[i]);
            }
        } catch (ignored) {}
        return result;
    }

    function restoreResultName(items, oldName) {
        for (var i = 0; i < items.length; i++) {
            try {
                if (items[i].name && items[i].name.indexOf("__codex_embed_") === 0) {
                    items[i].name = oldName;
                }
            } catch (ignored) {}
        }
    }

    function revealAndUnlock(item, states) {
        var current = item;
        while (current) {
            saveAndSet(current, "locked", false, states);
            saveAndSet(current, "hidden", false, states);
            saveAndSet(current, "visible", true, states);

            try {
                if (!current.parent || current === current.parent) break;
                current = current.parent;
            } catch (parentErr) {
                break;
            }
        }
    }

    function saveAndSet(target, property, value, states) {
        try {
            var oldValue = target[property];
            if (oldValue !== value) {
                states.push({ target: target, property: property, value: oldValue });
                target[property] = value;
            }
        } catch (ignored) {}
    }

    function restoreStates(states) {
        for (var i = states.length - 1; i >= 0; i--) {
            try {
                states[i].target[states[i].property] = states[i].value;
            } catch (ignored) {}
        }
    }
})();
