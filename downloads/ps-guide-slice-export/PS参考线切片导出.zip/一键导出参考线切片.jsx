#target photoshop

/*
One-click export slices by guides
Photoshop 2020-2026 compatible JSX script.

Menu name follows this file name: one-click-export-guide-slices in Chinese.

What it does:
1. Reads the current document guides.
2. Uses canvas edges plus horizontal/vertical guides as slice boundaries.
3. Lets the user choose PNG or JPG.
4. After clicking Save, asks for an output folder.
5. Exports each slice at the highest practical quality.

Notes:
- The source PSD is not edited. Every slice is exported from a temporary duplicate.
- JPG export adds a white background before flattening.
- PNG export keeps transparency.

Shortcut:
Set it in Photoshop:
Edit > Keyboard Shortcuts > Application Menus > File > Scripts.
*/

app.bringToFront();

var __GSE_DOC = app.documents.length ? app.activeDocument : null;

(function () {
    if (!__GSE_DOC) {
        alert("Please open a Photoshop document first.");
        return;
    }

    var oldUnits = app.preferences.rulerUnits;
    var oldDialogs = app.displayDialogs;
    app.preferences.rulerUnits = Units.PIXELS;
    app.displayDialogs = DialogModes.NO;

    try {
        var guideData = __GSE_collectGuideData(__GSE_DOC);
        if (!guideData.hasGuides) {
            alert("\u5f53\u524d\u6587\u6863\u6ca1\u6709\u53c2\u8003\u7ebf\u3002\n\u8bf7\u5148\u7528\u53c2\u8003\u7ebf\u6807\u51fa\u9700\u8981\u5207\u7247\u7684\u8fb9\u754c\u3002");
            return;
        }

        var slices = __GSE_buildSlices(guideData.xs, guideData.ys);
        if (!slices.length) {
            alert("\u6ca1\u6709\u627e\u5230\u53ef\u5bfc\u51fa\u7684\u5207\u7247\u3002\n\u8bf7\u786e\u8ba4\u53c2\u8003\u7ebf\u4e4b\u95f4\u81f3\u5c11\u95f4\u9694 1 px\u3002");
            return;
        }

        var settings = __GSE_chooseSettings(slices.length);
        if (!settings) {
            return;
        }

        var outputFolder = Folder.selectDialog("\u9009\u62e9\u5207\u7247\u5bfc\u51fa\u6587\u4ef6\u5939");
        if (!outputFolder) {
            return;
        }

        __GSE_exportSlices(__GSE_DOC, slices, outputFolder, settings.format, guideData);
    } catch (e) {
        alert("\u5bfc\u51fa\u5931\u8d25\uff1a\n" + e.message);
    } finally {
        app.preferences.rulerUnits = oldUnits;
        app.displayDialogs = oldDialogs;
        try {
            app.activeDocument = __GSE_DOC;
        } catch (focusError) {
            // Original document may have been closed by the user.
        }
    }
})();

function __GSE_chooseSettings(sliceCount) {
    try {
        var dialog = new Window("dialog", "\u4e00\u952e\u5bfc\u51fa\u53c2\u8003\u7ebf\u5207\u7247");
        dialog.orientation = "column";
        dialog.alignChildren = "fill";
        dialog.margins = 18;

        var title = dialog.add("statictext", undefined, "\u9009\u62e9\u5bfc\u51fa\u683c\u5f0f\uff08\u5171 " + sliceCount + " \u5f20\uff09");
        title.alignment = "left";

        var formatPanel = dialog.add("panel", undefined, "\u683c\u5f0f");
        formatPanel.orientation = "column";
        formatPanel.alignChildren = "left";
        formatPanel.margins = 14;

        var pngOption = formatPanel.add("radiobutton", undefined, "PNG\uff08\u4fdd\u7559\u900f\u660e\uff09");
        var jpgOption = formatPanel.add("radiobutton", undefined, "JPG\uff08\u6700\u9ad8\u8d28\u91cf\uff0c\u767d\u8272\u80cc\u666f\uff09");
        pngOption.value = true;

        var buttons = dialog.add("group");
        buttons.alignment = "right";
        var saveButton = buttons.add("button", undefined, "\u4fdd\u5b58", { name: "ok" });
        var cancelButton = buttons.add("button", undefined, "\u53d6\u6d88", { name: "cancel" });

        saveButton.onClick = function () {
            dialog.close(1);
        };
        cancelButton.onClick = function () {
            dialog.close(0);
        };

        if (dialog.show() !== 1) {
            return null;
        }

        return {
            format: jpgOption.value ? "jpg" : "png"
        };
    } catch (e) {
        var choice = prompt("\u8bf7\u8f93\u5165\u5bfc\u51fa\u683c\u5f0f\uff1aPNG \u6216 JPG", "PNG");
        if (choice === null) {
            return null;
        }

        choice = String(choice).replace(/^\s+|\s+$/g, "").toLowerCase();
        return {
            format: choice === "jpg" || choice === "jpeg" ? "jpg" : "png"
        };
    }
}

function __GSE_collectGuideData(doc) {
    var widthPx = __GSE_unitToPx(doc.width);
    var heightPx = __GSE_unitToPx(doc.height);
    var verticals = [];
    var horizontals = [];

    for (var i = 0; i < doc.guides.length; i++) {
        var guide = doc.guides[i];
        var position = Math.round(__GSE_unitToPx(guide.coordinate));

        if (__GSE_isVerticalGuide(guide)) {
            if (position > 0 && position < widthPx) {
                verticals.push(position);
            }
        } else {
            if (position > 0 && position < heightPx) {
                horizontals.push(position);
            }
        }
    }

    verticals = __GSE_uniqueSorted(verticals);
    horizontals = __GSE_uniqueSorted(horizontals);

    return {
        width: widthPx,
        height: heightPx,
        verticals: verticals,
        horizontals: horizontals,
        xs: [0].concat(verticals).concat([widthPx]),
        ys: [0].concat(horizontals).concat([heightPx]),
        hasGuides: verticals.length > 0 || horizontals.length > 0
    };
}

function __GSE_buildSlices(xs, ys) {
    var slices = [];
    var rowCount = Math.max(0, ys.length - 1);
    var colCount = Math.max(0, xs.length - 1);

    for (var row = 0; row < rowCount; row++) {
        for (var col = 0; col < colCount; col++) {
            var left = xs[col];
            var top = ys[row];
            var right = xs[col + 1];
            var bottom = ys[row + 1];

            if (right - left >= 1 && bottom - top >= 1) {
                slices.push({
                    left: left,
                    top: top,
                    right: right,
                    bottom: bottom,
                    row: row + 1,
                    col: col + 1,
                    rows: rowCount,
                    cols: colCount,
                    index: slices.length + 1
                });
            }
        }
    }

    return slices;
}

function __GSE_exportSlices(sourceDoc, slices, outputFolder, format, guideData) {
    var baseName = __GSE_baseName(sourceDoc.name);
    var exportFolder = __GSE_uniqueFolder(outputFolder, baseName + "_guide_slices");
    if (!exportFolder.exists && !exportFolder.create()) {
        throw new Error("\u65e0\u6cd5\u521b\u5efa\u5bfc\u51fa\u6587\u4ef6\u5939\uff1a" + exportFolder.fsName);
    }

    var exported = 0;
    var skipped = [];

    for (var i = 0; i < slices.length; i++) {
        var slice = slices[i];
        var filename = __GSE_buildSliceName(baseName, slice, format);
        var file = __GSE_uniqueFile(exportFolder, filename);

        try {
            __GSE_exportOneSlice(sourceDoc, slice, file, format);
            exported++;
        } catch (sliceError) {
            skipped.push(__GSE_pad(slice.index, 3) + "\uff1a" + sliceError.message);
        }
    }

    var message = "\u5bfc\u51fa\u5b8c\u6210\uff1a" + exported + " \u5f20 " + format.toUpperCase() + "\u3002";
    message += "\n\n\u4fdd\u5b58\u4f4d\u7f6e\uff1a\n" + exportFolder.fsName;
    message += "\n\n\u5207\u7247\u8303\u56f4\uff1a" + guideData.width + " x " + guideData.height + " px";
    if (skipped.length) {
        message += "\n\n\u8df3\u8fc7\uff1a\n" + skipped.join("\n");
    }

    alert(message);
}

function __GSE_exportOneSlice(sourceDoc, slice, file, format) {
    var tempDoc = null;

    app.activeDocument = sourceDoc;
    try {
        tempDoc = __GSE_duplicateForExport(sourceDoc);
        app.activeDocument = tempDoc;

        tempDoc.crop([
            UnitValue(slice.left, "px"),
            UnitValue(slice.top, "px"),
            UnitValue(slice.right, "px"),
            UnitValue(slice.bottom, "px")
        ]);

        if (format === "jpg") {
            __GSE_prepareJpgBackground(tempDoc);
            __GSE_exportJpg(tempDoc, file);
        } else {
            __GSE_exportPng(tempDoc, file);
        }
    } finally {
        if (tempDoc) {
            __GSE_closeNoSave(tempDoc);
        }
        try {
            app.activeDocument = sourceDoc;
        } catch (e) {
            // Original document may have been closed by the user.
        }
    }
}

function __GSE_duplicateForExport(sourceDoc) {
    try {
        return sourceDoc.duplicate("__guide_slice_export_temp__", true);
    } catch (e) {
        return sourceDoc.duplicate("__guide_slice_export_temp__", false);
    }
}

function __GSE_prepareJpgBackground(doc) {
    app.activeDocument = doc;

    var white = new SolidColor();
    white.rgb.red = 255;
    white.rgb.green = 255;
    white.rgb.blue = 255;

    var bg = doc.artLayers.add();
    bg.name = "__jpg_white_background__";
    doc.selection.selectAll();
    doc.selection.fill(white, ColorBlendMode.NORMAL, 100, false);
    doc.selection.deselect();

    try {
        bg.move(doc, ElementPlacement.PLACEATEND);
    } catch (e) {
        try {
            bg.move(doc.layers[doc.layers.length - 1], ElementPlacement.PLACEAFTER);
        } catch (e2) {
            // If moving fails, flattening for JPEG still uses a white-filled layer.
        }
    }

    doc.flatten();
}

function __GSE_exportPng(doc, file) {
    app.activeDocument = doc;

    var options = new ExportOptionsSaveForWeb();
    options.format = SaveDocumentType.PNG;
    options.PNG8 = false;
    options.transparency = true;
    options.interlaced = false;
    options.includeProfile = true;

    doc.exportDocument(file, ExportType.SAVEFORWEB, options);
}

function __GSE_exportJpg(doc, file) {
    app.activeDocument = doc;

    var options = new ExportOptionsSaveForWeb();
    options.format = SaveDocumentType.JPEG;
    options.quality = 100;
    options.optimized = true;
    options.includeProfile = true;

    doc.exportDocument(file, ExportType.SAVEFORWEB, options);
}

function __GSE_isVerticalGuide(guide) {
    try {
        if (guide.direction === Direction.VERTICAL) {
            return true;
        }
        if (guide.direction === Direction.HORIZONTAL) {
            return false;
        }
    } catch (e) {
        // Fall back to string matching below.
    }

    return String(guide.direction).toLowerCase().indexOf("vertical") >= 0;
}

function __GSE_unitToPx(value) {
    try {
        return Number(value.as("px"));
    } catch (e) {
        return Number(value);
    }
}

function __GSE_uniqueSorted(values) {
    values.sort(function (a, b) {
        return a - b;
    });

    var result = [];
    var last = null;
    for (var i = 0; i < values.length; i++) {
        var value = Math.round(Number(values[i]));
        if (isNaN(value)) {
            continue;
        }
        if (last === null || Math.abs(value - last) >= 1) {
            result.push(value);
            last = value;
        }
    }

    return result;
}

function __GSE_buildSliceName(baseName, slice, format) {
    var suffix;
    if (slice.rows > 1 && slice.cols > 1) {
        suffix = "r" + __GSE_pad(slice.row, 2) + "_c" + __GSE_pad(slice.col, 2);
    } else {
        suffix = __GSE_pad(slice.index, 3);
    }

    return __GSE_cleanName(baseName, "document") + "_slice_" + suffix + "." + format;
}

function __GSE_baseName(name) {
    var base = String(name || "document").replace(/\.[^\.]+$/, "");
    return __GSE_cleanName(base, "document");
}

function __GSE_uniqueFolder(parent, name) {
    var base = __GSE_cleanName(name, "guide_slices");
    var folder = new Folder(parent.fsName + "/" + base);
    var index = 2;

    while (folder.exists) {
        folder = new Folder(parent.fsName + "/" + base + "_" + index);
        index++;
    }

    return folder;
}

function __GSE_uniqueFile(folder, filename) {
    var cleaned = __GSE_cleanName(filename, "slice.png");
    var dot = cleaned.lastIndexOf(".");
    var name = dot >= 0 ? cleaned.substring(0, dot) : cleaned;
    var ext = dot >= 0 ? cleaned.substring(dot) : "";
    var file = new File(folder.fsName + "/" + cleaned);
    var index = 2;

    while (file.exists) {
        file = new File(folder.fsName + "/" + name + "_" + index + ext);
        index++;
    }

    return file;
}

function __GSE_cleanName(name, fallback) {
    var cleaned = String(name || "")
        .replace(/[\\\/:\*\?"<>\|]/g, "_")
        .replace(/^\s+|\s+$/g, "")
        .replace(/[\. ]+$/g, "");

    if (!cleaned) {
        cleaned = fallback;
    }

    return cleaned;
}

function __GSE_pad(number, size) {
    var text = String(number);
    while (text.length < size) {
        text = "0" + text;
    }
    return text;
}

function __GSE_closeNoSave(doc) {
    try {
        doc.close(SaveOptions.DONOTSAVECHANGES);
    } catch (e) {
        // Ignore close failures.
    }
}
