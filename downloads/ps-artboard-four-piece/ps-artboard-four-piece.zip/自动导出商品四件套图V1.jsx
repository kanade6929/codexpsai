#target photoshop

/*
Batch export artboard product image set
Photoshop 2020-2025 compatible JSX script.

Menu name follows this file name: batch-export-artboard-product-set in Chinese.

PSD structure:
Each artboard is one product. The artboard name is the product name.
Each artboard must contain three direct children, from top to bottom:
1. Product image/group. If this is a group, the entire group is exported.
2. Text layer/group
3. Background image/group

Exports per artboard:
1. transparent-1280-product.png -> product only, centered, transparent background
2. white-1280-product.jpg       -> product only, centered, white background
3. main-1280-product.jpg        -> product + text + background
4. transparent-800-product.png  -> product only, centered, transparent background.
   The whole 1280 composition is scaled to 800x800. It is never cropped to
   the product bounds or re-centered.

Shortcut:
Set it in Photoshop:
Edit > Keyboard Shortcuts > Application Menus > File > Scripts.

Run modes:
1. Build adjustment PSD and export all 4 files.
2. Re-export adjusted product files from the current adjustment PSD.
*/

app.bringToFront();

var __AB4_DOC = app.documents.length ? app.activeDocument : null;
var __AB4_LEFT_OPEN_DOC = null;
var __AB4_MODE_BUILD_AND_EXPORT = "buildAndExport";
var __AB4_MODE_EXPORT_ADJUSTED = "exportAdjusted";

(function () {
    if (!__AB4_DOC) {
        alert("Please open a Photoshop document first.");
        return;
    }

    var runMode = __AB4_chooseRunMode();
    if (!runMode) {
        return;
    }

    var outputRoot = Folder.selectDialog("\u9009\u62e9\u5bfc\u51fa\u6587\u4ef6\u5939");
    if (!outputRoot) {
        return;
    }

    var oldUnits = app.preferences.rulerUnits;
    app.preferences.rulerUnits = Units.PIXELS;

    try {
        if (runMode === __AB4_MODE_EXPORT_ADJUSTED) {
            __AB4_exportAdjustedArtboardsFromCurrentDoc(__AB4_DOC, outputRoot);
        } else {
            __AB4_exportAllArtboards(__AB4_DOC, outputRoot);
        }
    } catch (e) {
        alert("\u5bfc\u51fa\u5931\u8d25\uff1a\n" + e.message);
    } finally {
        app.preferences.rulerUnits = oldUnits;
        try {
            app.activeDocument = __AB4_LEFT_OPEN_DOC ? __AB4_LEFT_OPEN_DOC : __AB4_DOC;
        } catch (e2) {
            // Original document may have been closed by the user.
        }
    }
})();

function __AB4_chooseRunMode() {
    try {
        var dialog = new Window("dialog", "\u81ea\u52a8\u5bfc\u51fa\u5546\u54c1\u56db\u4ef6\u5957");
        dialog.orientation = "column";
        dialog.alignChildren = "fill";
        dialog.margins = 18;

        var title = dialog.add("statictext", undefined, "\u8bf7\u9009\u62e9\u672c\u6b21\u8981\u6267\u884c\u7684\u64cd\u4f5c\uff1a");
        title.alignment = "left";

        var buildOption = dialog.add("radiobutton", undefined, "\u5236\u4f5c\u6587\u6863\u5e76\u5bfc\u51fa\u7d20\u6750\u56fe");
        var exportOption = dialog.add("radiobutton", undefined, "\u5bfc\u51fa\u7d20\u6750\u56fe");
        buildOption.value = true;

        var note = dialog.add("statictext", undefined, "\u7b2c 2 \u9879\u7528\u4e8e\u8c03\u6574 PSD\uff1a\u6309\u5f53\u524d\u753b\u9762\u72b6\u6001\u5bfc\u51fa\uff0c\u4e0d\u91cd\u65b0\u5c45\u4e2d\u3002");
        note.alignment = "left";

        var buttons = dialog.add("group");
        buttons.alignment = "right";
        var okButton = buttons.add("button", undefined, "\u786e\u5b9a", { name: "ok" });
        var cancelButton = buttons.add("button", undefined, "\u53d6\u6d88", { name: "cancel" });

        okButton.onClick = function () {
            dialog.close(1);
        };
        cancelButton.onClick = function () {
            dialog.close(0);
        };

        if (dialog.show() !== 1) {
            return null;
        }

        return exportOption.value ? __AB4_MODE_EXPORT_ADJUSTED : __AB4_MODE_BUILD_AND_EXPORT;
    } catch (e) {
        var choice = prompt(
            "\u8bf7\u8f93\u5165\u6a21\u5f0f\uff1a\n1 = \u5236\u4f5c\u6587\u6863\u5e76\u5bfc\u51fa\u7d20\u6750\u56fe\n2 = \u5bfc\u51fa\u7d20\u6750\u56fe",
            "1"
        );

        if (choice === null) {
            return null;
        }

        return String(choice).replace(/^\s+|\s+$/g, "") === "2" ? __AB4_MODE_EXPORT_ADJUSTED : __AB4_MODE_BUILD_AND_EXPORT;
    }
}

function __AB4_exportAllArtboards(sourceDoc, outputRoot) {
    var exportedCount = 0;
    var skipped = [];
    var usedFolderNames = {};
    var exportRecords = [];
    var workDoc = null;
    var keepWorkDocOpen = false;

    app.activeDocument = sourceDoc;

    try {
        // Duplicating a large PSD once is much faster than duplicating it for
        // every artboard. All visibility edits happen in this temporary copy.
        workDoc = sourceDoc.duplicate("\u81ea\u52a8\u5bfc\u51fa\u5546\u54c1\u56db\u4ef6\u5957_\u8c03\u6574\u7528", false);
        app.activeDocument = workDoc;

        var artboards = __AB4_collectVisibleArtboards(workDoc);
        if (!artboards.length) {
            alert("\u6ca1\u6709\u627e\u5230\u53ef\u89c1\u753b\u677f\u3002\u8bf7\u786e\u8ba4\u81f3\u5c11\u6709\u4e00\u4e2a\u753b\u677f\u5f00\u542f\u773c\u775b\u53ef\u89c1\u3002");
            return;
        }

        keepWorkDocOpen = true;

        for (var i = 0; i < artboards.length; i++) {
            var item = artboards[i];
            var productName = __AB4_cleanName(item.layer.name, "\u672a\u547d\u540d\u5546\u54c1");
            var folderName = __AB4_uniqueName(productName, usedFolderNames);
            var productFolder = new Folder(outputRoot.fsName + "/" + folderName);

            if (!productFolder.exists && !productFolder.create()) {
                skipped.push(productName + "\uff1a\u65e0\u6cd5\u521b\u5efa\u6587\u4ef6\u5939");
                continue;
            }

            var record = __AB4_createExportRecord(workDoc, item.layer, productName, productFolder);
            if (record) {
                __AB4_exportMainJpg(
                    workDoc,
                    record.rect,
                    record.mainJpgFile
                );
                exportRecords.push(record);
            } else {
                skipped.push(productName + "\uff1a\u753b\u677f\u4e0b\u65b9\u5c11\u4e8e 3 \u4e2a\u76f4\u5c5e\u5bf9\u8c61");
            }
        }

        __AB4_prepareAdjustmentDocument(workDoc, exportRecords);

        for (var j = 0; j < exportRecords.length; j++) {
            __AB4_exportAdjustedProductSet(workDoc, exportRecords[j]);
            exportedCount++;
        }
    } finally {
        if (workDoc) {
            if (keepWorkDocOpen) {
                __AB4_LEFT_OPEN_DOC = workDoc;
                try {
                    app.activeDocument = workDoc;
                } catch (e) {
                    // Leave the document open even if focusing it fails.
                }
            } else {
                __AB4_closeNoSave(workDoc);
                try {
                    app.activeDocument = sourceDoc;
                } catch (e2) {
                    // Original document may have been closed by the user.
                }
            }
        }
    }

    var message = "\u5bfc\u51fa\u5b8c\u6210\uff1a" + exportedCount + " \u4e2a\u753b\u677f\u3002";
    if (skipped.length) {
        message += "\n\n\u8df3\u8fc7\uff1a\n" + skipped.join("\n");
    }
    if (__AB4_LEFT_OPEN_DOC) {
        message += "\n\n\u5df2\u4fdd\u7559\u4e00\u4e2a\u8c03\u6574\u7528 PSD \u526f\u672c\uff0c\u53ef\u7528\u4e8e\u624b\u52a8\u5fae\u8c03\u3002";
    }

    alert(message);
}

function __AB4_exportAdjustedArtboardsFromCurrentDoc(sourceDoc, outputRoot) {
    var exportedCount = 0;
    var skipped = [];
    var usedFolderNames = {};

    app.activeDocument = sourceDoc;

    var artboards = __AB4_collectVisibleArtboards(sourceDoc);
    if (!artboards.length) {
        alert("\u6ca1\u6709\u627e\u5230\u53ef\u89c1\u753b\u677f\u3002\u8bf7\u786e\u8ba4\u8c03\u6574 PSD \u91cc\u81f3\u5c11\u6709\u4e00\u4e2a\u753b\u677f\u5f00\u542f\u773c\u775b\u53ef\u89c1\u3002");
        return;
    }

    for (var i = 0; i < artboards.length; i++) {
        var artboard = artboards[i].layer;
        var productName = __AB4_cleanName(artboard.name, "\u672a\u547d\u540d\u5546\u54c1");
        var folderName = __AB4_uniqueName(productName, usedFolderNames);
        var productFolder = new Folder(outputRoot.fsName + "/" + folderName);

        if (!productFolder.exists && !productFolder.create()) {
            skipped.push(productName + "\uff1a\u65e0\u6cd5\u521b\u5efa\u6587\u4ef6\u5939");
            continue;
        }

        var record = __AB4_createAdjustedExportRecord(sourceDoc, artboard, productName, productFolder);
        if (!record) {
            skipped.push(productName + "\uff1a\u6ca1\u627e\u5230\u5546\u54c1\u56fe\u6216\u753b\u677f\u5185\u5bb9\u4e3a\u7a7a");
            continue;
        }

        __AB4_exportAdjustedProductSet(sourceDoc, record);
        exportedCount++;
    }

    var message = "\u8c03\u6574\u56fe\u91cd\u65b0\u5bfc\u51fa\u5b8c\u6210\uff1a" + exportedCount + " \u4e2a\u753b\u677f\u3002";
    message += "\n\n\u672c\u5165\u53e3\u4ec5\u7528\u4e8e\u8c03\u6574 PSD\uff1a\u6309\u5f53\u524d\u753b\u9762\u72b6\u6001\u5bfc\u51fa\u767d\u5e95 JPG\u3001\u900f\u660e\u5e95 1280 PNG\u3001\u900f\u660e\u5e95 800 PNG\u3002";
    if (skipped.length) {
        message += "\n\n\u8df3\u8fc7\uff1a\n" + skipped.join("\n");
    }

    alert(message);
}

function __AB4_createExportRecord(workDoc, artboard, productName, productFolder) {
    app.activeDocument = workDoc;

    var rect = __AB4_getArtboardRect(artboard);

    if (artboard.layers.length < 3) {
        return null;
    }

    return {
        artboard: artboard,
        rect: rect,
        productLayer: artboard.layers[0],
        textLayer: artboard.layers[1],
        backgroundLayer: artboard.layers[2],
        forceShowProductTree: true,
        png1280File: __AB4_file(productFolder, "\u900f\u660e\u5e95-1280-" + productName + ".png"),
        whiteJpgFile: __AB4_file(productFolder, "\u767d\u5e95-1280-" + productName + ".jpg"),
        png800File: __AB4_file(productFolder, "\u900f\u660e\u5e95-800-" + productName + ".png"),
        mainJpgFile: __AB4_file(productFolder, "\u4e3b\u56fe-1280-" + productName + ".jpg")
    };
}

function __AB4_createAdjustedExportRecord(workDoc, artboard, productName, productFolder) {
    app.activeDocument = workDoc;

    var rect = __AB4_getArtboardRect(artboard);
    var whiteLayer = __AB4_findWhiteBackgroundLayer(artboard);
    var productLayer = __AB4_findAdjustedProductLayer(artboard, whiteLayer);

    if (!productLayer) {
        return null;
    }

    return {
        artboard: artboard,
        rect: rect,
        productLayer: productLayer,
        textLayer: null,
        backgroundLayer: null,
        whiteLayer: whiteLayer,
        forceShowProductTree: false,
        png1280File: __AB4_file(productFolder, "\u900f\u660e\u5e95-1280-" + productName + ".png"),
        whiteJpgFile: __AB4_file(productFolder, "\u767d\u5e95-1280-" + productName + ".jpg"),
        png800File: __AB4_file(productFolder, "\u900f\u660e\u5e95-800-" + productName + ".png"),
        mainJpgFile: null
    };
}

function __AB4_findAdjustedProductLayer(artboard, whiteLayer) {
    var whiteId = whiteLayer ? __AB4_getDomLayerId(whiteLayer) : null;

    for (var i = 0; i < artboard.layers.length; i++) {
        var layer = artboard.layers[i];
        var layerId = __AB4_getDomLayerId(layer);

        if (whiteId !== null && layerId === whiteId) {
            continue;
        }

        if (__AB4_isLayerVisible(layer) && __AB4_getLayerBoundsRect(layer)) {
            return layer;
        }
    }

    for (var j = 0; j < artboard.layers.length; j++) {
        var fallbackLayer = artboard.layers[j];
        var fallbackId = __AB4_getDomLayerId(fallbackLayer);

        if (whiteId !== null && fallbackId === whiteId) {
            continue;
        }

        if (__AB4_getLayerBoundsRect(fallbackLayer)) {
            return fallbackLayer;
        }
    }

    return null;
}

function __AB4_findWhiteBackgroundLayer(artboard) {
    for (var i = 0; i < artboard.layers.length; i++) {
        if (String(artboard.layers[i].name) === "\u767d\u5e95\uff08\u53ef\u9690\u85cf\uff09") {
            return artboard.layers[i];
        }
    }

    return null;
}

function __AB4_prepareAdjustmentDocument(workDoc, records) {
    app.activeDocument = workDoc;

    for (var i = 0; i < records.length; i++) {
        var record = records[i];
        record.whiteLayer = __AB4_prepareAdjustmentArtboard(record.artboard, record.rect, record.productLayer);
    }
}

function __AB4_prepareAdjustmentArtboard(artboard, rect, productLayer) {
    __AB4_setVisible(artboard, true);
    __AB4_setArtboardBackgroundTransparent(artboard);

    for (var i = 0; i < artboard.layers.length; i++) {
        var layer = artboard.layers[i];
        if (__AB4_getDomLayerId(layer) === __AB4_getDomLayerId(productLayer)) {
            __AB4_showLayerTree(layer);
        } else {
            __AB4_setVisible(layer, false);
        }
    }

    __AB4_centerLayerInArtboard(productLayer, rect);
    return __AB4_addAdjustableWhiteBackground(artboard, rect, productLayer);
}

function __AB4_setArtboardBackgroundTransparent(artboard) {
    var id = __AB4_getDomLayerId(artboard);
    if (id === null) {
        return;
    }

    var doc = app.activeDocument;
    var previousActiveLayer = null;
    var rect = null;

    try {
        previousActiveLayer = doc.activeLayer;
    } catch (e) {
        previousActiveLayer = null;
    }

    try {
        rect = __AB4_getArtboardRect(artboard);
    } catch (e2) {
        rect = null;
    }

    if (__AB4_setArtboardBackgroundTransparentByProperty(id)) {
        return;
    }

    try {
        __AB4_selectLayerById(id, false);
        if (rect && __AB4_setTargetArtboardBackgroundTransparentByEditEvent(rect)) {
            return;
        }
    } catch (e3) {
        // Fall through to restore focus.
    } finally {
        if (previousActiveLayer) {
            try {
                doc.activeLayer = previousActiveLayer;
            } catch (e4) {
                // Restoring the active layer is cosmetic only.
            }
        }
    }
}

function __AB4_setArtboardBackgroundTransparentByProperty(layerId) {
    try {
        var ref = new ActionReference();
        ref.putProperty(charIDToTypeID("Prpr"), stringIDToTypeID("artboard"));
        ref.putIdentifier(charIDToTypeID("Lyr "), Number(layerId));

        var desc = new ActionDescriptor();
        desc.putReference(charIDToTypeID("null"), ref);

        var artboardDesc = __AB4_getArtboardDescriptor(layerId);
        if (!artboardDesc) {
            artboardDesc = new ActionDescriptor();
        }

        artboardDesc.putInteger(stringIDToTypeID("artboardBackgroundType"), 3);
        desc.putObject(charIDToTypeID("T   "), stringIDToTypeID("artboard"), artboardDesc);
        executeAction(charIDToTypeID("setd"), desc, DialogModes.NO);
        return true;
    } catch (e) {
        return false;
    }
}

function __AB4_setTargetArtboardBackgroundTransparentByEditEvent(rect) {
    try {
        var desc = new ActionDescriptor();
        var artboardDesc = new ActionDescriptor();
        var rectDesc = new ActionDescriptor();
        var colorDesc = new ActionDescriptor();
        var guides = new ActionList();
        var ref = new ActionReference();

        ref.putEnumerated(stringIDToTypeID("layer"), stringIDToTypeID("ordinal"), stringIDToTypeID("targetEnum"));
        desc.putReference(charIDToTypeID("null"), ref);

        rectDesc.putDouble(stringIDToTypeID("top"), Number(rect.top));
        rectDesc.putDouble(stringIDToTypeID("left"), Number(rect.left));
        rectDesc.putDouble(stringIDToTypeID("bottom"), Number(rect.bottom));
        rectDesc.putDouble(stringIDToTypeID("right"), Number(rect.right));
        artboardDesc.putObject(stringIDToTypeID("artboardRect"), stringIDToTypeID("classFloatRect"), rectDesc);

        artboardDesc.putList(stringIDToTypeID("guideIDs"), guides);
        artboardDesc.putString(stringIDToTypeID("artboardPresetName"), "");

        colorDesc.putDouble(stringIDToTypeID("red"), 255);
        colorDesc.putDouble(charIDToTypeID("Grn "), 255);
        colorDesc.putDouble(stringIDToTypeID("blue"), 255);
        artboardDesc.putObject(stringIDToTypeID("color"), stringIDToTypeID("RGBColor"), colorDesc);

        artboardDesc.putInteger(stringIDToTypeID("artboardBackgroundType"), 3);
        desc.putObject(stringIDToTypeID("artboard"), stringIDToTypeID("artboard"), artboardDesc);
        desc.putInteger(stringIDToTypeID("changeSizes"), 8);
        desc.putInteger(stringIDToTypeID("changeBackground"), 1);

        executeAction(stringIDToTypeID("editArtboardEvent"), desc, DialogModes.NO);
        return true;
    } catch (e) {
        return false;
    }
}

function __AB4_getArtboardDescriptor(layerId) {
    try {
        var ref = new ActionReference();
        ref.putProperty(charIDToTypeID("Prpr"), stringIDToTypeID("artboard"));
        ref.putIdentifier(charIDToTypeID("Lyr "), Number(layerId));

        var desc = executeActionGet(ref);
        if (desc.hasKey(stringIDToTypeID("artboard"))) {
            return desc.getObjectValue(stringIDToTypeID("artboard"));
        }
    } catch (e) {
        // Fall through.
    }

    return null;
}

function __AB4_centerLayerInArtboard(layer, artboardRect) {
    var bounds = __AB4_getLayerBoundsRect(layer);
    if (!bounds) {
        return;
    }

    var layerWidth = bounds.right - bounds.left;
    var layerHeight = bounds.bottom - bounds.top;
    var artboardWidth = artboardRect.right - artboardRect.left;
    var artboardHeight = artboardRect.bottom - artboardRect.top;
    var desiredLeft = artboardRect.left + (artboardWidth - layerWidth) / 2;
    var desiredTop = artboardRect.top + (artboardHeight - layerHeight) / 2;

    __AB4_translateLayerTree(layer, desiredLeft - bounds.left, desiredTop - bounds.top);
}

function __AB4_addAdjustableWhiteBackground(artboard, artboardRect, productLayer) {
    var doc = app.activeDocument;

    var white = new SolidColor();
    white.rgb.red = 255;
    white.rgb.green = 255;
    white.rgb.blue = 255;

    var bg = doc.artLayers.add();
    bg.name = "\u767d\u5e95\uff08\u53ef\u9690\u85cf\uff09";

    doc.selection.select([
        [artboardRect.left, artboardRect.top],
        [artboardRect.right, artboardRect.top],
        [artboardRect.right, artboardRect.bottom],
        [artboardRect.left, artboardRect.bottom]
    ]);
    doc.selection.fill(white, ColorBlendMode.NORMAL, 100, false);
    doc.selection.deselect();

    try {
        bg.move(artboard, ElementPlacement.INSIDE);
    } catch (e1) {
        try {
            bg.move(artboard, ElementPlacement.PLACEATEND);
        } catch (e2) {
            // If moving into the artboard fails, leave the layer in place.
        }
    }

    try {
        bg.move(productLayer, ElementPlacement.PLACEAFTER);
    } catch (e3) {
        try {
            bg.move(artboard.layers[artboard.layers.length - 1], ElementPlacement.PLACEAFTER);
        } catch (e4) {
            // Best effort: the layer is still a normal visible white background.
        }
    }

    __AB4_setVisible(bg, false);
    return bg;
}

function __AB4_exportAdjustedProductSet(sourceDoc, record) {
    app.activeDocument = sourceDoc;
    __AB4_setVisible(record.artboard, true);

    if (record.forceShowProductTree === false) {
        __AB4_setVisible(record.productLayer, true);
    } else {
        __AB4_showLayerTree(record.productLayer);
    }

    if (record.whiteLayer) {
        __AB4_setVisible(record.whiteLayer, false);
    }

    var renderDoc = __AB4_copyProductLayerToTransparentRenderDoc(sourceDoc, record);

    try {
        __AB4_exportPng(renderDoc, record.png1280File);
        __AB4_exportScaledPngFromRenderDoc(renderDoc, record.png800File, 800, 800);
        __AB4_fillDocumentWhiteAtBottom(renderDoc);
        __AB4_saveJpgInPlace(renderDoc, record.whiteJpgFile);
    } finally {
        __AB4_closeNoSave(renderDoc);
        app.activeDocument = sourceDoc;
        if (record.whiteLayer) {
            __AB4_setVisible(record.whiteLayer, false);
        }
    }
}

function __AB4_copyProductLayerToTransparentRenderDoc(sourceDoc, record) {
    app.activeDocument = sourceDoc;

    var renderDoc = __AB4_createRenderDoc(record.rect, false);
    app.activeDocument = sourceDoc;

    var sourceBounds = __AB4_getLayerBoundsRect(record.productLayer);
    var copied = record.productLayer.duplicate(renderDoc, ElementPlacement.PLACEATBEGINNING);

    app.activeDocument = renderDoc;
    __AB4_moveCopiedLayerToArtboardPosition(copied, sourceBounds, record.rect);

    return renderDoc;
}

function __AB4_exportMainJpg(sourceDoc, rect, file) {
    var renderDoc = __AB4_copyMergedArtboardToRenderDoc(sourceDoc, rect);

    try {
        __AB4_saveJpgInPlace(renderDoc, file);
    } finally {
        __AB4_closeNoSave(renderDoc);
        app.activeDocument = sourceDoc;
    }
}

function __AB4_copyMergedArtboardToRenderDoc(sourceDoc, rect) {
    app.activeDocument = sourceDoc;

    var renderDoc = __AB4_createRenderDoc(rect, false);
    app.activeDocument = sourceDoc;

    sourceDoc.selection.select([
        [rect.left, rect.top],
        [rect.right, rect.top],
        [rect.right, rect.bottom],
        [rect.left, rect.bottom]
    ]);

    try {
        sourceDoc.selection.copy(true);
    } catch (e) {
        sourceDoc.selection.copy();
    }

    sourceDoc.selection.deselect();
    app.activeDocument = renderDoc;

    try {
        renderDoc.paste();
    } catch (e2) {
        // Leave a blank render doc if paste fails; save will surface the issue.
    }

    return renderDoc;
}

function __AB4_createRenderDoc(rect, fillWhite) {
    var width = Math.round(rect.right - rect.left);
    var height = Math.round(rect.bottom - rect.top);
    var resolution = 72;

    try {
        resolution = Number(app.activeDocument.resolution);
    } catch (e) {
        resolution = 72;
    }

    var doc = app.documents.add(
        UnitValue(width, "px"),
        UnitValue(height, "px"),
        resolution,
        "__AB4_render_temp__",
        NewDocumentMode.RGB,
        DocumentFill.TRANSPARENT
    );

    if (fillWhite) {
        __AB4_fillDocumentWhite(doc);
    }

    return doc;
}

function __AB4_copyLayersToRenderDoc(sourceDoc, renderDoc, rect, layersBottomToTop) {
    for (var i = 0; i < layersBottomToTop.length; i++) {
        var sourceLayer = layersBottomToTop[i];
        __AB4_showLayerTree(sourceLayer);
        app.activeDocument = sourceDoc;

        var sourceBounds = __AB4_getLayerBoundsRect(sourceLayer);
        var copied = sourceLayer.duplicate(renderDoc, ElementPlacement.PLACEATBEGINNING);
        app.activeDocument = renderDoc;
        __AB4_moveCopiedLayerToArtboardPosition(copied, sourceBounds, rect);
    }
}

function __AB4_moveCopiedLayerToArtboardPosition(copiedLayer, sourceBounds, artboardRect) {
    if (!sourceBounds) {
        __AB4_translateLayerTree(copiedLayer, -artboardRect.left, -artboardRect.top);
        return;
    }

    var copiedBounds = __AB4_getLayerBoundsRect(copiedLayer);
    if (!copiedBounds) {
        __AB4_translateLayerTree(copiedLayer, -artboardRect.left, -artboardRect.top);
        return;
    }

    var desiredLeft = sourceBounds.left - artboardRect.left;
    var desiredTop = sourceBounds.top - artboardRect.top;
    var dx = desiredLeft - copiedBounds.left;
    var dy = desiredTop - copiedBounds.top;

    __AB4_translateLayerTree(copiedLayer, dx, dy);
}

function __AB4_translateLayerTree(layer, dx, dy) {
    try {
        layer.translate(UnitValue(dx, "px"), UnitValue(dy, "px"));
        return;
    } catch (e) {
        // Some LayerSet objects in older Photoshop builds do not translate as a group.
    }

    if (layer.typename === "LayerSet") {
        for (var i = 0; i < layer.layers.length; i++) {
            __AB4_translateLayerTree(layer.layers[i], dx, dy);
        }
    }
}

function __AB4_getLayerBoundsRect(layer) {
    try {
        var b = layer.bounds;
        return {
            left: __AB4_toPx(b[0]),
            top: __AB4_toPx(b[1]),
            right: __AB4_toPx(b[2]),
            bottom: __AB4_toPx(b[3])
        };
    } catch (e) {
        return null;
    }
}

function __AB4_fillDocumentWhite(doc) {
    app.activeDocument = doc;

    var white = new SolidColor();
    white.rgb.red = 255;
    white.rgb.green = 255;
    white.rgb.blue = 255;

    doc.selection.select([
        [0, 0],
        [__AB4_toPx(doc.width), 0],
        [__AB4_toPx(doc.width), __AB4_toPx(doc.height)],
        [0, __AB4_toPx(doc.height)]
    ]);
    doc.selection.fill(white, ColorBlendMode.NORMAL, 100, false);
    doc.selection.deselect();
}

function __AB4_fillDocumentWhiteAtBottom(doc) {
    app.activeDocument = doc;

    var bottomLayer = doc.artLayers.add();
    bottomLayer.name = "__AB4_white_background__";
    __AB4_fillDocumentWhite(doc);

    try {
        bottomLayer.move(doc, ElementPlacement.PLACEATEND);
    } catch (e) {
        try {
            bottomLayer.move(doc.layers[doc.layers.length - 1], ElementPlacement.PLACEAFTER);
        } catch (e2) {
            // If moving fails, flattening for JPEG still uses a white-filled layer.
        }
    }
}

function __AB4_exportScaledPngFromRenderDoc(doc, file, widthPx, heightPx) {
    app.activeDocument = doc;

    var scaledDoc = doc.duplicate("__AB4_scaled_png_temp__", false);
    app.activeDocument = scaledDoc;

    try {
        // Resize the complete canvas composition. Do not trim transparent pixels,
        // crop to product bounds, or re-center the product.
        scaledDoc.resizeImage(UnitValue(widthPx, "px"), UnitValue(heightPx, "px"), null, ResampleMethod.BICUBICSHARPER);
        __AB4_exportPng(scaledDoc, file);
    } finally {
        __AB4_closeNoSave(scaledDoc);
        app.activeDocument = doc;
    }
}

function __AB4_saveJpgInPlace(doc, file) {
    app.activeDocument = doc;

    doc.flatten();

    var options = new JPEGSaveOptions();
    options.quality = 12;
    options.embedColorProfile = true;
    options.formatOptions = FormatOptions.STANDARDBASELINE;

    doc.saveAs(file, options, true, Extension.LOWERCASE);
}

function __AB4_closeNoSave(doc) {
    try {
        doc.close(SaveOptions.DONOTSAVECHANGES);
    } catch (e) {
        // Ignore close failures.
    }
}

function __AB4_setArtboardVariant(artboard, mode) {
    __AB4_setVisible(artboard, true);

    for (var i = 0; i < artboard.layers.length; i++) {
        var layer = artboard.layers[i];

        if (mode === "main") {
            if (i < 3) {
                __AB4_showLayerTree(layer);
            } else {
                __AB4_setVisible(layer, false);
            }
        } else {
            if (i === 0) {
                __AB4_showLayerTree(layer);
            } else {
                __AB4_setVisible(layer, false);
            }
        }
    }
}

function __AB4_showLayerTree(layer) {
    __AB4_setVisible(layer, true);

    if (layer.typename === "LayerSet") {
        for (var i = 0; i < layer.layers.length; i++) {
            __AB4_showLayerTree(layer.layers[i]);
        }
    }
}

function __AB4_hideOtherTopLevelLayers(doc, targetArtboard) {
    for (var i = 0; i < doc.layers.length; i++) {
        var layer = doc.layers[i];
        __AB4_setVisible(layer, __AB4_getDomLayerId(layer) === __AB4_getDomLayerId(targetArtboard));
    }
}

function __AB4_setVisible(layer, visible) {
    try {
        layer.visible = visible;
    } catch (e) {
        // Some special layers can reject visibility changes. Skip safely.
    }
}

function __AB4_exportPng(doc, file) {
    app.activeDocument = doc;

    var options = new ExportOptionsSaveForWeb();
    options.format = SaveDocumentType.PNG;
    options.PNG8 = false;
    options.transparency = true;
    options.interlaced = false;
    options.includeProfile = true;

    doc.exportDocument(file, ExportType.SAVEFORWEB, options);
}

function __AB4_collectArtboards(doc) {
    var artboards = [];

    for (var i = 0; i < doc.layers.length; i++) {
        var layer = doc.layers[i];
        if (__AB4_hasArtboardFlag(layer)) {
            artboards.push({
                layer: layer,
                index: i
            });
        }
    }

    if (artboards.length) {
        return artboards;
    }

    // Compatibility fallback for older Photoshop builds that do not expose the
    // artboard flag consistently through ExtendScript.
    for (var j = 0; j < doc.layers.length; j++) {
        var fallbackLayer = doc.layers[j];
        if (__AB4_isTopLevelLayerSet(fallbackLayer)) {
            artboards.push({
                layer: fallbackLayer,
                index: j
            });
        }
    }

    return artboards;
}

function __AB4_collectVisibleArtboards(doc) {
    var artboards = __AB4_collectArtboards(doc);
    var visibleArtboards = [];

    for (var i = 0; i < artboards.length; i++) {
        if (__AB4_isLayerVisible(artboards[i].layer)) {
            visibleArtboards.push(artboards[i]);
        }
    }

    return visibleArtboards;
}

function __AB4_isLayerVisible(layer) {
    try {
        return layer.visible === true;
    } catch (e) {
        return false;
    }
}

function __AB4_hasArtboardFlag(layer) {
    if (!layer || layer.typename !== "LayerSet") {
        return false;
    }

    try {
        var id = __AB4_getDomLayerId(layer);
        if (id === null) {
            return false;
        }

        var ref = new ActionReference();
        ref.putIdentifier(charIDToTypeID("Lyr "), Number(id));
        var desc = executeActionGet(ref);
        var key = stringIDToTypeID("artboardEnabled");

        if (desc.hasKey(key)) {
            return desc.getBoolean(key) === true;
        }
    } catch (e) {
        return false;
    }

    return false;
}

function __AB4_isTopLevelLayerSet(layer) {
    if (!layer || layer.typename !== "LayerSet") {
        return false;
    }

    try {
        return layer.parent && layer.parent.typename === "Document";
    } catch (e) {
        return false;
    }
}

function __AB4_getArtboardRect(layer) {
    try {
        var id = __AB4_getDomLayerId(layer);
        var ref = new ActionReference();
        ref.putIdentifier(charIDToTypeID("Lyr "), Number(id));
        var desc = executeActionGet(ref);
        var artboardKey = stringIDToTypeID("artboard");

        if (desc.hasKey(artboardKey)) {
            var artboardDesc = desc.getObjectValue(artboardKey);
            var rectDesc = artboardDesc.getObjectValue(stringIDToTypeID("artboardRect"));

            return {
                left: rectDesc.getUnitDoubleValue(stringIDToTypeID("left")),
                top: rectDesc.getUnitDoubleValue(stringIDToTypeID("top")),
                right: rectDesc.getUnitDoubleValue(stringIDToTypeID("right")),
                bottom: rectDesc.getUnitDoubleValue(stringIDToTypeID("bottom"))
            };
        }
    } catch (e) {
        // Fall back to DOM bounds below.
    }

    var b = layer.bounds;
    return {
        left: __AB4_toPx(b[0]),
        top: __AB4_toPx(b[1]),
        right: __AB4_toPx(b[2]),
        bottom: __AB4_toPx(b[3])
    };
}

function __AB4_getDomLayerId(layer) {
    try {
        return Number(layer.id);
    } catch (e) {
        return null;
    }
}

function __AB4_selectLayerById(layerId, addToSelection) {
    var desc = new ActionDescriptor();
    var ref = new ActionReference();

    ref.putIdentifier(charIDToTypeID("Lyr "), Number(layerId));
    desc.putReference(charIDToTypeID("null"), ref);

    if (addToSelection) {
        desc.putEnumerated(
            stringIDToTypeID("selectionModifier"),
            stringIDToTypeID("selectionModifierType"),
            stringIDToTypeID("addToSelection")
        );
    }

    desc.putBoolean(charIDToTypeID("MkVs"), false);
    executeAction(charIDToTypeID("slct"), desc, DialogModes.NO);
}

function __AB4_toPx(value) {
    try {
        return Number(value.as("px"));
    } catch (e) {
        return Number(value);
    }
}

function __AB4_file(folder, name) {
    return new File(folder.fsName + "/" + __AB4_cleanName(name, "\u672a\u547d\u540d\u6587\u4ef6"));
}

function __AB4_cleanName(name, fallback) {
    var cleaned = String(name || "")
        .replace(/[\\\/:\*\?"<>\|]/g, "_")
        .replace(/^\s+|\s+$/g, "")
        .replace(/[\. ]+$/g, "");

    if (!cleaned) {
        cleaned = fallback;
    }

    return cleaned;
}

function __AB4_uniqueName(name, used) {
    var base = __AB4_cleanName(name, "\u672a\u547d\u540d\u5546\u54c1");
    var current = base;
    var index = 2;

    while (used[current]) {
        current = base + "_" + index;
        index++;
    }

    used[current] = true;
    return current;
}
