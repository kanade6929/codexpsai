#target photoshop

/*
  PS_自动生成白墨图层.jsx

  用途：
  - 根据当前选中的 Photoshop 图层或图层组的非透明区域，自动生成白墨底版图层。
  - 适合亚克力、贴纸、UV、透明材质印刷等需要单独白墨层的周边工艺文件。

  使用：
  1. 在 Photoshop 打开 PSD。
  2. 在图层面板选中要生成白墨的图层或图层组。
  3. 文件 > 脚本 > 浏览...，选择本脚本。
*/

(function () {
  if (app.documents.length === 0) {
    alert("请先在 Photoshop 中打开一个文件。");
    return;
  }

  var doc = app.activeDocument;
  var originalRulerUnits = app.preferences.rulerUnits;
  app.preferences.rulerUnits = Units.PIXELS;

  try {
    var sourceLayer = doc.activeLayer;
    var ui = showDialog(sourceLayer);
    if (!ui) return;

    if (ui.clearOld && sourceLayer.name === ui.layerName) {
      alert("当前选中的来源图层也叫“" + ui.layerName + "”。\n\n请先换一个来源图层，或取消“删除同名旧白墨层”。");
      return;
    }

    if (ui.clearOld) {
      removeLayersByName(doc, ui.layerName);
    }

    var selectionMade = makeSelectionFromLayerTransparency(doc, sourceLayer, ui.edgeMode, ui.thresholdPercent);
    if (!selectionMade) {
      alert("没有取得有效的非透明区域。\n\n请确认当前选中的是有内容的像素图层、形状图层或图层组。");
      return;
    }

    applySelectionOffset(doc, ui.spreadPx);

    if (!selectionHasBounds(doc)) {
      alert("白墨区域为空，可能是内缩数值太大。");
      return;
    }

    var whiteLayer = doc.artLayers.add();
    whiteLayer.name = ui.layerName;
    whiteLayer.opacity = ui.opacity;

    var fillColor = makeSolidColor(ui.previewColor);
    doc.selection.fill(fillColor, ColorBlendMode.NORMAL, 100, false);

    if (ui.placeBelow) {
      moveLayerNearSource(whiteLayer, sourceLayer, false);
    } else {
      moveLayerNearSource(whiteLayer, sourceLayer, true);
    }

    if (!ui.keepSelection) {
      try { doc.selection.deselect(); } catch (e) {}
    }

    doc.activeLayer = whiteLayer;
    alert("白墨图层已生成：" + whiteLayer.name);
  } catch (err) {
    alert("生成失败：\n" + err.message + (err.line ? "\n\n行号：" + err.line : ""));
  } finally {
    app.preferences.rulerUnits = originalRulerUnits;
  }

  function showDialog(sourceLayer) {
    var result = null;
    var win = new Window("dialog", "自动生成白墨图层");
    win.orientation = "column";
    win.alignChildren = ["fill", "top"];
    win.spacing = 10;
    win.margins = 16;

    var sourcePanel = win.add("panel", undefined, "来源");
    sourcePanel.alignChildren = "left";
    sourcePanel.add("statictext", undefined, "当前选中：" + safeLayerName(sourceLayer));
    sourcePanel.add("statictext", undefined, "按当前图层 / 图层组的非透明区域生成白墨。");

    var paramPanel = win.add("panel", undefined, "参数");
    paramPanel.alignChildren = "left";

    var nameGroup = paramPanel.add("group");
    nameGroup.add("statictext", undefined, "白墨图层名：");
    var nameInput = nameGroup.add("edittext", undefined, "白墨");
    nameInput.characters = 18;

    var spreadGroup = paramPanel.add("group");
    spreadGroup.add("statictext", undefined, "外扩 / 内缩 px：");
    var spreadInput = spreadGroup.add("edittext", undefined, "0");
    spreadInput.characters = 8;
    spreadGroup.add("statictext", undefined, "正数外扩，负数内缩");

    var opacityGroup = paramPanel.add("group");
    opacityGroup.add("statictext", undefined, "图层不透明度：");
    var opacityInput = opacityGroup.add("edittext", undefined, "100");
    opacityInput.characters = 8;
    opacityGroup.add("statictext", undefined, "%");

    var colorGroup = paramPanel.add("group");
    colorGroup.add("statictext", undefined, "填充颜色：");
    var colorList = colorGroup.add("dropdownlist", undefined, [
      "纯黑 RGB 0/0/0（生产交付）",
      "浅蓝检查色（方便在白底上查看）"
    ]);
    colorList.selection = 0;
    colorList.preferredSize.width = 250;

    var edgePanel = win.add("panel", undefined, "透明度曲线 / 白墨边缘");
    edgePanel.alignChildren = "left";
    var edgeModeList = edgePanel.add("dropdownlist", undefined, [
      "硬边阈值（推荐：半透明边缘压成实边）",
      "保留原透明度（旧版：边缘会跟着发虚）",
      "包住淡边（适合很淡的发光/阴影边缘）",
      "严格内收（适合避免白墨露边）"
    ]);
    edgeModeList.selection = 0;
    edgeModeList.preferredSize.width = 330;

    var thresholdGroup = edgePanel.add("group");
    thresholdGroup.add("statictext", undefined, "透明度阈值 %：");
    var thresholdInput = thresholdGroup.add("edittext", undefined, "50");
    thresholdInput.characters = 8;
    thresholdGroup.add("statictext", undefined, "低于阈值丢弃，高于阈值变实色");

    edgeModeList.onChange = function () {
      if (!edgeModeList.selection) return;
      if (edgeModeList.selection.index === 0) thresholdInput.text = "50";
      if (edgeModeList.selection.index === 1) thresholdInput.text = "0";
      if (edgeModeList.selection.index === 2) thresholdInput.text = "5";
      if (edgeModeList.selection.index === 3) thresholdInput.text = "85";
      thresholdInput.enabled = edgeModeList.selection.index !== 1;
    };

    var optionPanel = win.add("panel", undefined, "选项");
    optionPanel.alignChildren = "left";
    var placeBelowCheck = optionPanel.add("checkbox", undefined, "生成在来源图层下方");
    placeBelowCheck.value = true;
    var clearOldCheck = optionPanel.add("checkbox", undefined, "生成前删除同名旧白墨层");
    clearOldCheck.value = false;
    var keepSelectionCheck = optionPanel.add("checkbox", undefined, "保留选区");
    keepSelectionCheck.value = false;

    var buttons = win.add("group");
    buttons.alignment = ["right", "top"];
    var okButton = buttons.add("button", undefined, "生成", { name: "ok" });
    buttons.add("button", undefined, "取消", { name: "cancel" });

    okButton.onClick = function () {
      var layerName = trimString(nameInput.text);
      var spreadPx = parseNumber(spreadInput.text);
      var opacity = parseNumber(opacityInput.text);
      var thresholdPercent = parseNumber(thresholdInput.text);

      if (!layerName) {
        alert("请填写白墨图层名。");
        return;
      }
      if (isNaN(spreadPx)) {
        alert("外扩 / 内缩数值需要填写数字。");
        return;
      }
      if (isNaN(opacity) || opacity <= 0 || opacity > 100) {
        alert("图层不透明度需要在 1 到 100 之间。");
        return;
      }
      if (edgeModeList.selection.index !== 1 && (isNaN(thresholdPercent) || thresholdPercent <= 0 || thresholdPercent >= 100)) {
        alert("透明度阈值需要在 1 到 99 之间。");
        return;
      }

      result = {
        layerName: layerName,
        spreadPx: Math.round(spreadPx),
        opacity: opacity,
        previewColor: colorList.selection && colorList.selection.index === 1 ? "blue" : "black",
        edgeMode: edgeModeList.selection.index === 1 ? "soft" : "threshold",
        thresholdPercent: edgeModeList.selection.index === 1 ? 0 : thresholdPercent,
        placeBelow: placeBelowCheck.value,
        clearOld: clearOldCheck.value,
        keepSelection: keepSelectionCheck.value
      };
      win.close();
    };

    win.show();
    return result;
  }

  function makeSelectionFromLayerTransparency(docRef, sourceLayer, edgeMode, thresholdPercent) {
    var tempLayer = null;
    var oldActive = docRef.activeLayer;

    try {
      docRef.activeLayer = sourceLayer;
      tempLayer = sourceLayer.duplicate();
      docRef.activeLayer = tempLayer;

      if (tempLayer.typename === "LayerSet") {
        tempLayer = tempLayer.merge();
        docRef.activeLayer = tempLayer;
      }

      loadActiveLayerTransparency();
      if (edgeMode === "threshold") {
        hardenCurrentSelection(docRef, thresholdPercent);
      }
      var hasSelection = selectionHasBounds(docRef);

      try {
        docRef.activeLayer = tempLayer;
        tempLayer.remove();
      } catch (removeErr) {}

      docRef.activeLayer = oldActive;
      return hasSelection;
    } catch (err) {
      try {
        if (tempLayer) {
          docRef.activeLayer = tempLayer;
          tempLayer.remove();
        }
      } catch (removeErr2) {}

      try { docRef.activeLayer = oldActive; } catch (activeErr) {}
      throw err;
    }
  }

  function loadActiveLayerTransparency() {
    var desc = new ActionDescriptor();
    var selectionRef = new ActionReference();
    selectionRef.putProperty(charIDToTypeID("Chnl"), charIDToTypeID("fsel"));
    desc.putReference(charIDToTypeID("null"), selectionRef);

    var transparencyRef = new ActionReference();
    transparencyRef.putEnumerated(charIDToTypeID("Chnl"), charIDToTypeID("Chnl"), charIDToTypeID("Trsp"));
    desc.putReference(charIDToTypeID("T   "), transparencyRef);

    executeAction(charIDToTypeID("setd"), desc, DialogModes.NO);
  }

  function hardenCurrentSelection(docRef, thresholdPercent) {
    var maskChannel = null;
    var oldChannels = null;
    var thresholdValue = Math.round(Math.max(1, Math.min(99, thresholdPercent)) * 2.55);

    try {
      try { oldChannels = docRef.activeChannels; } catch (e) {}

      maskChannel = docRef.channels.add();
      maskChannel.name = "__white_ink_alpha_curve__";
      docRef.selection.store(maskChannel, SelectionType.REPLACE);

      docRef.activeChannels = [maskChannel];
      applyBinaryLevelsToActiveChannel(thresholdValue);
      docRef.selection.load(maskChannel, SelectionType.REPLACE);

      restoreActiveChannels(docRef, oldChannels);
      try { maskChannel.remove(); } catch (removeErr) {}
    } catch (err) {
      try { restoreActiveChannels(docRef, oldChannels); } catch (restoreErr) {}
      try { if (maskChannel) maskChannel.remove(); } catch (removeErr2) {}
      throw new Error("透明度曲线处理失败：" + err.message);
    }
  }

  function applyBinaryLevelsToActiveChannel(thresholdValue) {
    var blackPoint = Math.max(0, Math.min(254, thresholdValue - 1));
    var whitePoint = Math.max(1, Math.min(255, thresholdValue));

    var desc = new ActionDescriptor();
    var adjustments = new ActionList();
    var adjustment = new ActionDescriptor();
    var input = new ActionList();
    var output = new ActionList();

    input.putInteger(blackPoint);
    input.putInteger(whitePoint);
    output.putInteger(0);
    output.putInteger(255);

    adjustment.putList(charIDToTypeID("Inpt"), input);
    adjustment.putDouble(charIDToTypeID("Gmm "), 1.0);
    adjustment.putList(charIDToTypeID("Otpt"), output);
    adjustments.putObject(charIDToTypeID("LvlA"), adjustment);
    desc.putList(charIDToTypeID("Adjs"), adjustments);

    executeAction(charIDToTypeID("Lvls"), desc, DialogModes.NO);
  }

  function restoreActiveChannels(docRef, oldChannels) {
    try {
      if (oldChannels && oldChannels.length > 0) {
        docRef.activeChannels = oldChannels;
        return;
      }
    } catch (e) {}

    var channels = [];
    for (var i = 0; i < docRef.channels.length; i++) {
      try {
        if (docRef.channels[i].kind === ChannelType.COMPONENT) {
          channels.push(docRef.channels[i]);
        }
      } catch (e2) {}
    }

    if (channels.length > 0) {
      docRef.activeChannels = channels;
    }
  }

  function applySelectionOffset(docRef, spreadPx) {
    if (spreadPx === 0) return;

    if (spreadPx > 0) {
      try {
        docRef.selection.expand(spreadPx);
      } catch (e) {
        actionSelectionOffset("Expn", spreadPx);
      }
    } else {
      var shrinkPx = Math.abs(spreadPx);
      try {
        docRef.selection.contract(shrinkPx);
      } catch (e2) {
        actionSelectionOffset("Cntc", shrinkPx);
      }
    }
  }

  function actionSelectionOffset(actionCode, px) {
    var desc = new ActionDescriptor();
    desc.putUnitDouble(charIDToTypeID("By  "), charIDToTypeID("#Pxl"), px);
    executeAction(charIDToTypeID(actionCode), desc, DialogModes.NO);
  }

  function selectionHasBounds(docRef) {
    try {
      var bounds = docRef.selection.bounds;
      return bounds && bounds.length === 4;
    } catch (e) {
      return false;
    }
  }

  function moveLayerNearSource(layerToMove, sourceLayer, placeAbove) {
    try {
      if (placeAbove) {
        layerToMove.move(sourceLayer, ElementPlacement.PLACEBEFORE);
      } else {
        layerToMove.move(sourceLayer, ElementPlacement.PLACEAFTER);
      }
    } catch (e) {}
  }

  function removeLayersByName(container, layerName) {
    for (var i = container.layers.length - 1; i >= 0; i--) {
      var layer = container.layers[i];
      if (layer.typename === "LayerSet") {
        removeLayersByName(layer, layerName);
      }

      if (layer.name === layerName) {
        try { layer.remove(); } catch (e) {}
      }
    }
  }

  function makeSolidColor(kind) {
    var color = new SolidColor();
    if (kind === "blue") {
      color.rgb.red = 120;
      color.rgb.green = 210;
      color.rgb.blue = 255;
    } else {
      color.rgb.red = 0;
      color.rgb.green = 0;
      color.rgb.blue = 0;
    }
    return color;
  }

  function parseNumber(value) {
    return parseFloat(String(value).replace(",", "."));
  }

  function trimString(value) {
    return String(value).replace(/^\s+|\s+$/g, "");
  }

  function safeLayerName(layer) {
    try { return layer.name; } catch (e) { return "当前图层"; }
  }
}());
