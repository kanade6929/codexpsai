#target photoshop
#targetengine "whiteInkLivePanel"

/*
  Photoshop 2022 白墨实时预览面板
  - 根据锁定的具体图层透明度生成白墨，不修改来源图层。
  - CMYK 文档正式白墨固定为 C0 M0 Y0 K100。
  - RGB 文档使用 RGB 0/0/0，不自动转换文档颜色模式。
  - 双滑杆作用于完整 Alpha 灰度，0 与 255 两端始终锁定。
*/

(function () {
  var PANEL_KEY = "__whiteInkLivePanelWindow";
  var PREVIEW_LAYER_NAME = "__WHITE_INK_LIVE_PREVIEW__";
  var SOURCE_CHANNEL_NAME = "__WHITE_INK_ALPHA_SOURCE__";
  var WORK_CHANNEL_NAME = "__WHITE_INK_ALPHA_WORK__";
  var SELECTION_CHANNEL_NAME = "__WHITE_INK_SELECTION_BACKUP__";

  if ($.global[PANEL_KEY]) {
    try {
      $.global[PANEL_KEY].show();
      return;
    } catch (existingPanelErr) {
      $.global[PANEL_KEY] = null;
    }
  }

  var state = {
    doc: null,
    sourceLayer: null,
    sourceChannel: null,
    previewLayer: null,
    pendingSettings: null,
    generatedLayer: null,
    lastRefreshAt: 0,
    liveDragEnabled: true,
    closing: false,
    ui: null
  };

  $.global.__whiteInkPreviewHistory = function () {
    refreshPreviewCore(state.pendingSettings);
  };

  $.global.__whiteInkGenerateHistory = function () {
    state.generatedLayer = generateLayerCore(state.pendingSettings, false);
  };

  var win = buildPanel();
  state.ui = win.__ui;
  $.global[PANEL_KEY] = win;
  win.center();
  win.show();

  if (app.documents.length > 0) {
    bindCurrentSource(true);
  } else {
    setStatus("请先打开文档，再点击“重新读取当前图层”。", true);
  }

  function buildPanel() {
    var panel = new Window("palette", "白墨实时预览", undefined, { resizeable: true });
    panel.orientation = "column";
    panel.alignChildren = ["fill", "top"];
    panel.spacing = 8;
    panel.margins = 12;
    panel.minimumSize.width = 390;

    var sourcePanel = panel.add("panel", undefined, "来源");
    sourcePanel.orientation = "column";
    sourcePanel.alignChildren = ["fill", "top"];
    sourcePanel.margins = 10;
    var sourceText = sourcePanel.add("statictext", undefined, "尚未读取图层", { multiline: true });
    sourceText.preferredSize.height = 34;
    var sourceButtons = sourcePanel.add("group");
    sourceButtons.alignment = ["left", "top"];
    var rereadButton = sourceButtons.add("button", undefined, "重新读取当前图层");

    var presetPanel = panel.add("panel", undefined, "预设");
    presetPanel.orientation = "row";
    presetPanel.alignChildren = ["left", "center"];
    presetPanel.margins = 10;
    var presetList = presetPanel.add("dropdownlist", undefined, [
      "标准硬边",
      "保留细节",
      "防止露白",
      "保留柔边",
      "自定义"
    ]);
    presetList.selection = 0;
    presetList.preferredSize.width = 180;

    var curvePanel = panel.add("panel", undefined, "Alpha 透明度调整");
    curvePanel.orientation = "column";
    curvePanel.alignChildren = ["fill", "top"];
    curvePanel.margins = 10;

    var takeoffRow = curvePanel.add("group");
    takeoffRow.alignChildren = ["left", "center"];
    takeoffRow.add("statictext", undefined, "淡边取舍").preferredSize.width = 68;
    var takeoffSlider = takeoffRow.add("slider", undefined, 50, 0, 100);
    takeoffSlider.preferredSize.width = 210;
    var takeoffValue = takeoffRow.add("edittext", undefined, "50");
    takeoffValue.characters = 4;

    var hardnessRow = curvePanel.add("group");
    hardnessRow.alignChildren = ["left", "center"];
    hardnessRow.add("statictext", undefined, "边缘硬度").preferredSize.width = 68;
    var hardnessSlider = hardnessRow.add("slider", undefined, 100, 0, 100);
    hardnessSlider.preferredSize.width = 210;
    var hardnessValue = hardnessRow.add("edittext", undefined, "100");
    hardnessValue.characters = 4;

    var curveHint = curvePanel.add("statictext", undefined, "取舍越高越去淡边；硬度越高越接近实边。透明和实色两端保持不变。", { multiline: true });
    curveHint.preferredSize.height = 30;

    var offsetRow = curvePanel.add("group");
    offsetRow.alignChildren = ["left", "center"];
    offsetRow.add("statictext", undefined, "外扩 / 内缩").preferredSize.width = 82;
    var offsetInput = offsetRow.add("edittext", undefined, "0");
    offsetInput.characters = 5;
    offsetRow.add("statictext", undefined, "px（正数外扩，负数内缩）");

    var previewPanel = panel.add("panel", undefined, "预览");
    previewPanel.orientation = "column";
    previewPanel.alignChildren = ["left", "top"];
    previewPanel.margins = 10;
    var previewCheck = previewPanel.add("checkbox", undefined, "启用实时预览");
    previewCheck.value = true;
    var previewModeRow = previewPanel.add("group");
    previewModeRow.add("statictext", undefined, "显示方式");
    var previewMode = previewModeRow.add("dropdownlist", undefined, ["蓝色半透明检查", "纯黑实际效果"]);
    previewMode.selection = 0;
    previewMode.preferredSize.width = 170;

    var outputPanel = panel.add("panel", undefined, "正式输出");
    outputPanel.orientation = "column";
    outputPanel.alignChildren = ["left", "top"];
    outputPanel.margins = 10;
    var nameRow = outputPanel.add("group");
    nameRow.add("statictext", undefined, "图层名");
    var nameInput = nameRow.add("edittext", undefined, "白墨");
    nameInput.characters = 18;
    var placeBelowCheck = outputPanel.add("checkbox", undefined, "放在来源图层下方");
    placeBelowCheck.value = true;
    var clearOldCheck = outputPanel.add("checkbox", undefined, "生成前删除同名旧白墨层");
    clearOldCheck.value = false;

    var colorInfo = outputPanel.add("statictext", undefined, "CMYK：C0 M0 Y0 K100；RGB：RGB 0/0/0。正式层固定 100% 不透明。", { multiline: true });
    colorInfo.preferredSize.height = 30;

    var statusText = panel.add("statictext", undefined, "准备就绪", { multiline: true });
    statusText.preferredSize.height = 34;

    var buttonRow = panel.add("group");
    buttonRow.alignment = ["right", "top"];
    var generateButton = buttonRow.add("button", undefined, "生成正式白墨");
    var closeButton = buttonRow.add("button", undefined, "关闭");

    panel.__ui = {
      sourceText: sourceText,
      rereadButton: rereadButton,
      presetList: presetList,
      takeoffSlider: takeoffSlider,
      takeoffValue: takeoffValue,
      hardnessSlider: hardnessSlider,
      hardnessValue: hardnessValue,
      offsetInput: offsetInput,
      previewCheck: previewCheck,
      previewMode: previewMode,
      nameInput: nameInput,
      placeBelowCheck: placeBelowCheck,
      clearOldCheck: clearOldCheck,
      statusText: statusText,
      generateButton: generateButton,
      closeButton: closeButton
    };

    panel.__test = {
      bindCurrentSource: function () { return bindCurrentSource(false); },
      requestPreview: function () { return requestPreview(false); },
      generateFinalLayer: function () { return generateFinalLayer(); },
      state: state
    };

    rereadButton.onClick = function () {
      bindCurrentSource(true);
    };

    presetList.onChange = function () {
      if (!presetList.selection || presetList.selection.index === 4) return;
      applyPreset(presetList.selection.index);
      requestPreview(false);
    };

    wireSlider(takeoffSlider, takeoffValue);
    wireSlider(hardnessSlider, hardnessValue);

    takeoffValue.onChange = function () {
      syncEditToSlider(takeoffValue, takeoffSlider);
      markCustomPreset();
      requestPreview(false);
    };
    hardnessValue.onChange = function () {
      syncEditToSlider(hardnessValue, hardnessSlider);
      markCustomPreset();
      requestPreview(false);
    };
    offsetInput.onChange = function () {
      var value = parseNumber(offsetInput.text);
      if (isNaN(value)) value = 0;
      value = Math.max(-100, Math.min(100, Math.round(value)));
      offsetInput.text = String(value);
      markCustomPreset();
      requestPreview(false);
    };
    previewCheck.onClick = function () {
      if (previewCheck.value) {
        if (!ensureSourceCache()) {
          previewCheck.value = false;
          return;
        }
        requestPreview(false);
      } else {
        cleanupTemporaryArtifacts(state.doc, true);
        state.sourceChannel = null;
        setStatus("预览已关闭，临时层和临时通道已清理。", false);
      }
    };
    previewMode.onChange = function () {
      requestPreview(false);
    };
    generateButton.onClick = function () {
      generateFinalLayer();
    };
    closeButton.onClick = function () {
      panel.close();
    };
    panel.onClose = function () {
      state.closing = true;
      try { cleanupTemporaryArtifacts(state.doc, true); } catch (cleanupErr) {}
      state.sourceChannel = null;
      $.global[PANEL_KEY] = null;
      return true;
    };
    panel.onResizing = panel.onResize = function () {
      this.layout.resize();
    };

    return panel;

    function wireSlider(slider, valueInput) {
      slider.onChanging = function () {
        valueInput.text = String(Math.round(slider.value));
        markCustomPreset();
        requestPreview(true);
      };
      slider.onChange = function () {
        valueInput.text = String(Math.round(slider.value));
        markCustomPreset();
        requestPreview(false);
      };
    }
  }

  function applyPreset(index) {
    var takeoff = 50;
    var hardness = 100;
    var offset = 0;
    if (index === 1) {
      takeoff = 30;
      hardness = 85;
    } else if (index === 2) {
      takeoff = 70;
      hardness = 100;
      offset = -1;
    } else if (index === 3) {
      takeoff = 50;
      hardness = 0;
    }
    state.ui.takeoffSlider.value = takeoff;
    state.ui.takeoffValue.text = String(takeoff);
    state.ui.hardnessSlider.value = hardness;
    state.ui.hardnessValue.text = String(hardness);
    state.ui.offsetInput.text = String(offset);
  }

  function markCustomPreset() {
    if (state.ui.presetList.selection && state.ui.presetList.selection.index !== 4) {
      state.ui.presetList.selection = 4;
    }
  }

  function syncEditToSlider(input, slider) {
    var value = parseNumber(input.text);
    if (isNaN(value)) value = Math.round(slider.value);
    value = Math.max(0, Math.min(100, Math.round(value)));
    input.text = String(value);
    slider.value = value;
  }

  function bindCurrentSource(showMessage) {
    if (app.documents.length === 0) {
      setStatus("没有打开的文档。", true);
      return false;
    }

    var newDoc = app.activeDocument;
    var newSource = newDoc.activeLayer;
    if (!isConcreteSourceLayer(newSource)) {
      cleanupTemporaryArtifacts(state.doc, true);
      if (newDoc !== state.doc) cleanupTemporaryArtifacts(newDoc, true);
      state.doc = newDoc;
      state.sourceLayer = null;
      state.sourceChannel = null;
      state.previewLayer = null;
      updateSourceText();
      setStatus("请选择具体图层，不要选择画板或图层组。", true);
      return false;
    }
    cleanupTemporaryArtifacts(state.doc, true);
    if (newDoc !== state.doc) cleanupTemporaryArtifacts(newDoc, true);

    state.doc = newDoc;
    state.sourceLayer = newSource;
    state.sourceChannel = null;
    state.previewLayer = null;
    state.liveDragEnabled = getDocumentPixelCount(newDoc) <= 40000000;
    updateSourceText();

    if (state.ui.previewCheck.value) {
      if (!captureSourceAlpha()) return false;
      requestPreview(false);
    } else if (showMessage) {
      setStatus("已锁定当前文档和来源图层。", false);
    }
    return true;
  }

  function updateSourceText() {
    if (!state.doc || !state.sourceLayer) {
      state.ui.sourceText.text = "尚未读取图层";
      return;
    }
    var modeText = getModeText(state.doc);
    state.ui.sourceText.text = "文档：" + safeName(state.doc) + "\n来源：" + safeName(state.sourceLayer) + "（" + modeText + "）";
  }

  function ensureSourceCache() {
    if (!isSourceValid()) {
      setStatus("来源已失效，请点击“重新读取当前图层”。", true);
      return false;
    }
    if (!state.sourceChannel || !isChannelValid(state.sourceChannel)) {
      return captureSourceAlpha();
    }
    return true;
  }

  function captureSourceAlpha() {
    if (!isSourceValid()) return false;
    if (!isConcreteSourceLayer(state.sourceLayer)) {
      setStatus("当前选中对象不能直接读取透明度，请选择具体图层，不要选择画板或图层组。", true);
      return false;
    }
    var doc = state.doc;
    app.activeDocument = doc;
    removeLayersByName(doc, PREVIEW_LAYER_NAME, null);
    removeChannelsByName(doc, SOURCE_CHANNEL_NAME);
    removeChannelsByName(doc, WORK_CHANNEL_NAME);
    removeChannelsByName(doc, SELECTION_CHANNEL_NAME);
    var context = captureDocumentContext(doc);
    var sourceChannel = null;

    try {
      doc.activeLayer = state.sourceLayer;
      loadActiveLayerTransparency();
      if (!selectionHasBounds(doc)) {
        throw new Error("当前来源没有可用的非透明区域。");
      }

      sourceChannel = doc.channels.add();
      sourceChannel.name = SOURCE_CHANNEL_NAME;
      doc.selection.store(sourceChannel, SelectionType.REPLACE);
      state.sourceChannel = sourceChannel;
      return true;
    } catch (err) {
      state.sourceChannel = null;
      setStatus("当前选中对象不能直接读取透明度，请选择具体图层，不要选择画板或图层组。详情：" + err.message, true);
      return false;
    } finally {
      restoreDocumentContext(doc, context);
    }
  }

  function requestPreview(fromDragging) {
    if (state.closing || !state.ui.previewCheck.value) return;
    if (!ensureSourceCache()) return;

    if (fromDragging) {
      if (!state.liveDragEnabled) {
        setStatus("当前文件较大：松开滑杆后更新预览。", false);
        return;
      }
      var now = new Date().getTime();
      if (now - state.lastRefreshAt < 130) return;
    }

    var settings = readSettings(false);
    if (!settings) return;
    state.pendingSettings = settings;
    var started = new Date().getTime();

    try {
      app.activeDocument = state.doc;
      if (state.doc.suspendHistory) {
        state.doc.suspendHistory("更新白墨预览", "$.global.__whiteInkPreviewHistory()");
      } else {
        refreshPreviewCore(settings);
      }
      state.lastRefreshAt = new Date().getTime();
      var elapsed = state.lastRefreshAt - started;
      if (elapsed > 800) state.liveDragEnabled = false;
      setStatus("预览已更新" + (state.liveDragEnabled ? "" : "；当前文件改为松开滑杆后刷新") + "。", false);
      app.refresh();
    } catch (err) {
      setStatus("预览失败：" + err.message, true);
    }
  }

  function refreshPreviewCore(settings) {
    var doc = state.doc;
    var context = captureDocumentContext(doc);
    try {
      removeLayersByName(doc, PREVIEW_LAYER_NAME, null);
      state.previewLayer = generateLayerCore(settings, true);
    } finally {
      restoreDocumentContext(doc, context);
    }
  }

  function generateFinalLayer() {
    if (!ensureSourceCache()) return;
    var settings = readSettings(true);
    if (!settings) return;

    if (settings.clearOld && safeName(state.sourceLayer) === settings.layerName) {
      setStatus("来源图层与正式白墨层同名，请换一个图层名或取消删除同名层。", true);
      return;
    }

    var doc = state.doc;
    var context = captureDocumentContext(doc);
    state.pendingSettings = settings;
    state.generatedLayer = null;

    try {
      app.activeDocument = doc;
      removeLayersByName(doc, PREVIEW_LAYER_NAME, null);
      if (settings.clearOld) removeLayersByName(doc, settings.layerName, state.sourceLayer);

      if (doc.suspendHistory) {
        doc.suspendHistory("生成正式白墨", "$.global.__whiteInkGenerateHistory()");
      } else {
        state.generatedLayer = generateLayerCore(settings, false);
      }

      if (!state.generatedLayer) throw new Error("没有生成白墨图层。");
      state.ui.previewCheck.value = false;
      cleanupChannelsOnly(doc);
      state.sourceChannel = null;
      setStatus("正式白墨已生成：" + settings.layerName + "。" + getOutputColorMessage(doc), false);
    } catch (err) {
      setStatus("生成失败：" + err.message, true);
    } finally {
      restoreDocumentContext(doc, context);
      app.refresh();
    }
  }

  function generateLayerCore(settings, isPreview) {
    var doc = state.doc;
    var workChannel = null;
    var layer = null;
    try {
      if (!state.sourceChannel || !isChannelValid(state.sourceChannel)) {
        throw new Error("原始 Alpha 缓存不存在，请重新读取当前图层。");
      }

      removeChannelsByName(doc, WORK_CHANNEL_NAME);
      doc.selection.load(state.sourceChannel, SelectionType.REPLACE);
      workChannel = doc.channels.add();
      workChannel.name = WORK_CHANNEL_NAME;
      doc.selection.store(workChannel, SelectionType.REPLACE);
      doc.activeChannels = [workChannel];
      applyAlphaLevels(settings.takeoff, settings.hardness);
      doc.selection.load(workChannel, SelectionType.REPLACE);
      restoreComponentChannels(doc);

      applySelectionOffset(doc, settings.offsetPx);
      if (!selectionHasBounds(doc)) {
        throw new Error("调整后白墨区域为空，请降低淡边取舍或减少内缩。");
      }

      layer = doc.artLayers.add();
      layer.name = isPreview ? PREVIEW_LAYER_NAME : settings.layerName;
      layer.opacity = isPreview && settings.previewMode === "blue" ? 65 : 100;
      layer.blendMode = BlendMode.NORMAL;
      doc.selection.fill(makeOutputColor(doc, isPreview && settings.previewMode === "blue"), ColorBlendMode.NORMAL, 100, false);
      var previewAboveSource = isPreview && settings.previewMode === "blue";
      moveLayerNearSource(layer, state.sourceLayer, previewAboveSource ? false : settings.placeBelow);

      if (isPreview) {
        try { layer.allLocked = true; } catch (lockErr) {}
        state.previewLayer = layer;
      }
      return layer;
    } finally {
      try { restoreComponentChannels(doc); } catch (channelsErr) {}
      try {
        if (workChannel) workChannel.remove();
      } catch (removeChannelErr) {}
    }
  }

  function readSettings(forFinal) {
    var layerName = trimString(state.ui.nameInput.text);
    var takeoff = parseNumber(state.ui.takeoffValue.text);
    var hardness = parseNumber(state.ui.hardnessValue.text);
    var offsetPx = parseNumber(state.ui.offsetInput.text);

    if (forFinal && !layerName) {
      setStatus("请填写正式白墨图层名。", true);
      return null;
    }
    if (isNaN(takeoff) || isNaN(hardness) || isNaN(offsetPx)) {
      setStatus("透明度和扩缩参数需要填写数字。", true);
      return null;
    }

    takeoff = Math.max(0, Math.min(100, Math.round(takeoff)));
    hardness = Math.max(0, Math.min(100, Math.round(hardness)));
    offsetPx = Math.max(-100, Math.min(100, Math.round(offsetPx)));

    return {
      layerName: layerName || "白墨",
      takeoff: takeoff,
      hardness: hardness,
      offsetPx: offsetPx,
      previewMode: state.ui.previewMode.selection && state.ui.previewMode.selection.index === 1 ? "black" : "blue",
      placeBelow: state.ui.placeBelowCheck.value,
      clearOld: state.ui.clearOldCheck.value
    };
  }

  function applyAlphaLevels(takeoff, hardness) {
    var center = Math.round(takeoff * 2.55);
    var normalizedHardness = hardness / 100;
    var width = Math.max(1, Math.round(255 * (1 - normalizedHardness)));
    var blackPoint = Math.max(0, Math.round(center - width / 2));
    var whitePoint = Math.min(255, Math.round(center + width / 2));

    if (hardness === 0 && takeoff === 50) {
      blackPoint = 0;
      whitePoint = 255;
    }
    if (whitePoint <= blackPoint) whitePoint = Math.min(255, blackPoint + 1);
    if (whitePoint <= blackPoint) blackPoint = Math.max(0, whitePoint - 1);

    var desc = new ActionDescriptor();
    var adjustments = new ActionList();
    var adjustment = new ActionDescriptor();
    var input = new ActionList();
    var output = new ActionList();
    input.putInteger(blackPoint);
    input.putInteger(whitePoint);
    output.putInteger(0);
    output.putInteger(255);
    adjustment.putList(charIDToTypeID("Inpt"), input);
    adjustment.putDouble(charIDToTypeID("Gmm "), 1.0);
    adjustment.putList(charIDToTypeID("Otpt"), output);
    adjustments.putObject(charIDToTypeID("LvlA"), adjustment);
    desc.putList(charIDToTypeID("Adjs"), adjustments);
    executeAction(charIDToTypeID("Lvls"), desc, DialogModes.NO);
  }

  function makeOutputColor(doc, useBlue) {
    var color = new SolidColor();
    if (useBlue) {
      color.rgb.red = 35;
      color.rgb.green = 180;
      color.rgb.blue = 255;
    } else if (doc.mode === DocumentMode.CMYK) {
      color.cmyk.cyan = 0;
      color.cmyk.magenta = 0;
      color.cmyk.yellow = 0;
      color.cmyk.black = 100;
    } else {
      color.rgb.red = 0;
      color.rgb.green = 0;
      color.rgb.blue = 0;
    }
    return color;
  }

  function getOutputColorMessage(doc) {
    return doc.mode === DocumentMode.CMYK ? "颜色为 C0 M0 Y0 K100。" : "当前不是 CMYK 文档，使用 RGB 0/0/0，未转换颜色模式。";
  }

  function cleanupTemporaryArtifacts(doc, removeSourceChannel) {
    if (!doc) return;
    var oldDoc = null;
    try { oldDoc = app.activeDocument; } catch (e) {}
    try {
      app.activeDocument = doc;
      removeLayersByName(doc, PREVIEW_LAYER_NAME, null);
      removeChannelsByName(doc, WORK_CHANNEL_NAME);
      removeChannelsByName(doc, SELECTION_CHANNEL_NAME);
      if (removeSourceChannel) removeChannelsByName(doc, SOURCE_CHANNEL_NAME);
    } catch (cleanupErr) {
    } finally {
      try { if (oldDoc) app.activeDocument = oldDoc; } catch (restoreDocErr) {}
    }
  }

  function cleanupChannelsOnly(doc) {
    removeChannelsByName(doc, WORK_CHANNEL_NAME);
    removeChannelsByName(doc, SOURCE_CHANNEL_NAME);
  }

  function captureDocumentContext(doc) {
    var context = { activeLayer: null, activeChannels: null, selectionChannel: null, hadSelection: false, rulerUnits: app.preferences.rulerUnits };
    try { context.activeLayer = doc.activeLayer; } catch (e) {}
    try { context.activeChannels = doc.activeChannels; } catch (e2) {}
    try {
      if (selectionHasBounds(doc)) {
        removeChannelsByName(doc, SELECTION_CHANNEL_NAME);
        context.selectionChannel = doc.channels.add();
        context.selectionChannel.name = SELECTION_CHANNEL_NAME;
        doc.selection.store(context.selectionChannel, SelectionType.REPLACE);
        context.hadSelection = true;
      }
    } catch (selectionErr) {}
    app.preferences.rulerUnits = Units.PIXELS;
    return context;
  }

  function restoreDocumentContext(doc, context) {
    if (!context) return;
    try {
      if (context.hadSelection && context.selectionChannel && isChannelValid(context.selectionChannel)) {
        doc.selection.load(context.selectionChannel, SelectionType.REPLACE);
      } else {
        doc.selection.deselect();
      }
    } catch (selectionErr) {}
    try {
      if (context.selectionChannel && isChannelValid(context.selectionChannel)) context.selectionChannel.remove();
    } catch (removeErr) {}
    try {
      if (context.activeChannels && context.activeChannels.length > 0) doc.activeChannels = context.activeChannels;
      else restoreComponentChannels(doc);
    } catch (channelsErr) {
      try { restoreComponentChannels(doc); } catch (fallbackErr) {}
    }
    try {
      if (context.activeLayer && isLayerValid(context.activeLayer)) doc.activeLayer = context.activeLayer;
      else if (state.sourceLayer && isLayerValid(state.sourceLayer)) doc.activeLayer = state.sourceLayer;
    } catch (layerErr) {}
    try { app.preferences.rulerUnits = context.rulerUnits; } catch (unitsErr) {}
  }

  function loadActiveLayerTransparency() {
    var desc = new ActionDescriptor();
    var selectionRef = new ActionReference();
    selectionRef.putProperty(charIDToTypeID("Chnl"), charIDToTypeID("fsel"));
    desc.putReference(charIDToTypeID("null"), selectionRef);
    var transparencyRef = new ActionReference();
    transparencyRef.putEnumerated(charIDToTypeID("Chnl"), charIDToTypeID("Chnl"), charIDToTypeID("Trsp"));
    desc.putReference(charIDToTypeID("T   "), transparencyRef);
    executeAction(charIDToTypeID("setd"), desc, DialogModes.NO);
  }

  function applySelectionOffset(doc, offsetPx) {
    if (offsetPx === 0) return;
    if (offsetPx > 0) {
      try { doc.selection.expand(offsetPx); }
      catch (e) { actionSelectionOffset("Expn", offsetPx); }
    } else {
      var amount = Math.abs(offsetPx);
      try { doc.selection.contract(amount); }
      catch (e2) { actionSelectionOffset("Cntc", amount); }
    }
  }

  function actionSelectionOffset(actionCode, px) {
    var desc = new ActionDescriptor();
    desc.putUnitDouble(charIDToTypeID("By  "), charIDToTypeID("#Pxl"), px);
    executeAction(charIDToTypeID(actionCode), desc, DialogModes.NO);
  }

  function moveLayerNearSource(layer, source, placeBelow) {
    try {
      layer.move(source, placeBelow ? ElementPlacement.PLACEAFTER : ElementPlacement.PLACEBEFORE);
    } catch (e) {}
  }

  function removeLayersByName(container, layerName, excludedLayer) {
    if (!container || !container.layers) return;
    for (var i = container.layers.length - 1; i >= 0; i--) {
      var layer = container.layers[i];
      if (layer.typename === "LayerSet") removeLayersByName(layer, layerName, excludedLayer);
      if (layer !== excludedLayer && safeName(layer) === layerName) {
        try { layer.allLocked = false; } catch (unlockErr) {}
        try { layer.remove(); } catch (removeErr) {}
      }
    }
  }

  function removeChannelsByName(doc, channelName) {
    if (!doc) return;
    for (var i = doc.channels.length - 1; i >= 0; i--) {
      var channel = doc.channels[i];
      if (safeName(channel) === channelName) {
        try { channel.remove(); } catch (e) {}
      }
    }
  }

  function restoreComponentChannels(doc) {
    var channels = [];
    for (var i = 0; i < doc.channels.length; i++) {
      try {
        if (doc.channels[i].kind === ChannelType.COMPONENT) channels.push(doc.channels[i]);
      } catch (e) {}
    }
    if (channels.length > 0) doc.activeChannels = channels;
  }

  function selectionHasBounds(doc) {
    try {
      var bounds = doc.selection.bounds;
      return bounds && bounds.length === 4;
    } catch (e) {
      return false;
    }
  }

  function isSourceValid() {
    return state.doc && state.sourceLayer && isLayerValid(state.sourceLayer);
  }

  function isConcreteSourceLayer(layer) {
    try {
      return layer && layer.typename === "ArtLayer";
    } catch (e) {
      return false;
    }
  }

  function isLayerValid(layer) {
    try { var name = layer.name; return name !== undefined; }
    catch (e) { return false; }
  }

  function isChannelValid(channel) {
    try { var name = channel.name; return name !== undefined; }
    catch (e) { return false; }
  }

  function getDocumentPixelCount(doc) {
    try { return doc.width.as("px") * doc.height.as("px"); }
    catch (e) { return 0; }
  }

  function getModeText(doc) {
    if (doc.mode === DocumentMode.CMYK) return "CMYK，正式输出 K100";
    if (doc.mode === DocumentMode.RGB) return "RGB，正式输出 RGB 0/0/0";
    return "非 CMYK/RGB，建议先确认生产颜色模式";
  }

  function setStatus(message, isError) {
    if (!state.ui || !state.ui.statusText) return;
    state.ui.statusText.text = (isError ? "提示：" : "") + message;
  }

  function parseNumber(value) {
    return parseFloat(String(value).replace(",", "."));
  }

  function trimString(value) {
    return String(value).replace(/^\s+|\s+$/g, "");
  }

  function safeName(value) {
    try { return value.name; } catch (e) { return ""; }
  }
}());
