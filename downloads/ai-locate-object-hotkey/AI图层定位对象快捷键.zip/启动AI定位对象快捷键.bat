@echo off
set "SCRIPT=%~dp0AI_Locate_Object_Hotkey.ps1"
start "AI Locate Object Hotkey" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Minimized -File "%SCRIPT%"
