#target illustrator

/*
  AI_图层面板定位对象.jsx

  Purpose:
  - Opens Illustrator's Layers panel for the current selection.
  - The actual Layers panel "Locate Object" button is a panel UI control, not a
    stable Illustrator JSX menu command. Use the paired PowerShell hotkey script
    to trigger that button with the ~ key after one-time calibration.
*/

(function () {
  if (app.documents.length === 0) {
    alert("请先打开一个 Illustrator 文件。");
    return;
  }

  var doc = app.activeDocument;
  var hasSelection = false;

  try {
    hasSelection = doc.selection && doc.selection.length > 0;
  } catch (e) {
    hasSelection = false;
  }

  try {
    app.activate();
  } catch (activateErr) {}

  try {
    app.executeMenuCommand("AdobeLayerPalette1");
  } catch (panelErr) {
    alert("无法打开图层面板：\n" + panelErr.message);
    return;
  }

  if (!hasSelection) {
    alert("图层面板已打开。\n\n请先选中一个对象，再使用图层面板底部的“定位对象”。");
    return;
  }

  alert(
    "图层面板已打开。\n\n" +
      "如需用 ~ 键定位对象，请运行配套的 PowerShell 快捷键脚本，并先把鼠标放到图层面板底部“定位对象”按钮上按 Ctrl+Alt+~ 校准一次。"
  );
})();
