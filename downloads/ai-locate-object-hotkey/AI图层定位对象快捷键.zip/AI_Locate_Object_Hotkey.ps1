param(
    [switch]$SelfTest
)

$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.Windows.Forms

$signature = @"
using System;
using System.Runtime.InteropServices;

public static class NativeKeys {
    [StructLayout(LayoutKind.Sequential)]
    public struct POINT {
        public int X;
        public int Y;
    }

    [DllImport("user32.dll")]
    public static extern short GetAsyncKeyState(int vKey);

    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

    [DllImport("user32.dll")]
    public static extern bool GetCursorPos(out POINT lpPoint);

    [DllImport("user32.dll")]
    public static extern bool SetCursorPos(int X, int Y);

    [DllImport("user32.dll")]
    public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);
}
"@

Add-Type -TypeDefinition $signature

$VK_SHIFT = 0x10
$VK_CONTROL = 0x11
$VK_MENU = 0x12
$VK_ESCAPE = 0x1B
$VK_OEM_3 = 0xC0
$MOUSEEVENTF_LEFTDOWN = 0x0002
$MOUSEEVENTF_LEFTUP = 0x0004

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$configPath = Join-Path $scriptDir "AI_locate_object_hotkey.config.json"
$logPath = Join-Path $scriptDir "AI_locate_object_hotkey.log"

function Write-Log($message) {
    $line = "{0} {1}" -f (Get-Date).ToString("yyyy-MM-dd HH:mm:ss"), $message
    Add-Content -LiteralPath $logPath -Value $line -Encoding UTF8
}

function Show-Info($message) {
    [System.Windows.Forms.MessageBox]::Show(
        $message,
        "AI Locate Object Hotkey",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
}

function Show-Warn($message) {
    [System.Windows.Forms.MessageBox]::Show(
        $message,
        "AI Locate Object Hotkey",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    ) | Out-Null
}

function Test-KeyDown($vk) {
    return ([NativeKeys]::GetAsyncKeyState($vk) -band 0x8000) -ne 0
}

function Get-ActiveProcessName {
    $hwnd = [NativeKeys]::GetForegroundWindow()
    if ($hwnd -eq [IntPtr]::Zero) {
        return ""
    }

    $processId = 0
    [void][NativeKeys]::GetWindowThreadProcessId($hwnd, [ref]$processId)
    if ($processId -le 0) {
        return ""
    }

    try {
        return (Get-Process -Id $processId -ErrorAction Stop).ProcessName
    } catch {
        return ""
    }
}

function Test-IllustratorActive {
    $name = Get-ActiveProcessName
    return $name -match "^Illustrator"
}

function Read-Config {
    if (!(Test-Path -LiteralPath $configPath)) {
        return $null
    }

    try {
        return Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
    } catch {
        return $null
    }
}

function Save-Config($x, $y) {
    $data = [ordered]@{
        x = [int]$x
        y = [int]$y
        updatedAt = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
        note = "Screen coordinate of Illustrator Layers panel Locate Object button."
        engine = "GetAsyncKeyState polling"
    }

    $data | ConvertTo-Json | Set-Content -LiteralPath $configPath -Encoding UTF8
}

function Click-LocateButton {
    if (!(Test-IllustratorActive)) {
        return
    }

    $config = Read-Config
    if ($null -eq $config -or $null -eq $config.x -or $null -eq $config.y) {
        Show-Warn "Button position is not calibrated yet.`n`nIn Illustrator, open the Layers panel, place your mouse on the Locate Object button, then press Ctrl+Alt+~ once."
        return
    }

    $oldPoint = New-Object NativeKeys+POINT
    [void][NativeKeys]::GetCursorPos([ref]$oldPoint)

    [void][NativeKeys]::SetCursorPos([int]$config.x, [int]$config.y)
    Start-Sleep -Milliseconds 30
    [NativeKeys]::mouse_event($MOUSEEVENTF_LEFTDOWN, 0, 0, 0, [UIntPtr]::Zero)
    Start-Sleep -Milliseconds 30
    [NativeKeys]::mouse_event($MOUSEEVENTF_LEFTUP, 0, 0, 0, [UIntPtr]::Zero)
    Start-Sleep -Milliseconds 30
    [void][NativeKeys]::SetCursorPos($oldPoint.X, $oldPoint.Y)
    Write-Log "Clicked Locate Object at X=$($config.x), Y=$($config.y)"
}

function Calibrate-LocateButton {
    if (!(Test-IllustratorActive)) {
        Show-Warn "Switch to Illustrator first. Then place your mouse on the Layers panel Locate Object button and press Ctrl+Alt+~."
        return
    }

    $point = New-Object NativeKeys+POINT
    [void][NativeKeys]::GetCursorPos([ref]$point)
    Save-Config $point.X $point.Y
    Write-Log "Calibrated Locate Object at X=$($point.X), Y=$($point.Y)"
    Show-Info ("Saved Locate Object button position: X={0}, Y={1}`n`nPress ~ in Illustrator to trigger it." -f $point.X, $point.Y)
}

if ($SelfTest) {
    "SelfTest OK"
    exit 0
}

Write-Log "Started polling hotkey engine. ~ triggers only while Illustrator is active."

$wasOem3Down = $false

while ($true) {
    $oem3Down = Test-KeyDown $VK_OEM_3

    if ($oem3Down -and -not $wasOem3Down) {
        $ctrlDown = Test-KeyDown $VK_CONTROL
        $altDown = Test-KeyDown $VK_MENU
        $shiftDown = Test-KeyDown $VK_SHIFT
        $escapeDown = Test-KeyDown $VK_ESCAPE

        if ($ctrlDown -and $altDown -and $shiftDown) {
            Write-Log "Exited by Ctrl+Alt+Shift+~"
            break
        } elseif ($ctrlDown -and $altDown) {
            Calibrate-LocateButton
        } elseif (!$ctrlDown -and !$altDown -and !$escapeDown) {
            Click-LocateButton
        }
    }

    $wasOem3Down = $oem3Down
    Start-Sleep -Milliseconds 25
}
