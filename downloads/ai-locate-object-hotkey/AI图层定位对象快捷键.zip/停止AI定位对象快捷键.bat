@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$self=$PID; Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -ne $self -and $_.CommandLine -like '*AI_Locate_Object_Hotkey.ps1*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }"
